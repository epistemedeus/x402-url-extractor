import { existsSync } from "node:fs";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { CompositionError } from "./errors.mjs";
import { PACKAGE_ROOT } from "./support.mjs";

export async function loadInspector(options = {}) {
  const vendor = join(PACKAGE_ROOT, "vendor/s20-route-compare-ro");
  const sibling = join(PACKAGE_ROOT, "../s20-route-compare-ro");
  const fromEnv = options.s20Root || process.env.COMPOSITION_S20_ROOT;
  const chosen = fromEnv || (existsSync(join(vendor, "src/inspect.mjs")) ? vendor : sibling);
  const entry = join(chosen, "src/inspect.mjs");
  if (!existsSync(entry)) throw new CompositionError("inspector_missing", 3);
  const mod = await import(pathToFileURL(entry).href);
  if (typeof mod.inspectRequest !== "function") throw new CompositionError("inspector_missing", 3);
  return { root: chosen, inspectRequest: mod.inspectRequest };
}
