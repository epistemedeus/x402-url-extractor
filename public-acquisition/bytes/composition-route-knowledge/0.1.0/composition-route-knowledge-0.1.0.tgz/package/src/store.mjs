import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { receivingInstant } from "./clock.mjs";
import { CompositionError } from "./errors.mjs";
import { loadOriginal } from "./knowledge.mjs";
import { verifySupport } from "./support.mjs";

export const STORE_SCHEMA = "pilot.composition-knowledge-store.v1";

export function storePath(dir) {
  return join(dir, "store.json");
}

export function readStore(dir) {
  const path = storePath(dir);
  if (!existsSync(path)) throw new CompositionError("knowledge_store_missing");
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(path, "utf8"));
  } catch {
    throw new CompositionError("knowledge_store_invalid");
  }
  if (!parsed || parsed.schemaVersion !== STORE_SCHEMA || !parsed.record || !Array.isArray(parsed.decisions)) {
    throw new CompositionError("knowledge_store_invalid");
  }
  return parsed;
}

export function writeStore(dir, store) {
  mkdirSync(dir, { recursive: true });
  writeFileSync(storePath(dir), `${JSON.stringify(store, null, 2)}\n`);
}

export function retain(dir, now = new Date()) {
  if (existsSync(storePath(dir))) throw new CompositionError("knowledge_store_exists");
  const review = verifySupport();
  const record = loadOriginal();
  const store = {
    schemaVersion: STORE_SCHEMA,
    retainedAt: receivingInstant(now),
    record: { ...record, revokedAt: null, revocationReason: null },
    decisions: [],
    review,
  };
  writeStore(dir, store);
  return {
    retained: true,
    retainedAt: store.retainedAt,
    classId: record.classId,
    freezeDigest: record.freezeDigest,
    taskHeldForLaterConsumer: "read-only-quote-comparison",
  };
}

export function revoke(dir, now = new Date()) {
  const store = readStore(dir);
  if (store.record.revokedAt) throw new CompositionError("already_revoked");
  store.record.revokedAt = receivingInstant(now);
  store.record.revocationReason = "retained compatibility result revoked";
  writeStore(dir, store);
  return { revokedAt: store.record.revokedAt, classId: store.record.classId, freezeDigest: store.record.freezeDigest };
}
