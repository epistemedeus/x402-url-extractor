import { createHash } from "node:crypto";

export const QUOTE_SCHEMA = "pilot.s20-public-quote.v1";

export const COST_EXCLUSIONS = Object.freeze([
  "accounting_deduction",
  "hosting_marginal",
  "provider_api_marginal",
  "retry_error_refund",
  "seller_chain_gas",
  "settlement_deduction",
]);

export function operationQuote({
  routeId,
  operation = "compose.read-only-inspect",
  facilitatorUrl,
  facilitatorAllIn = "3",
  buyer = "10",
  notBefore,
  expiresAt,
  evidenceClass = "fixture",
  network = "eip155:84532",
  scheme = "exact",
  environment = "test",
  asset = "FIXTURE",
  unit = "fixture_micro",
  omitFee = false,
  omitInterval = false,
  omitTopology = false,
}) {
  const quote = {
    schemaVersion: QUOTE_SCHEMA,
    evidenceClass,
    routeId,
    operation,
    environment,
    unit,
    asset,
    components: { buyer_payment_requirement: buyer },
    exclusions: [...COST_EXCLUSIONS],
    interval: { notBefore, expiresAt },
    topology: { network, scheme, facilitatorUrl },
  };
  if (!omitFee) quote.components.facilitator_all_in = facilitatorAllIn;
  if (omitInterval) delete quote.interval;
  if (omitTopology) delete quote.topology;
  return quote;
}

export function quoteIdFor(side) {
  if (typeof side.bodySha256 === "string" && /^[0-9a-f]{64}$/.test(side.bodySha256)) {
    return side.bodySha256;
  }
  const fields = {
    asset: side.asset ?? null,
    bodySha256: side.bodySha256 ?? null,
    components: side.components ?? null,
    environment: side.environment ?? null,
    evidenceClass: side.evidenceClass ?? null,
    exclusions: side.exclusions ?? null,
    httpStatus: side.httpStatus ?? null,
    interval: side.interval ?? null,
    operation: side.operation ?? null,
    routeId: side.routeId ?? null,
    topology: side.topology ?? null,
    unit: side.unit ?? null,
    url: side.url ?? null,
  };
  return createHash("sha256").update(JSON.stringify(fields)).digest("hex");
}
