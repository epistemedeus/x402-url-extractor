import { CompositionError } from "./errors.mjs";

const INSTANT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/;
const SKEW_MS = 120000;

export function receivingInstant(date = new Date()) {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    throw new CompositionError("receiver_clock_invalid");
  }
  return date.toISOString().slice(0, 19) + "Z";
}

export function receiverAsOf(requestAsOf, now = new Date()) {
  const receiver = receivingInstant(now);
  if (requestAsOf === undefined) return receiver;
  if (typeof requestAsOf !== "string" || !INSTANT.test(requestAsOf)) {
    throw new CompositionError("as_of_invalid");
  }
  const delta = Math.abs(Date.parse(requestAsOf) - now.getTime());
  if (!Number.isFinite(delta) || delta > SKEW_MS) {
    throw new CompositionError("as_of_not_receiver_clock");
  }
  return receiver;
}

export function freshnessOf(interval, asOf) {
  if (!asOf || !interval || !interval.notBefore || !interval.expiresAt) return "not_judged";
  if (asOf < interval.notBefore) return "early";
  if (asOf >= interval.expiresAt) return "stale";
  return "fresh";
}
