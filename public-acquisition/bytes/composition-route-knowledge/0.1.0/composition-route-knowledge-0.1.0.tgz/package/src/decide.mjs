import { createHash } from "node:crypto";
import { freshnessOf, receiverAsOf } from "./clock.mjs";
import { CompositionError } from "./errors.mjs";
import { LATER_TASK, ORIGINAL_CLASSES, loadOriginal } from "./knowledge.mjs";
import { quoteIdFor } from "./quotes.mjs";
import { loadInspector } from "./s20.mjs";
import { verifySupport } from "./support.mjs";

export const REQUEST_SCHEMA = "pilot.composition-route-decision-request.v1";
export const DECISION_SCHEMA = "pilot.composition-route-decision.v1";

const REQUEST_KEYS = new Set([
  "schemaVersion",
  "left",
  "right",
  "asOf",
  "retainedQuotes",
  "claimSavings",
  "taskId",
  "replayOriginalFixture",
]);

const FORBIDDEN = new Set([
  "spend",
  "spendAuthorized",
  "authorizeSpend",
  "broadcast",
  "sign",
  "signature",
  "signTransaction",
  "privateKey",
  "signer",
  "custody",
  "custodyAuthorized",
  "wallet",
  "payTo",
  "payment",
  "paymentAuthority",
  "signerAuthority",
  "publishPrice",
  "pricePublish",
  "sku",
  "selectCheaper",
  "cheaper",
  "cheapest",
  "profitable",
  "rank",
  "recommend",
  "recommendCheaper",
  "modelRank",
  "rankModels",
]);

const REASON_ORDER = [
  "changed_quote",
  "quality_evidence_mismatch",
  "not_an_operation_quote",
  "missing_fee_component",
  "undeclared_component",
  "unknown_fee",
  "unknown_interval",
  "unknown_topology",
  "mixed_environment",
  "topology_mismatch",
  "stale_quote",
  "quote_not_yet_effective",
  "freshness_not_judged",
  "interval_mismatch",
  "operation_mismatch",
  "environment_mismatch",
  "unit_mismatch",
  "asset_mismatch",
  "exclusion_mismatch",
];

const NEXT = {
  unknown_fee: "Disclose facilitator_all_in or name it in exclusions. Do not treat the gap as zero.",
  unknown_interval: "Record notBefore and expiresAt. The receiver clock cannot judge a quote without an interval.",
  unknown_topology: "Name network and scheme on both quotes before comparing them.",
  stale_quote: "Refresh the expired quote and judge it again at the receiver clock. Do not drop the stale side.",
  quote_not_yet_effective: "Wait until notBefore or replace the quote with one already in force at the receiver clock.",
  missing_fee_component: "Disclose the fee component the other side states, or exclude it by name. A missing fee is not zero.",
  undeclared_component: "Name every cost component as an amount or an exclusion before comparing.",
  topology_mismatch: "Compare quotes that share network and scheme.",
  interval_mismatch: "Align both quote intervals before comparing amounts.",
  operation_mismatch: "Compare quotes for the same operation.",
  environment_mismatch: "Compare quotes from the same environment.",
  unit_mismatch: "Compare quotes that use the same unit.",
  asset_mismatch: "Compare quotes that name the same asset.",
  exclusion_mismatch: "Align named exclusions before comparing.",
  not_an_operation_quote: "Obtain operation quotes for the same useful operation. A support catalog is not a price.",
  quality_evidence_mismatch: "Compare quotes that share an evidence class. A fixture is not a live observation.",
  changed_quote: "Re-inspect the new quote id. The retained quote id is not current.",
  freshness_not_judged: "Judge both intervals at the receiver clock before comparing amounts.",
  mixed_environment: "Split mixed testnet and mainnet catalogs before comparing.",
};

function scanAuthority(value) {
  if (!value || typeof value !== "object") return;
  if (Array.isArray(value)) {
    for (const item of value) scanAuthority(item);
    return;
  }
  for (const key of Object.keys(value)) {
    if (FORBIDDEN.has(key)) throw new CompositionError("authority_refused");
    scanAuthority(value[key]);
  }
}

function assertRequest(request) {
  if (!request || typeof request !== "object" || Array.isArray(request)) {
    throw new CompositionError("request_not_object");
  }
  scanAuthority(request);
  for (const key of Object.keys(request)) {
    if (!REQUEST_KEYS.has(key)) throw new CompositionError("unknown_request_field");
  }
  if (request.schemaVersion !== REQUEST_SCHEMA) throw new CompositionError("request_schema");
  if (request.replayOriginalFixture === true) throw new CompositionError("unchanged_fixture_not_reuse");
  if (request.taskId !== undefined) {
    if (ORIGINAL_CLASSES.includes(request.taskId)) throw new CompositionError("unchanged_fixture_not_reuse");
    if (request.taskId !== LATER_TASK.id) throw new CompositionError("unknown_task");
  }
  if (request.claimSavings === true) throw new CompositionError("declared_savings_refused");
  if (request.left === undefined || request.right === undefined) throw new CompositionError("request_sides_missing");
  if (request.retainedQuotes !== undefined) {
    if (!Array.isArray(request.retainedQuotes) || request.retainedQuotes.length < 1 || request.retainedQuotes.length > 2) {
      throw new CompositionError("retained_quotes_invalid");
    }
    for (const row of request.retainedQuotes) {
      if (!row || typeof row.quoteId !== "string" || !/^[0-9a-f]{64}$/.test(row.quoteId)) {
        throw new CompositionError("retained_quotes_invalid");
      }
      if (Object.keys(row).length !== 1) throw new CompositionError("unknown_request_field");
    }
  }
}

function gapsFor(side, label) {
  if (typeof side === "string") return [];
  if (!side || typeof side !== "object" || Array.isArray(side)) {
    return [{ code: "unknown_interval", side: label }];
  }
  const gaps = [];
  if (!side.interval || !side.interval.notBefore || !side.interval.expiresAt) {
    gaps.push({ code: "unknown_interval", side: label });
  }
  if (!side.topology || !side.topology.network || !side.topology.scheme) {
    gaps.push({ code: "unknown_topology", side: label });
  }
  const components = side.components && typeof side.components === "object" ? side.components : {};
  const exclusions = Array.isArray(side.exclusions) ? side.exclusions : [];
  if (!Object.prototype.hasOwnProperty.call(components, "facilitator_all_in") && !exclusions.includes("facilitator_all_in")) {
    gaps.push({ code: "unknown_fee", side: label });
  }
  return gaps;
}

function primary(reasons) {
  for (const code of REASON_ORDER) {
    if (reasons.includes(code)) return code;
  }
  return reasons[0] || "not_an_operation_quote";
}

function nextChecks(reasons, preface) {
  const lines = [];
  if (preface) lines.push(preface);
  for (const reason of reasons) {
    const line = NEXT[reason];
    if (line && !lines.includes(line)) lines.push(line);
  }
  return lines;
}

function sourceOf(request, label) {
  const side = label === "left" ? request.left : request.right;
  return typeof side === "string" ? side : "request";
}

function decorate(side, request) {
  const quoteId = quoteIdFor(side);
  return {
    quoteId,
    provenance: {
      quoteId,
      evidenceClass: side.evidenceClass ?? null,
      source: sourceOf(request, side.label || "left"),
      url: side.url ?? null,
      bodySha256: side.bodySha256 ?? null,
      probedAt: side.probedAt ?? null,
      routeId: side.routeId ?? null,
    },
    terms: {
      routeId: side.routeId ?? null,
      operation: side.operation ?? null,
      environment: side.environment ?? null,
      unit: side.unit ?? null,
      asset: side.asset ?? null,
      components: side.components ?? null,
      exclusions: side.exclusions ?? null,
      interval: side.interval ?? null,
      topology: side.topology ? {
        network: side.topology.network ?? null,
        scheme: side.topology.scheme ?? null,
        facilitatorUrl: side.topology.facilitatorUrl ?? null,
      } : null,
      evidenceClass: side.evidenceClass ?? null,
      feeState: side.feeDisclosure?.state ?? (side.components ? "see-components" : "unknown"),
      quoteKind: side.quoteKind ?? null,
    },
  };
}

function knowledgeBlock(record, adaptation, review, elapsedMs) {
  const revoked = Boolean(record.revokedAt);
  return {
    applied: false,
    reason: revoked ? "revoked" : "scope_mismatch",
    original: {
      package: record.package,
      pilotCommit: record.pilotCommit,
      freezeDigest: record.freezeDigest,
      comparisonSha256: record.comparisonSha256,
      comparisonStatus: record.comparisonStatus,
      classId: record.classId,
      scope: record.scope,
      preflightAdmitted: record.preflightAdmitted,
      reuse: record.reuse,
      direct: record.direct,
      sourcePaths: record.sourcePaths,
    },
    laterTask: LATER_TASK.id,
    differentConsumer: true,
    revoked,
    revokedAt: record.revokedAt || null,
    adaptation: { steps: adaptation, count: adaptation.length },
    review: { steps: review, count: review.length },
    elapsedMs,
    savingsObserved: false,
    savingsRefusal: "This later task measured its own steps and did not record a paired reduction. The original different-adapter elapsed gap is not savings on read-only quote comparison.",
  };
}

function guardText(decision) {
  const text = JSON.stringify(decision).toLowerCase();
  if (text.includes("cheaper") || text.includes("cheapest") || text.includes("profitable")) {
    throw new CompositionError("ranking_refused");
  }
}

function authorities() {
  return { payment: "none", signer: "none", wallet: "none" };
}

function adaptationFor(record) {
  const steps = [
    `load original compatibility result ${record.freezeDigest}`,
    `compare later task ${LATER_TASK.id} with original class ${record.classId}`,
  ];
  if (record.revokedAt) steps.push("withhold packet because the retained result is revoked");
  else steps.push("withhold packet because the later task scope differs");
  if (record.preflightAdmitted === false) steps.push("record preflight admission false");
  return steps;
}

export async function decide(request, options = {}) {
  const started = Date.now();
  assertRequest(request);
  const review = verifySupport();
  const record = options.record || loadOriginal();
  const asOf = receiverAsOf(request.asOf, options.now);
  review.push("judge freshness at the receiver clock");
  const adaptation = adaptationFor(record);
  const gaps = [...gapsFor(request.left, "left"), ...gapsFor(request.right, "right")];
  if (gaps.length > 0) {
    const reasons = [...new Set(gaps.map((gap) => gap.code))];
    const decision = {
      schemaVersion: DECISION_SCHEMA,
      readOnly: true,
      task: { ...LATER_TASK, differentFrom: record.classId },
      asOf,
      comparable: false,
      reason: primary(reasons),
      reasons,
      ranking: "withheld",
      selection: "none",
      priceAuthorized: false,
      spendAuthorized: false,
      signingAuthorized: false,
      custodyAuthorized: false,
      evaluatorUsed: false,
      costEngine: "not_invoked",
      unknownTreatedAsZero: false,
      quotes: [],
      termDifferences: [],
      gaps,
      eligibility: { left: "not_judged", right: "not_judged" },
      fees: { left: "unknown", right: "unknown", unknownTreatedAsZero: false },
      timing: { asOf, clock: "receiver" },
      quality: { evidenceAligned: false },
      previousDecisionCurrent: null,
      nextCheck: nextChecks(reasons, record.revokedAt
        ? `Compatibility result ${record.freezeDigest} was revoked at ${record.revokedAt}. Do not apply it to ${LATER_TASK.id}.`
        : null),
      knowledge: knowledgeBlock(record, adaptation, review, Date.now() - started),
      authorities: authorities(),
    };
    guardText(decision);
    return decision;
  }

  const inspector = await loadInspector(options);
  let inspection;
  try {
    inspection = await inspector.inspectRequest({
      schemaVersion: "pilot.s20-quote-inspection-request.v1",
      asOf,
      left: request.left,
      right: request.right,
    }, { baseDir: options.baseDir });
  } catch (error) {
    if (error instanceof CompositionError) throw error;
    if (error && error.reason) throw new CompositionError(error.reason, error.exitCode || 2);
    throw error;
  }
  if (inspection.evaluatorUsed !== false || inspection.spendAuthorized !== false || inspection.signingAuthorized !== false || inspection.custodyAuthorized !== false || inspection.priceAuthorized !== false || inspection.ranking !== "withheld" || inspection.selection !== "none") {
    throw new CompositionError("authority_refused");
  }
  review.push("attach quote ids and provenance");
  review.push("refuse ranking and payment authority");
  const quotes = (inspection.sides || []).map((side) => decorate(side, request));
  let changed = false;
  if (request.retainedQuotes) {
    review.push("compare retained quote ids");
    const retainedIds = request.retainedQuotes.map((row) => row.quoteId).sort();
    const currentIds = quotes.map((row) => row.quoteId).sort();
    changed = retainedIds.join() !== currentIds.join();
  }
  const left = inspection.sides?.[0];
  const right = inspection.sides?.[1];
  const qualityMismatch = Boolean(left && right && left.quoteKind === "operation_quote" && right.quoteKind === "operation_quote" && left.evidenceClass !== right.evidenceClass);
  let reasons = [...(inspection.reasons || [])];
  let comparable = inspection.comparable === true;
  if (qualityMismatch) {
    comparable = false;
    reasons.push("quality_evidence_mismatch");
  }
  if (changed) {
    comparable = false;
    reasons.push("changed_quote");
  }
  if (comparable) reasons = ["same_disclosed_basis"];
  const reason = comparable ? "same_disclosed_basis" : primary(reasons);
  const preface = record.revokedAt
    ? `Compatibility result ${record.freezeDigest} was revoked at ${record.revokedAt}. Do not apply it to ${LATER_TASK.id}.`
    : null;
  const decision = {
    schemaVersion: DECISION_SCHEMA,
    readOnly: true,
    task: { ...LATER_TASK, differentFrom: record.classId },
    asOf,
    comparable,
    reason,
    reasons,
    ranking: "withheld",
    selection: "none",
    priceAuthorized: false,
    spendAuthorized: false,
    signingAuthorized: false,
    custodyAuthorized: false,
    publication: "withheld",
    evaluatorUsed: false,
    costEngine: "not_invoked",
    unknownTreatedAsZero: false,
    omittedComponents: inspection.omittedComponents ?? null,
    quotes,
    termDifferences: inspection.termDifferences || [],
    eligibility: {
      left: freshnessOf(left?.interval, asOf),
      right: freshnessOf(right?.interval, asOf),
      sameOperation: Boolean(left?.operation && left.operation === right?.operation),
      evidenceAligned: Boolean(left && right && left.evidenceClass === right.evidenceClass) && !qualityMismatch,
    },
    fees: {
      left: left?.components ?? left?.feeDisclosure?.state ?? "unknown",
      right: right?.components ?? right?.feeDisclosure?.state ?? "unknown",
      unknownTreatedAsZero: false,
    },
    timing: {
      asOf,
      clock: "receiver",
      left: left?.interval ?? null,
      right: right?.interval ?? null,
    },
    quality: {
      evidenceAligned: Boolean(left && right && left.evidenceClass === right.evidenceClass) && !qualityMismatch,
      left: left?.evidenceClass ?? null,
      right: right?.evidenceClass ?? null,
    },
    quoteChanged: changed,
    previousDecisionCurrent: request.retainedQuotes ? !changed && comparable : null,
    freshInspection: changed ? {
      comparable: inspection.comparable === true,
      reason: inspection.reason,
      quoteIds: quotes.map((row) => row.quoteId),
    } : null,
    nextCheck: comparable && !record.revokedAt ? [] : nextChecks(comparable ? [] : reasons, preface),
    knowledge: knowledgeBlock(record, adaptation, review, Date.now() - started),
    authorities: authorities(),
  };
  decision.decisionId = createHash("sha256").update(JSON.stringify({
    asOf,
    reason: decision.reason,
    quoteIds: quotes.map((row) => row.quoteId),
    freezeDigest: record.freezeDigest,
    revoked: Boolean(record.revokedAt),
  })).digest("hex");
  guardText(decision);
  return decision;
}
