import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { CompositionError } from "./errors.mjs";

export const PACKAGE_ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");

export const SUPPORT_SHA256 = Object.freeze({
  LICENSE: "2c844e541eb597e55dcb35e0bf23d96fcb9ca540f14a9ea6973e4c00cefb1aaa",
  "SOURCE-NOTICE.txt": "6d0d7edcf4e5a971c0b1a2422e7800e7d121f53fd8cf5339331c72a40d0a2c0b",
  "DEPENDENCIES.md": "e45e940695a908339d783d72e70086797405ce2eb8e90f2749de891c4a718d7a",
  "COLD-INSTALL.txt": "46ab07d5cd4be23a8aa5504b74db1fae933cf35f01de31883f33dc4aa9a2aadc",
  "knowledge/original-result.json": "8ab187b532a08584750ce35c2d3b2ac084dd97609ef44fca0025080c45f97271",
  "inputs/r6-pin.json": "68f86c366e99918dc7a6304c0be134c7e20e7d693b45a9bc3a32bda2979306d5",
});

function sha256(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

export function verifySupport(root = PACKAGE_ROOT) {
  const review = [];
  for (const [rel, expected] of Object.entries(SUPPORT_SHA256)) {
    const path = join(root, rel);
    if (!existsSync(path)) throw new CompositionError("support_file_missing");
    const digest = sha256(readFileSync(path));
    review.push(`hash ${rel}`);
    if (digest !== expected) throw new CompositionError("support_file_tampered");
  }
  const pin = JSON.parse(readFileSync(join(root, "inputs/r6-pin.json"), "utf8"));
  if (!pin || !Array.isArray(pin.files) || pin.files.length === 0) {
    throw new CompositionError("support_file_tampered");
  }
  for (const row of pin.files) {
    if (!row || typeof row.path !== "string" || row.path.includes("..")) {
      throw new CompositionError("support_file_tampered");
    }
    const path = join(root, "inputs/r6", row.path);
    if (!existsSync(path)) throw new CompositionError("support_file_missing");
    const digest = sha256(readFileSync(path));
    review.push(`hash inputs/r6/${row.path}`);
    if (digest !== row.sha256) throw new CompositionError("support_file_tampered");
  }
  return review;
}
