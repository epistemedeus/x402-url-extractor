import { createHash } from "node:crypto";
import { CompositionError } from "./errors.mjs";

export const MAX_BYTES = 262144;

export const ALLOWED_URLS = Object.freeze([
  "https://x402.org/facilitator/supported",
  "https://facilitator.payai.network/supported",
  "https://v2.facilitator.mogami.tech/supported",
  "https://api.cdp.coinbase.com/platform/v2/x402/supported",
]);

const VOLATILE = new Set(["recentBlockhash", "lastValidBlockHeight"]);
const CREDENTIAL_HEADERS = new Set(["authorization", "cookie", "proxy-authorization", "x-api-key"]);

function sha256(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

function stripVolatile(value) {
  if (Array.isArray(value)) return value.map(stripVolatile);
  if (value && typeof value === "object") {
    const out = {};
    for (const key of Object.keys(value).sort()) {
      if (VOLATILE.has(key)) continue;
      out[key] = stripVolatile(value[key]);
    }
    return out;
  }
  return value;
}

function termsSha(body) {
  try {
    return sha256(Buffer.from(JSON.stringify(stripVolatile(JSON.parse(Buffer.from(body).toString("utf8"))))));
  } catch {
    return null;
  }
}

export async function boundedGet(url, options = {}) {
  if (options.method && options.method !== "GET") throw new CompositionError("method_refused");
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new CompositionError("host_not_allowlisted");
  }
  if (parsed.username || parsed.password || parsed.protocol !== "https:" || !ALLOWED_URLS.includes(url)) {
    throw new CompositionError("host_not_allowlisted");
  }
  for (const key of Object.keys(options.headers || {})) {
    if (CREDENTIAL_HEADERS.has(key.toLowerCase())) throw new CompositionError("credential_header_refused");
  }
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  const timeoutMs = options.timeoutMs ?? 10000;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let response;
  try {
    response = await fetchImpl(url, {
      method: "GET",
      redirect: "manual",
      signal: controller.signal,
      headers: { accept: "application/json, text/plain" },
    });
  } catch (error) {
    if (error && (error.name === "AbortError" || error.name === "TimeoutError")) {
      throw new CompositionError("read_timeout");
    }
    throw new CompositionError("read_failed");
  } finally {
    clearTimeout(timer);
  }
  if (response.status >= 300 && response.status < 400) throw new CompositionError("redirect_refused");
  const declared = Number(response.headers?.get?.("content-length"));
  if (Number.isFinite(declared) && declared > MAX_BYTES) throw new CompositionError("body_too_large");
  const body = Buffer.from(await response.arrayBuffer());
  if (body.length > MAX_BYTES) throw new CompositionError("body_too_large");
  return {
    url,
    status: response.status,
    bytes: body.length,
    body,
    bodySha256: sha256(body),
    contentType: response.headers?.get?.("content-type") || "",
  };
}

export async function probeFrozen({ manifest, readFrozen, fetchImpl, timeoutMs }) {
  if (!manifest || !Array.isArray(manifest.endpoints)) throw new CompositionError("probe_manifest_invalid");
  const rows = [];
  for (const endpoint of manifest.endpoints) {
    if (!ALLOWED_URLS.includes(endpoint.url)) throw new CompositionError("host_not_allowlisted");
    try {
      const live = await boundedGet(endpoint.url, { fetchImpl, timeoutMs });
      const frozen = readFrozen(endpoint.bodyFile);
      const frozenSha = sha256(frozen);
      const exact = frozenSha === live.bodySha256 && endpoint.bodySha256 === live.bodySha256 && live.status === endpoint.status;
      const savedTerms = termsSha(frozen);
      const liveTerms = termsSha(live.body);
      const termsMatch = exact || (live.status === endpoint.status && savedTerms !== null && savedTerms === liveTerms);
      rows.push({
        url: endpoint.url,
        status: live.status,
        bytes: live.bytes,
        bodySha256: live.bodySha256,
        frozenSha256: endpoint.bodySha256,
        exactMatch: exact,
        termsMatch,
        materialChange: !termsMatch,
      });
    } catch (error) {
      rows.push({
        url: endpoint.url,
        error: error.reason || "read_failed",
        materialChange: null,
      });
    }
  }
  const material = rows.some((row) => row.materialChange === true);
  const incomplete = rows.some((row) => row.error);
  return {
    schemaVersion: "pilot.composition-bounded-read.v1",
    observedAt: new Date().toISOString().slice(0, 19) + "Z",
    readOnly: true,
    ranking: "withheld",
    selection: "none",
    priceAuthorized: false,
    spendAuthorized: false,
    signingAuthorized: false,
    custodyAuthorized: false,
    frozeFilesWritten: false,
    readStatus: incomplete ? "incomplete" : "complete",
    materialChange: material,
    comparable: false,
    reason: material ? "changed_quote" : "not_an_operation_quote",
    nextCheck: material
      ? ["Frozen capture bytes changed. Re-inspect the new body. Do not rank the catalogs and do not replace the frozen archive from this read."]
      : ["These bodies are support catalogs, not operation quotes. A hash match is not a price."],
    rows,
  };
}
