export class CompositionError extends Error {
  constructor(reason, exitCode = 2) {
    super(reason);
    this.name = "CompositionError";
    this.reason = reason;
    this.exitCode = exitCode;
  }
}
