import { readFileSync } from "node:fs";
import { join } from "node:path";
import { CompositionError } from "./errors.mjs";
import { PACKAGE_ROOT } from "./support.mjs";

export const LATER_TASK = Object.freeze({
  id: "read-only-quote-comparison",
  consumer: "composition-route-knowledge",
  version: "0.1.0",
});

export const ORIGINAL_CLASSES = Object.freeze([
  "different-adapter",
  "changed-version-applicability",
  "unaffected-behavior",
  "incompatible-task",
  "ambiguous-applicability",
]);

export function loadOriginal(root = PACKAGE_ROOT) {
  const record = JSON.parse(readFileSync(join(root, "knowledge/original-result.json"), "utf8"));
  if (record.schemaVersion !== "pilot.vf14-original-compatibility-result.v1") {
    throw new CompositionError("knowledge_record_invalid");
  }
  if (record.comparisonStatus !== "executed" || record.classId !== "different-adapter") {
    throw new CompositionError("knowledge_record_invalid");
  }
  if (!Array.isArray(record.doesNotApplyTo) || !record.doesNotApplyTo.includes(LATER_TASK.id)) {
    throw new CompositionError("knowledge_record_invalid");
  }
  if (record.preflightAdmitted !== false || record.reuse?.correct !== true || record.direct?.correct !== false) {
    throw new CompositionError("knowledge_record_invalid");
  }
  return record;
}
