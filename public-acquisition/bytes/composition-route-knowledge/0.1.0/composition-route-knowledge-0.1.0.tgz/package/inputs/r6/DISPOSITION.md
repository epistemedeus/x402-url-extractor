# L01–L20 disposition

Updated 2026-10-01 from GitHub API and the live HTTP pins in
[evidence/live-pins-20261001.json](evidence/live-pins-20261001.json).
`control/plan/LAUNCH-0930/COVERAGE.md` (ledger timestamp 2026-09-30T16:10Z)
is historical. This table replaces its L01–L20 ownership claims. It does not
claim a 136-row re-audit.

R1–R5 were `running` at 2026-10-01T08:12Z. Their jobs are the active owners
named below. No new writer is assigned here.

| Family | Input pin | Active owner | Missing delta | Launch test | Next integration consumer |
| --- | --- | --- | --- | --- | --- |
| L01 hosted machine gateway | SDS `main` `f32d285f131fbaef6c7690b06be5efa68724d0b8` (PR 264 merged). Merchant `master` `e0880cce26abafc23859e40c5f971b042b3945ef`. Live OpenAPI `1.23.49` at `https://agents.samedaydesk.com/openapi.json` 2026-10-01T08:07:59Z | None on SDS. R5 `PAID-USEFUL-JOURNEY-100141` running on the merchant journey since 2026-10-01T08:04:26Z; no new merchant head was on the open-PR list at inspection | Neo origin still does not advertise a gateway (`llms.txt` fact). Cohort 8 says the optional correspondence mount on the SDS host is unconfigured; this pass did not re-probe that mount | Cold caller completes one useful gateway call and reads the result after a process restart, with the optional mount absent preserving existing routes | R5 paid journey, then L19 joins |
| L02 contract-qualified market | Neo PR 208 draft `004545564e7ebbdf9c6d66ec7075e9b15ef14ff6` on `heavy/neo109-earned-receiving-20260926`. Current earned head is PR 227 `4d49fbca49100b56e2986d0187d5191e2abf91fb` | R3 `EARNED-HOST-100139` running since 2026-10-01T08:05:22Z on PR 227. PR 208 stays open and is not a second writer | Real listing through acceptance on the hosted kernel. Synthetic cards remain short of launch. 0.10 USDC stays unfunded | One real claim, useful submission, and acceptance, with owed distinct from settled | P3 contribution package after R3 exports |
| L03 walletless contributor entry | Same PR 227 pin. Pack `packs/contributor-walletless-job` MIT, nonsettling | R3, same job as L02 | Payout destination and a funded disclosed reward. The pack already reaches owed without a wallet | Fresh contributor discovers prerequisites, submits, and sees owed while settled stays false | P3, same consumer as L02 |
| L04 visitor capability network | Dead lanes preserved below (VF16-b, VF17). Open Neo drafts 203–205 are 2026-09-26 visitor exports, not live owners | None. Do not resume the dead lanes | Two cold sessions, private-data sentinel, later invocation, correction | Those checks on a host that already serves L01 | L11 correspondence after L01 |
| L05 EIN machine activation | EIN PR 168 draft `99e8241ffbe4cbab4a9e1a8e499751fbf2cb7899` on `codex/ein-machine-consolidation-093112`. EIN `main` `31fecfe9fe83f0e234d50b6c0bd1074bf9b90098` | R4 `EIN-ACTIVATION-100140` running since 2026-10-01T08:05:27Z | Host startup and portable cold client. Human pages stay out of this package. No turnaround research in this pass | Assess, prepare, authorized human claim, scoped status, on the existing host | L17 handlers inside the same EIN branch |
| L06 Route Lock | Public `route-lock-0.1.0.tgz` sha `6f1b59e9…70cbf`, 20149 bytes, HTTP 200 at 2026-10-01T08:07:58Z. MIT | R1 `PUBLIC-ENTRY-100137` running since 2026-10-01T08:03:42Z, continuing Neo PR 233 `62df915ba5c96791747ec86a938b18ebbd802005` and Pilot PR 251 | Skill index HTTP 404. Expired receipt must not authorize a later action. `launched` stays false until that receipt says so | Anonymous install, one lock decision, one expired-receipt refusal | Hermes or plain HTTPS caller after R1 hosts the skill files |
| L07 Release Gate | Public `release-gate-0.1.4.tgz` sha `f14eac0c…7bef`, 16254 bytes, HTTP 200. Change-monitor `gate` on this worker exited 0 and bound that sha from a verified cache | R1, same job, because the monitor sidecar still says `sourceQualified: false` while the bytes are public | Sidecar and in-archive README still describe the archive as awaiting deployment | `evaluateRelease` on the public bytes; a tampered tree does not bind | P2 change-monitor |
| L08 agent readiness repair | SDS PR 263 draft `3adad4f05ea197ab6eb553e0168571f25d00887f` on `heavy/l08-agent-repair-093076`. Compare against SDS main: ahead 7, behind 12, 96 files, status diverged | R2 `PUBLIC-READINESS-100138` running since 2026-10-01T08:05:03Z | Remove private-git acquisition of Neo PR 230 `de9c23b5d19de30874e432e7ef1193d0d02d6702`. AG6 PR 260 `400bf94c0220` remains an older draft, not the live owner | Cold install without Git credentials, changed-target repair, existing route regression | L15 seller repair after R2 exports the public adapter |
| L09 bounty aggregation | Neo PR 225 draft `09f88605777891f9f5c1d686edeed1b0cffc2b4b` on `heavy/l09-bounty-next-093076`, base `c709c9d88560b4c74809b30532541aa2ab6e1906`, updated 2026-10-01T00:25:02Z. Public pack 1.0.3 sha `fd31b022…87b4`, 434515 bytes | None running. PR 225 is the continuation pin, not a live writer | Live refresh of two sources, open versus closed, economics card that refuses a reward absent from the capture. Status JSON still says hosted acquisition unverified | `packs/bounty-discovery` tests plus one bounded live query. Cached mode does not fetch | P1 package, then P3 as the contributor task |
| L10 observatory | Public page `https://neomorphic.io/labs/agent-economy-observatory/` HTTP 200, 34917 bytes, 2026-10-01. Source tree on Neo main `b25785918d4394dfd1625d997499a060a6ea01b3`: `public/labs/agent-economy-observatory/` and `packages/change-monitor/vendor/s12-observatory/` | None. Neo PR 217 draft `1d9e6eb50ded038acd9511bc689a23f2fbb15eac` (`heavy/s12-observatory-0930`, updated 2026-09-30) must be diffed before any new writer | One maintained projection whose labels match the live APIs. Freshness and coverage stay visible. The demand snapshot's own coverage is `unknown_for_full_window` | A projection read of MoltJobs, x402stats, or the merchant demand document with source outage represented as unavailable | P2 monitoring package |
| L11 task-linked correspondence | Neo `services/correspondence/` present on main `b2578591…`. Cohort 8: optional SDS mount unconfigured (not re-probed here) | None. R3 may read the service; it does not reassign L11 | Conversations attached to a real task, scoped visibility, expiry, later retrieval | Restart retrieval of one task thread without a public social feed | L01 host after the mount decision |
| L12 continuous monitoring | Public `change-monitor-0.1.0.tgz` sha `a5248cac…100f`, 88319 bytes, HTTP 200 at 2026-10-01T08:11:27Z. Status JSON: `launched` false, `paidServiceLaunch` false, `cost.billable` false inside the README | None. Neo PR 221 draft `929dc4b3a8402fab5e4f3dec9c8b26c1b46bad1d` predates the main merge of PR 232 and must be diffed, not duplicated | Sidecar reconciliation (R1), then one changed later observation that is deduped, pausable, and cancellable. Seeded delivery stays `naturalCustomerDemand: false` | `node package/src/cli.mjs gate` then cold-install; unchanged check is not a delivery | P2 package. L19 can consume a change receipt as a measurement input |
| L13 route liquidity | Pilot PR 240 draft `f65cdfcb534b5fbcf5ad10a0062aa287bdb8c9c4` (`heavy/s20-route-compare-ro-0930`) | None | Two comparable read-only routes. Paid trial stays unbudgeted | Read-only comparison with explicit term differences and no spend | After L06 and L10, still P2 in the grand plan |
| L14 agent surface security | SkillGuard remains a separate source (cohort 8 names `ec890ac8811664f5d5a6eb4262cb66c0a9af953e`). Paid review is not a live route in the healthz price map read here | None | Scoped report, independent check, delivery path. No blanket safety score | One seeded defect in, one finding out, customer acceptance still unpaid | After L08 repair evidence exists |
| L15 seller repair | Fed by L08 / R2. Neo PR 230 is the private pin R2 must stop fetching | R2 owns the readiness entry. No separate L15 writer | Reproduce, repair, retest, reusable regression, sponsored versus paid kept distinct | A later consumer runs the regression without the private Neo checkout | The public adapter R2 exports |
| L16 evidence register | Neo PR 230 also carries the L16 handoff at `de9c23b5…`. Public purchase-evidence manifest on the merchant returned HTTP 200 (26418 bytes) at 2026-10-01 | R2 consumes the interface. No new evidence writer | Correction and revocation on a record a later caller can read. Referral stays opt-in | Revoked record cannot authorize; unknown payer stays unknown | L19 joins and the receipt referral only after a scoped record exists |
| L17 EIN extensions | Inside EIN PR 168, which stacks the earlier 164/165 work per the phase plan | R4 | Catalog matches live handlers. Human-page diffs stay out | Cold client examples for assess and scoped status | Same branch as L05 |
| L18 buyer mandate | Neo PR 223 draft `7089d5525e66f38fb21ff15bb34eaf40f7c9d6ac` on `heavy/l18-buyer-mandate-093076`, updated 2026-10-01T07:46:38Z. Job `MANDATE-CURRENT-CALLER-100128` is `done`, local head matches | None running. The done job is the receiving pin | Real-clock expiry, correction, revocation, restart. Historical evidence does not become new authority | Scoped no-spend caller refuses an expired or revoked record | A later paid execution only after that refusal is the default |
| L19 discovery to settlement joins | Live `https://agents.samedaydesk.com/v0/commerce-demand.json` at 2026-10-01T08:09:13.008Z. Merchant master `e0880cce…` | R5 for the journey. Measurement plane is already public and is not a new warehouse | Independent repeat paid success is 0 in this incomplete window. Source labels stay user-agent observations | A named experiment can point at one route and read these counters without inferring a person from a wallet | D2 falsifier and R5's useful-output receipt |
| L20 composition and knowledge transfer | Pilot PR 235 draft `d524bd43dc86fcbe716de0032ae2d6c8fcc3425a` (`heavy/vf14-integration-knowledge-0926`). Grand plan keeps negative VF13 evidence | None | A changed later task that includes review cost. Negative results stay | Benchmark refuses a claim of savings when the later task shows none | Only a surviving delta, after P3 or P2 shows reuse |

## Preserved retired and dead rows

Copied from `LAUNCH-0930/COVERAGE.md` as it stood at 2026-09-30T16:10Z.
This pass did not reopen them and did not re-read each underlying artifact.
Map value remains `retired` or `dead-no-resume`.

| Source | Ledger pin | Map | Why it stays |
| --- | --- | --- | --- |
| SDS-3 | reserve.json row 40 | retired | A2A card redirect to the designated gateway is allowed. Apex MCP versus gateway A2A stays documented. No dispatch |
| DIS-1 | reserve.json row 60 | retired | No registry title-only edit and no second server name |
| DIS-5 | reserve.json row 64 | retired | Agentverse handle lapses. No restore and no new mint |
| X-RETIRE-1 | reserve.json row 85 | retired | Findings 51–66 collected; the ledger says PR 69 merged |
| X-RETIRE-2 | reserve.json row 86 | retired | Re-dispatch of eight finish-family fixes whose heads already matched |
| X-RETIRE-3 | reserve.json row 87 | retired | Rebuilds of leaves folded into earlier PRs |
| X-RETIRE-4 | reserve.json row 88 | retired | Quota-fill families and the W5 112-row reserve |
| X-RETIRE-5 | reserve.json row 89 | retired | Periodic collector ticks, superseded by the automation lane |
| X-RETIRE-6 | reserve.json row 90 | retired | Registry title-only edit and directory submissions |
| X-RETIRE-7 | reserve.json row 91 | retired | Universal Heavy review before chat, and keyword import of verdicts |
| X-RETIRE-8 | reserve.json row 92 | retired | Relay #8 superseded, reviewed as input only |
| TRK-13 | reserve.json row 122 | retired | EIN edge probe for GPTBot. The ledger records it retired |
| PORT-AG6-b | `9058bac5` | dead-no-resume | Preserved dirty export only. L08's live pin is SDS PR 263, owner R2 |
| VF16-b | `f6de1dba` | dead-no-resume | L04 participation kit. No live owner |
| VF17 | `ad2379be` | dead-no-resume | L04 host qualification. No live owner |

The ledger's count of 12 retired rows is SDS-3, DIS-1, DIS-5, X-RETIRE-1
through X-RETIRE-8, and TRK-13. The three dead lanes are additional and were
already marked no-resume.

## Owners that must not be duplicated

| Job | State at 2026-10-01T08:12Z | Session | Writes |
| --- | --- | --- | --- |
| PUBLIC-ENTRY-100137 (R1) | running | `29791f72-33a0-43a1-8fce-1d965fb6ada5` | Neo PR 233 plus Pilot 251 skill files |
| PUBLIC-READINESS-100138 (R2) | running | `96c1dc15-cc52-4660-b8f5-7229b47b6631` | SDS PR 263 public adapter |
| EARNED-HOST-100139 (R3) | running | `46081737-e98a-4712-a6d5-81674598f5c7` | Neo PR 227 host |
| EIN-ACTIVATION-100140 (R4) | running | `bb526cd8-4022-4928-a7b3-473a53881dfd` | EIN PR 168 |
| PAID-USEFUL-JOURNEY-100141 (R5) | running | `64bd3acd-2748-46f6-a27c-5ae17954c249` | Merchant journey on current master `e0880cce…` |

Terminal predecessors worth receiving, not rewriting: merchant cold discovery
`2276da442a8a69e8053771f93e5e64bce84e12b6` (then merged through `e0880cce…`),
change-monitor `66b3fdf73cfe59c4c158830fdc64df38bb9144ba` (merged as
`b2578591…`), mandate caller `7089d5525e66f38fb21ff15bb34eaf40f7c9d6ac`,
acquisition Pilot 251 `002346702e3284c91dbb03a3f06966e14de165c7`.
