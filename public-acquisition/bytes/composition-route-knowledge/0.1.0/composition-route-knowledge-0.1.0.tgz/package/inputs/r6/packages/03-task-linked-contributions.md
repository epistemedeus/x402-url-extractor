# P3. Task-linked retained contribution

One objective task on the earned-work kernel. R3
(`EARNED-HOST-100139`) is the running host writer. This spec is the task
that writer unlocks. It does not start a second backend, a second signer,
or a payout.

## Repo and paths

| Item | Value |
| --- | --- |
| Repository | `epistemedeus/neomorphic-io` |
| Kernel branch | PR 227 `heavy/i28-heavy-remainder-093090` |
| Head | `4d49fbca49100b56e2986d0187d5191e2abf91fb` (2026-10-01T07:44:10Z) |
| Contributor pack | `packs/contributor-walletless-job/` |
| Bin | `packs/contributor-walletless-job/bin/first-job.mjs` |
| Journey | `packs/contributor-walletless-job/src/journey.mjs` |
| Honesty | `packs/contributor-walletless-job/src/honesty.mjs` |
| Contract pins | `packs/contributor-walletless-job/pins/earned-work-cx.v1.json`, `pins/i01-openapi.json` |
| Blocked by | R3 host export. Cohort 9 input for the portable receive was Neo `4d49fbca…`; the host job continues it |
| Correspondence | `services/correspondence/` may attach the task thread later. It is not the acceptance oracle |
| Artifact the task produces | A bounty-discovery capture accepted by P1 |
| Do not use as the task | Hermes issue 82657, pull 82728, or an x402 #3249 census comment |

Package description at that head: "W5-E06 contributor no-wallet first useful
job with local artifact preflight. List, read hash terms, claim, submit
artifact metadata, reach owed without a payout destination. Nonsettling
prototype." License MIT, copyright 2026 Pilot (epistemedeus), Neomorphic
sample. Node `>=22`. `private: true`.

The public n-bty-003 kit (sha `613df234…12dc`, 13891 bytes, HTTP 200) says
the owner fixture is not a paid claim and tells a contributor to file a
GitHub issue. That issue path is a contradictory submission channel.
P3 uses the kernel receipt only. The kit remains evidence that a well-formed
file is not acceptance.

## Work

1. Wait for R3's receiving-ready host adapter. If that job fails, this
   package stops with the host as the missing fact. Do not stand up Postgres
   elsewhere and do not drop a production schema.
2. Publish one task whose subject is: refresh two existing bounty engines,
   keep open and closed distinct, and produce the capture file P1's tests
   accept. Prerequisites, the 0.10 USDC figure, and the unpaid state are
   visible before claim.
3. Acceptance command is the bounty-discovery test plus the economics exit
   code from P1. An always-accept stub and an always-reject stub must fail
   a fixture test the way `experiments/wave5/e18` already requires on the
   older earned-work tree (useful valid submission succeeds; constant
   verifiers fail). Wire that behavior to this task's verifier. Do not add
   a model call to the verifier.
4. States stay separate: owed, settled, valid delivery, repeat use. The
   journey may reach owed with `paid: false`. Settled becomes true only
   after a funded payout path Root has already disclosed. This assignment
   does not fund it.
5. A second task, genuinely changed, reads the retained capture. The
   measured effect is a changed economics decision or an explicit negative
   ("decision unchanged"). Private owner database rows are not contributor
   input.

## Acceptance

On the contributor pack, against the R3 host URL, with a disposable
contributor token file:

```bash
node --test --test-concurrency=1 packs/contributor-walletless-job/tests/*.test.mjs
node packs/contributor-walletless-job/bin/first-job.mjs journey \
  --base-url "$EARNED_WORK_BASE_URL" \
  --contributor-token-file "$CONTRIBUTOR_TOKEN_FILE"
```

The journey exits 0 only when the receipt says owed and settled is false.
A second process reads the same task id after a restart and sees the same
artifact hash.

Verifier seeded failures:

- A submission that omits the capture file is refused.
- A submission whose economics output labels an uncaptured reward
  `verified` is refused.
- A record that sets Hermes 82657 `demandProof` true is refused by
  `bin/check-decision-record.mjs` (exit 3). That fixture is in this
  research package and is the executable stand-in until the host verifier
  is wired.

## Budget

| Resource | Bound |
| --- | --- |
| Cash now | 0 USD. `funded` is false in `evidence/decisions.json` |
| Disclosed reward | 0.10 USDC, shown as owed, not as paid |
| When it may move | 0.20 then 0.50 USDC only after one accepted result is reused and the funded budget covers the new amount |
| Network | The contributor's two bounded bounty GETs from P1, plus the host calls |
| Model tokens | 0 in the verifier. Contributor model use is their cost and is not reimbursed as token burn |
| Review | The time to run the journey command and the P1 tests |

No launch copy may say the 0.10 USDC is funded before the payout path and
the budget exist. Historical banked revenue (10.955 USDC in the phase plan,
1.027 USDC in the gateway settlement summary) was not re-verified as a
spendable balance here, and this package does not spend it.

## Measurement and stop

Measure: accepted useful result (yes/no), contributor wall time, reviewer
wall time, token-equivalent cost if the contributor reports it, actual cash
(0 until funded), and whether a later task's economics decision changed.

Stop when:

- acceptance requires a person or a model to grade prose, or
- the task text is Hermes 82657 or a generic x402 census, or
- the UI or receipt shows settled while the payout path is absent, or
- the second task's decision is unchanged. Retain the negative capture and
  leave the reward at 0. Do not retune the amount to buy a different answer.

## Consumer

The retained capture is the input to the next P1 economics run and may be
cited by the observatory as a dated source with `claimAuthority: none`.
L11 can attach correspondence to the task id after the receipt exists.
L20 adopts the transfer only when the second task's decision change survives
review cost.
