# Three decisions

Inspection window: 2026-10-01T08:06Z through 2026-10-01T08:12Z. Canonical
machine copy: [evidence/decisions.json](evidence/decisions.json). Pins:
[evidence/live-pins-20261001.json](evidence/live-pins-20261001.json).

Hermes [#82657](https://github.com/NousResearch/hermes-agent/issues/82657)
stays a support-file compatibility issue. GitHub API on 2026-10-01: state
open, updated 2026-08-30T03:40:51Z, labels include `P3` and `type/bug`.
Related pull [#82728](https://github.com/NousResearch/hermes-agent/pull/82728)
is open, unmerged, `mergeable: false`, updated 2026-08-09T21:27:51Z. Latest
release inspected: Hermes Agent v0.21.5, tag `v2026.9.24`, published
2026-09-24T10:09:38Z. None of those facts is a buyer.

## D1. Which install path can consume the public diagnostic now?

**Label: inference.**

**Answer.** An ordinary HTTPS client, or the MCP client that already reads
`GET https://agents.samedaydesk.com/mcp`, can consume the usable public
diagnostic with no new registry, npm package, or skill host. The Hermes
well-known installer is the next skill-index path, and it is blocked on three
static files that running job `PUBLIC-ENTRY-100137` (R1) already owns.

### Facts

- `GET https://agents.samedaydesk.com/mcp` returned HTTP 200 JSON at
  2026-10-01T08:08:30Z. Name `x402-data-gateway`, transport
  `streamable-http`, endpoint `https://agents.samedaydesk.com/mcp`, method
  POST, `toolCount` 24. The only free tool listed is `page_change`
  (`POST /recipes/page-change`, `charged: false`). The same body points at
  payment, manifest, OpenAPI, and purchase-evidence links.
- `GET https://agents.samedaydesk.com/extract?url=https%3A%2F%2Fexample.com`
  returned HTTP 402 at 2026-10-01T08:07:58Z with `x402Version` 2, amount
  `5000` (healthz price `$0.005`), network `eip155:8453`, asset
  `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`, payTo
  `0x8904dF3DE6DFEe6a7C8cc38619d2f17806213Cee`, and `expires`
  `2026-10-01T08:12:58.956Z`. Link headers named purchase-evidence, OpenAPI,
  and `/.well-known/x402`.
- Anonymous downloads returned HTTP 200 and the sha256 values in
  `live-pins-20261001.json` for route-lock 0.1.0, release-gate 0.1.4,
  agent-task-kit 0.1.2, change-monitor 0.1.0, bounty-discovery 1.0.3, and
  n-bty-003 0.1.0.
- `GET https://neomorphic.io/.well-known/skills/index.json` returned HTTP 404
  HTML at 2026-10-01T08:07:57Z. `https://neomorphic.io/llms.txt` (HTTP 200,
  same minute) says this origin does not advertise an MCP server, an A2A
  endpoint, or a live x402 payable route. `https://neomorphic.io/mcp/` is an
  HTML status page whose title says no MCP endpoint is launched there.
- `GET https://agents.samedaydesk.com/.well-known/x402-manifest.json` returned
  HTTP 404 at 2026-10-01T08:07:59Z. The live catalog is
  `/.well-known/x402` (HTTP 200, 60586 bytes in the same minute).

### Inference

The diagnostic a cold caller can use today is the merchant 402 plus the four
public archives. Missing infrastructure for that caller is a URL. Publishing
to the official MCP registry still needs a public npm (or PyPI or NuGet)
package and a namespace proof; route-lock 0.1.0 in the Pilot 251 adapter
notes is `"private": true`, and `https://neomorphic.io/llms.txt` does not
advertise an MCP server. Goose issue
[#11740](https://github.com/aaif-goose/goose/issues/11740) (open, updated
2026-09-16) is a task-registry proposal and does not read a route-lock
receipt. Those paths need more infrastructure than a direct GET.

Pilot PR [#251](https://github.com/epistemedeus/pilot/pull/251) at
`002346702e3284c91dbb03a3f06966e14de165c7` already proved a loopback Hermes
0.19.0 install of a linked `route-lock-receipt` skill. That skill is not on
the public origin. R1's prompt tells that running job to host
`/.well-known/skills/index.json`, the SKILL.md, and the linked script. This
decision does not open a second writer for that host.

### Contradictory evidence

- x402-foundation/x402 [#3249](https://github.com/x402-foundation/x402/issues/3249)
  (open, created 2026-08-24, updated 2026-09-20, 27 comments) asks merchants
  to expose `/.well-known/x402-manifest.json` when a 402 has no payment
  metadata. Our merchant's manifest path 404s, while the same host's 402
  carries payment metadata and `/.well-known/x402` returns 200. A client that
  only fetches the manifest path would miss a payable door. That is a
  compatibility seam for clients written to the issue's proposed path.
- The change-monitor and bounty-discovery status JSON files on the origin
  still say `hostedAcquisitionVerified: false` even though the bytes
  downloaded here match the sha256 those files declare. Cohort 9 already
  recorded the same change-monitor readback. The status sidecar is stale
  relative to the bytes. R1 is assigned to reconcile the monitor sidecar.
  Private-source qualification remains `unavailable` in that status file, and
  this pass does not mark it qualified.
- Inside the change-monitor 0.1.0 tarball, `package/README.md` still says the
  archive is not served from a public URL. The GET above served it.

### Hypothesis

After R1 hosts the three skill files, a machine other than the publishing VM
can install `route-lock-receipt` from the public HTTPS URL and run one
capture. An install count on the publishing VM does not measure that.

## D2. Which paid operation matches a recurring agent job?

**Label: inference.** The falsifier below is a **hypothesis**.

**Answer.** `GET /commerce/seller-integrity-audit` at `$0.01` is the paid
operation whose published contract is a recurring retry: OpenAPI summary on
the live gateway (version string `1.23.49` at 2026-10-01T08:07:59Z) says it
runs after a buyer integration fails, a seller changes the route, or before
the next paid retry or release. Required query fields are `origin` and
`route`.

`GET /extract` at `$0.005` has more historical settlements (18, amountAtomic
`180000`) and is a one-shot page capture. The recurring "did this page
change" job is already the free MCP tool `page_change`. Paying extract does
not become that job.

### Facts

- Healthz `prices` at 2026-10-01T08:07:59Z include `seller-integrity-audit`
  `$0.01`, `extract` `$0.005`, `payment-offer-preflight` `$0.005`,
  `agent-discoverability-audit` `$0.05`. This pass did not change any price.
- Commerce demand snapshot `generatedAt` `2026-10-01T08:09:13.008Z`, coverage
  `unknown_for_full_window`: `paidSuccessActors` 1, `repeatPaidSuccessActors`
  0, `independentPaidSuccessActors` 0, `repeatIndependentPaidSuccessActors` 0.
  `externalEvents` 5875, `externalActors` 468, `repeatExternalActors` 272.
  Agent-discovery observations 6116, of which the public policy text says
  they are user-agent labels and are neither buyer intent nor demand.
  Discovery counts include `/extract` 974 and
  `/commerce/seller-integrity-audit` 864.
- Settlement ledger on the same response: 43 reconciled settlements,
  amountAtomic `1027000` (1.027 USDC at 6 decimals). Classes: unclassified
  30 / `440000`, internal 12 / `577000`, validation 1 / `10000`. No class is
  named independent. Seller-integrity-audit: 6 settlements, amountAtomic
  `60000`. The plan's historical banked figure of 10.955 USDC is a different
  ledger and was not re-verified as spendable here.
- MCP typed outcomes retained from 2026-09-30T05:48:52Z to
  2026-10-01T07:14:48.838Z: 31 records, 16 `challenge`, 15 `invalid`,
  freshness `stale` against a 900000 ms max age. Tools in that slice are
  extract, read, deep_audit, and four singles. Seller-integrity-audit is
  absent from that typed slice.
- The unpaid `/extract` 402 observed in D1 already carries scheme, amount,
  asset, network, payTo, expiry, and resource URL. Offer lifetime on that
  sample was about five minutes.

### Inference

Repeat crawler fetches of paid route URLs are the recurring behavior that is
actually visible. They are satisfied by the free discovery documents. The
paid call that matches a *later retry after a route change* is
seller-integrity-audit, because that is the sentence in its live summary.
Payment-offer-preflight overlaps the same pre-authorization moment and costs
the same `$0.005` as simply repeating the unpaid 402. Discoverability-audit
is a ten-view registry census; another census is outside this assignment.

### Contradictory evidence

- Extract's 18 settlements are the largest route count. A reader who ranks by
  settlement count would pick extract. The route contract and the free
  `page_change` tool argue that those settlements are repeated one-shot
  captures, which the public class breakdown does not split into independent
  buyers.
- Issue 3249's `402_SANS_ACCEPTS` class is a real client dead-end on other
  hosts (the issue and the 2026-09-15 through 2026-09-20 comments describe
  foreign doors, method mismatches, and missing `Allow` headers). Our own
  `/extract` sample is the opposite class: a 402 with payment metadata. The
  issue does not show that anyone paid us to classify those doors.
- Coverage on the demand document is `unknown_for_full_window`. A zero in
  `repeatIndependentPaidSuccessActors` is a zero inside an incomplete window,
  which the document's own policy states must not be read as a historical
  zero for all time. It does falsify "an independent repeat buyer is already
  visible in this snapshot."

### Hypothesis, and the falsifier

First person, no spend: take ten public HTTPS seller routes that answer an
unauthenticated request. Record method, status, and whether payment metadata
parses. Classify each as payable, `402_SANS_ACCEPTS`, free, or method-mismatch
using only that unpaid response.

- If all ten are classifiable from the unpaid response, seller-integrity-audit
  is not required for the recurring pre-retry job on that set. Stop the paid
  experiment.
- If at least one door is ambiguous (metadata present, and method, `Allow`,
  or catalog text disagree), the specific next action is the existing `$0.01`
  audit for that origin and route. Demand is falsified when an independent
  caller is shown that exact next action and submits no payment credential
  before the offer expires, across a pre-registered count of 20 such
  eligible showings, while `repeatIndependentPaidSuccessActors` stays 0.
- Owner tests and unclassified settlements stay labelled. They do not fill
  the independent count.

R5 (`PAID-USEFUL-JOURNEY-100141`, running at 2026-10-01T08:12:27Z) owns the
merchant free-result to existing-paid-operation journey. This decision names
the operation and the falsifier. It does not edit the merchant repo.

## D3. Which contribution reuses the earned-work kernel?

**Label: hypothesis.** The kernel's current pin is a **fact**.

**Answer.** One held-out bounty capture, checked by the existing
bounty-discovery tests and the economics honesty rules, submitted through
`packs/contributor-walletless-job` once R3's host can store owed separately
from settled. Disclosed reward 0.10 USDC. Cash in this record stays 0 until
that path is funded. The task is a second-source refresh that a later
economics card can accept or refuse. It is not a generated essay, and it is
not a patch for Hermes 82657.

### Facts

- Neo PR [#227](https://github.com/epistemedeus/neomorphic-io/pull/227),
  branch `heavy/i28-heavy-remainder-093090`, head
  `4d49fbca49100b56e2986d0187d5191e2abf91fb` (2026-10-01T07:44:10Z), draft,
  open. Package `@neomorphic/contributor-walletless-job` 0.1.0, MIT,
  description: list, read hash terms, claim, submit artifact metadata, reach
  owed without a payout destination. "Nonsettling prototype."
- `EARNED-HOST-100139` was `running` at 2026-10-01T08:12:18Z (session
  `46081737-e98a-4712-a6d5-81674598f5c7`, cloud-b). Its prompt continues that
  same head. This package does not open another earned-work writer.
- Public bounty-discovery 1.0.3 is a dated snapshot pack (`claimAuthority:
  none`). Cached mode replays `captures/`. Live mode does bounded GETs.
  The economics CLI (`experiments/bounty-economics-20260912`) states that
  caller assertions are never labelled verified, and that it does not fetch,
  bid, pay, or settle. Both licenses are MIT.
- N-BTY-003 kit 0.1.0 downloaded with sha256
  `613df234495f926963526928457eb460877908652410b6b16adf09d6481b12dc`. Its
  README says the owner fixture is not a paid claim and that a well-formed
  validator result is not acceptance. `posted: false` remains in the status
  JSON.
- Hermes 82728 already proposes the installer fix. Paying a contributor to
  restate that issue spends the reward on duplicate prose.

### Inference

The kernel can already represent owed without a payout destination. A
contribution that needs a model to decide "useful" recreates the token-burn
problem the reward experiment is supposed to avoid. A process exit on a
capture file does not.

### Contradictory evidence

- The public n-bty-003 kit tells contributors to file a GitHub issue on
  `x402-url-extractor`, which is a different submission path from the
  earned-work kernel. Using both at once would fork the receipt. Package P3
  waits for the kernel host and does not add the GitHub issue path as a
  second acceptance.
- Bounty-discovery's status JSON says hosted acquisition is not claimed. The
  bytes were nonetheless publicly GET-able and matched that file's sha256.
  A contributor task that treats the status flag as "archive missing" would
  be wrong; a task that treats the flag as "launched bounty" would also be
  wrong. `claimAuthority` is `none`.

### Hypothesis

A second capture that changes an economics decision (attempt versus decline)
on a later task is worth the disclosed 0.10 USDC once settlement exists. A
second capture that reproduces the 2026-09-11 cached snapshot without an
open/closed change is a negative result: retain it, pay nothing further, and
do not move the reward to 0.20 or 0.50.
