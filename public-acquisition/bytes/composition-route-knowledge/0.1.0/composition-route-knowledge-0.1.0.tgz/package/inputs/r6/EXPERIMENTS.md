# Ranked experiments

Order follows the phase plan: a broken or almost-deliverable journey first,
then consumers unlocked, then a credible revenue test, then cost. Cash in
every row is the amount this assignment authorizes, which is zero. A later
Root action can fund a row only after its stop rule is still unsatisfied.

| Rank | Id | Question | Cash now | Depends on |
| --- | --- | --- | --- | --- |
| 1 | E1 | Can a machine that is not the publishing VM complete one unpaid diagnosis from a public URL? | 0 | R1 export for the skill files. The merchant 402 can be measured before that |
| 2 | E2 | Does seller-integrity-audit add a fact the unpaid 402 lacks, and does anyone pay the $0.01 when it does? | 0 | R5 may show the next action. This experiment does not buy the audit |
| 3 | E3 | Does a two-source bounty refresh change an economics decision against the 2026-09-11 cache? | 0 | None running. Continue PR 225 rather than a new repo |
| 4 | E4 | Does one objective contribution get accepted and then change a second task? | 0 disclosed, 0.10 USDC only after funding | R3 host |
| 5 | E5 | Does a retained change-monitor receipt beat a one-off archive download on a later task? | 0 | Public tarball already matches its sha. Sidecar reconciliation is R1 |

## E1. Cold completion of a public diagnostic

**Label: hypothesis.** H1 in the phase plan.

Measure discovery, download, first valid call, useful result, and the failure
reason. Count the merchant 402 path and the skill-index path separately.
Downloads alone are not the result. A Hermes support-file miss stays a
compatibility count.

Arms:

1. HTTPS only: GET the merchant MCP descriptor, GET `/extract` for a fixed
   public URL, record whether payment metadata parses and whether the offer
   expiry is still in the future at the caller's clock.
2. After R1: `hermes skills install` of the public SKILL.md from a second
   machine, then one capture. The publishing VM's install does not count.

Stop when 20 external attempts produce zero valid calls, or when every
failure is the already-known 404 on `/.well-known/skills/index.json` before
R1's files are hosted. Refine by fixing that host, not by adding a registry.

Resource: one Node 22 process and public HTTPS. No model tokens required for
the HTTPS arm.

## E2. Falsify paid demand for the recurring audit

**Label: hypothesis.** H2 in the phase plan, bound to one existing SKU.

The operation is `GET /commerce/seller-integrity-audit` at the live price
`$0.01`. The recurring job in its OpenAPI summary is a retry after failure
or after the seller route changes.

Protocol, first person, unpaid:

1. Sample 10 public seller routes. Save status, method, and whether payment
   metadata parses. Do not store raw credentials.
2. If the unpaid body already answers payable versus `402_SANS_ACCEPTS`
   versus method-mismatch, record that the paid audit was not required.
3. Only an ambiguous door (metadata present, and method, `Allow`, or catalog
   text disagree) becomes an eligible showing of the $0.01 next action.

Falsified when 20 eligible showings to independent callers produce zero
payment-credential submissions before offer expiry, and the public counter
`repeatIndependentPaidSuccessActors` is still 0. The 2026-10-01T08:09:13Z
snapshot is already at 0 inside coverage `unknown_for_full_window`, so the
snapshot alone is not the whole falsification.

Stop if the ten unpaid responses are all classifiable: the paid SKU is the
wrong tool for that set. Do not switch the experiment to extract or to a new
census. `page_change` remains the free recurring diff and is not a paid arm.

Resource: 10 unpaid HTTPS calls. The confirmation arm would cost at most
10 × $0.01 and is not authorized here.

Contradictory pull: extract has 18 settlements in the gateway ledger. E2
does not treat that count as independent demand, because the class breakdown
has no independent bucket.

## E3. Bounty refresh against the cached snapshot

**Label: hypothesis.** Detail in
[packages/01-bounty-intelligence.md](packages/01-bounty-intelligence.md).

Two existing engines inside bounty-discovery 1.0.3, `max-pages` 1, open and
closed kept distinct. Economics card must exit 2 when the reward is not in
the capture. No bid, claim, or pay.

Stop when the live rows do not change the cold-user decision relative to
`captures/live-2026-09-11T23-24-00-000Z`, or when the command cannot name
open versus closed. Retain the negative. Do not scrape a sixth directory.

## E4. 0.10 USDC objective contribution

**Label: hypothesis.** H3 in the phase plan. Detail in
[packages/03-task-linked-contributions.md](packages/03-task-linked-contributions.md).

Begin only when R3's host distinguishes owed from settled and a funded
payout path exists. Until then the disclosed amount is an IOU and the
experiment does not launch. Acceptance is a process exit on a held-out
capture. Review effort is the time to run that command, not a model grade.

Move to 0.20 or 0.50 USDC only after an accepted result is reused by a later
task and the funded budget covers it. Hermes 82657 is ineligible subject
matter.

## E5. Retained monitor versus one-off archive

**Label: hypothesis.** H4 in the phase plan. Detail in
[packages/02-observatory-monitoring.md](packages/02-observatory-monitoring.md).

Install the public change-monitor tarball. Subscribe to one source
projection. Run a baseline and one later observation.

Useful delivery is `content_changed` or `service_restored` with `delivered`
true after the receiver accepts it. An unchanged check is not delivery.
Seeded capture stays `naturalCustomerDemand: false`. `cost.billable` stays
false. There is no subscription offer in this experiment.

Stop when the only output is a duplicate of the public observatory page, or
when private Git source is marked qualified. Model-subscription opportunity
cost stays off this cash line.
