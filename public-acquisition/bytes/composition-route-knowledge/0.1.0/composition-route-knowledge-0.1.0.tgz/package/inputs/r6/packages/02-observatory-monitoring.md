# P2. Observatory and monitoring

One maintained projection consumed by the existing change-monitor. The
public archive is already an anonymous download. This package does not
create a subscription, a second observatory, or a writer that races R1's
sidecar reconciliation.

## Repo and paths

| Item | Value |
| --- | --- |
| Repository | `epistemedeus/neomorphic-io` |
| Main pin | `b25785918d4394dfd1625d997499a060a6ea01b3` |
| Package | `packages/change-monitor/` |
| Vendored projection | `packages/change-monitor/vendor/s12-observatory/` (`contract.js`, `envelope.js`, `fetch-observatory.js`, `paid-activity.js`, `projection.js`) |
| Public lab | `public/labs/agent-economy-observatory/` and `https://neomorphic.io/labs/agent-economy-observatory/` (HTTP 200, 34917 bytes, 2026-10-01) |
| Schemas | `packages/change-monitor/schema/event.schema.json`, `subscription.schema.json`, `usage-receipt.schema.json` |
| Drafts to diff before editing | PR 217 `1d9e6eb50ded038acd9511bc689a23f2fbb15eac`; PR 221 `929dc4b3a8402fab5e4f3dec9c8b26c1b46bad1d`. Both are older than the PR 232 merge. Unique deltas may remain; duplicating the package is not the next step |
| Archive | `https://neomorphic.io/downloads/change-monitor/0.1.0/change-monitor-0.1.0.tgz` |

## Facts already checked

Anonymous GET at 2026-10-01T08:11:27Z: HTTP 200, 88319 bytes, sha256
`a5248cac86ae604b365d95e3c21da5c15cd09f1a962428eb7d60b4c3b210100f`.
That matches the sha in the origin's `release-status.json`. The same JSON
says `hostedAcquisitionVerified: false`, `launched: false`,
`paidServiceLaunch: false`, `sourceQualified: false`, and
`privateGitSource: "unavailable"`.

On this worker, after extracting that tarball:

```bash
node package/src/cli.mjs gate
```

exited 0. The JSON reported Release Gate 0.1.4 sha
`f14eac0c4c10bba3f3d8b2e89d6eed1a87f47077bb06a7c70f96409ced9d7bef`,
`acquiredFrom: "verified-cache"`, `extraction: "reused"`,
`executableBound: true`. This was a cache hit, not a fresh network acquire.
The separate GET of the release-gate tarball in `live-pins-20261001.json`
is the network observation.

The in-archive README still says the tarball is not served from a public
URL, and it says `cost.billable` is false, seeded capture has
`naturalCustomerDemand: false`, and subscription JSON cannot name a
destination URL. Delivery is limited to an enrolled `127.0.0.1` or
`localhost` receiver.

License: MIT, copyright 2026 Neomorphic LLC, inside the tarball. Release
Gate is loaded from the pinned public archive. Route Lock is an envelope
pin and is not loaded. A private `packages/release-gate` tree is not used.

## Work

1. Leave R1 to reconcile the acquisition sidecar. Do not set
   `sourceQualified` true while `privateGitSource` is `unavailable`.
2. Diff PR 217 and PR 221 against main. Keep a delta only when it changes
   freshness, correction, or dedup and the main package lacks it.
3. Point one subscription at the vendored S12 projection or at the public
   merchant demand document. Represent `unknown_for_full_window` as
   incomplete coverage, not as zero customers.
4. Implement no scheduler and no homepage price. The README already forbids
   both. A later observation that is byte-identical to the baseline emits
   `unchanged` and no outbox event.
5. Pause and cancel are local subscription states. They do not send.

## Acceptance

```bash
curl -fsSL -o change-monitor-0.1.0.tgz \
  https://neomorphic.io/downloads/change-monitor/0.1.0/change-monitor-0.1.0.tgz
# sha256 must equal a5248cac86ae604b365d95e3c21da5c15cd09f1a962428eb7d60b4c3b210100f
tar -xzf change-monitor-0.1.0.tgz -C /tmp/change-monitor-install
node /tmp/change-monitor-install/package/src/cli.mjs gate
node /tmp/change-monitor-install/package/examples/cold-install.mjs --dest /tmp/change-monitor-journey
node --test --test-concurrency=1 /tmp/change-monitor-install/package/test/*.test.mjs
```

Required outcomes from the package README:

| Outcome | Outbox | Counts as useful delivery |
| --- | --- | --- |
| `baseline_established` | no | no |
| `unchanged` | no | no |
| `content_changed` | yes, rerun | only after receiver accept |
| `service_restored` | yes, rerun | only after receiver accept |
| `evidence_unavailable` | yes, do not treat as zero | a retained negative, not a customer |

Seeded failure: a tampered or partial Release Gate tree must not bind
(`executableBound` stays false). A subscription that contains a remote URL
must be rejected. `delivered` stays false for pending, failed, and unknown
sends. An unknown send is reconciled, not replayed.

## Budget

| Resource | Bound |
| --- | --- |
| Cash | 0 USD. `cost.billable` remains false. No SKU |
| Network | The public archive GET, Release Gate 0.1.4 GET on a cache miss, and one projection read |
| Model tokens | 0 on the acceptance path |
| Disk | The 88319 byte archive plus the Release Gate cache |

Operator time to read a receipt is the review cost and is recorded as time,
not folded into a fake USDC price.

## Measurement and stop

E5 measures a later task that consumes the receipt: did the caller avoid a
repeated failure, and how many seconds did review take, compared with
reading the observatory page alone.

Stop when:

- the run marks seeded output as customer demand or sets `paidServiceLaunch`
  true, or
- private Git source is described as qualified, or
- the only events are `unchanged` and `baseline_established` across two
  later observations of the same projection. Retain that negative. Do not
  add a subscription to manufacture a delivery.

## Consumer

L19 can attach a change receipt to the existing commerce-demand snapshot as
a measurement note. The seller-integrity falsifier (E2) may use a
`content_changed` event on a seller route as the trigger for an unpaid
re-read. It does not auto-purchase the $0.01 audit.

R1 remains the owner of the sidecar text. P2 starts after that sidecar
matches the bytes, or explicitly records that the bytes are public while
source qualification is still unavailable.
