# P1. Bounty intelligence and economics

Continuation of L09. No new repository and no new writer while this record
is the only output. The next admitted writer continues Neo PR 225.

## Repo and paths

| Item | Value |
| --- | --- |
| Repository | `epistemedeus/neomorphic-io` |
| Default branch pin | `b25785918d4394dfd1625d997499a060a6ea01b3` (2026-10-01T07:20:38Z) |
| Continue | PR 225, `heavy/l09-bounty-next-093076`, `09f88605777891f9f5c1d686edeed1b0cffc2b4b` |
| PR base at last update | `c709c9d88560b4c74809b30532541aa2ab6e1906` (behind current main; rebase is the writer's first check, not a silent discard) |
| Feed | `packs/bounty-discovery/` |
| Economics | `experiments/bounty-economics-20260912/` |
| Public bytes | `https://neomorphic.io/downloads/bounty-discovery/bounty-discovery-1.0.3.tar.gz` |
| Observed sha256 | `fd31b0224a0abd733bfde042cdbd08e6af29849adad1910ab895b7fdb05587b4` (434515 bytes, HTTP 200, 2026-10-01) |
| Pilot overlap | Pilot PR 241 `heavy/s05-r02-integrate-0930` at `651d1b9c019e2d4e95042e422eb8a164da25b727` is an earlier feed note. Do not merge it wholesale into Neo |

Cached captures already in the pack include agentbounties, bountyhub
(marked unsupported in the filename), gibwork, gofrantic, superteam, and
taskmarket, under `captures/live-2026-09-11T23-24-00-000Z/`. The refresh
uses two of those engines. It does not add a directory.

## Reused code and license

Both trees are MIT, copyright 2026 Pilot (epistemedeus), Neomorphic sample.
`packs/bounty-discovery/package.json` is `@neomorphic/bounty-discovery`
1.0.3, `private: true`, Node `>=22`, `claimAuthority: none`. The economics
README says the CLI does not fetch, bid, pay, or settle, and that caller
assertions are never labelled verified.

Dependencies: Node 22 standard library and the pack's existing local
modules. No new npm dependency. No private Git checkout on the caller path.
The public tarball is the acquisition path; the status JSON still says
`hostedAcquisitionVerified: false`, so the writer records the dated GET
rather than flipping that flag without a second anonymous readback.

## Work

1. Rebase or replay PR 225 onto current main and keep its live-GET persistence
   only where tests still pass.
2. `node bin/query.mjs snapshot --mode cached --now 2026-09-11T23:24:00.000Z`
   must match the existing snapshot contract
   `neomorphic.bounty-discovery.snapshot.v1`.
3. One live query, `--max-pages 1`, against two engines that already have
   parsers. Store open and closed as different states. A missing source is
   `unavailable`, not an empty marketplace.
4. Feed one observed card and one card whose reward is absent from the
   capture into `experiments/bounty-economics-20260912`. Unknown stays
   unknown. Token-price and review-time fields stay caller-supplied inputs
   with an `assumption` label.
5. Cold next action is a local command line, not a bid URL.

## Acceptance

From `packs/bounty-discovery` on Node 22:

```bash
node --experimental-strip-types --disable-warning=ExperimentalWarning --test --test-concurrency=1 tests/*.test.mjs
node bin/query.mjs snapshot --mode cached --now 2026-09-11T23:24:00.000Z
```

Cached mode must reject a fetch implementation (the README states this).
Live mode is a separate command with `--max-pages 1` and must name two
sources plus at least one open and one closed row, or an explicit
`unavailable` for a source that did not answer.

From `experiments/bounty-economics-20260912`:

```bash
node --test --test-concurrency=1 test/*.test.mjs
```

A card whose reward is not in the capture exits 2. Exit 0 is reserved for a
point estimate whose critical fields are in the capture. Exit 1 is a partial
card with EV suppressed.

Seeded failure already required by the current economics contract: a caller
label of `verified` on an uncaptured reward is invalid input.

## Budget

| Resource | Bound |
| --- | --- |
| Cash | 0 USD. No bid, claim, or x402 payment |
| Network | At most one page on each of two existing sources |
| Model tokens | 0 for the acceptance path. The tests are deterministic |
| Review | One person runs the two test commands and reads the open/closed counts |

## Measurement and stop

Measurement is the cold-user decision before and after the live capture:
attempt, verify-first, or decline, plus the hinge field. E3 in
[EXPERIMENTS.md](../EXPERIMENTS.md) is this measurement.

Stop when:

- live mode cannot separate open from closed, or
- the economics module emits `verified` for a caller assertion, or
- the decision matches the 2026-09-11 cached deck and no later task reads
  the new capture.

Refine only by fixing a parser that dropped a closed row. Do not add a sixth
source to chase a different answer. Do not raise a reward. The 0.10 USDC
contributor path is P3 and stays unfunded.

## Consumer

P3 submits one capture this package accepts. The observatory page may cite
the snapshot as a dated source. It does not become a second bounty product.
