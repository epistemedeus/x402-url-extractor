# Dependencies

Node.js 22 or newer. No npm packages.

| Piece | How a cold copy gets it | License |
| --- | --- | --- |
| This directory | The versioned tarball, after Neomorphic hosts it. | MIT, `LICENSE`. |
| `s20-route-compare-ro` | Vendored inside the tarball at `vendor/s20-route-compare-ro`. In this repository it is the sibling directory. | MIT. Node built-ins only. |
| Route-cost evaluator `997756cceb0aff3caffcaa689fad3571f4cc270b` | Not included and not imported. | No LICENSE file. Not a public dependency. |
| VF14 solver harness and `freeze/` | Not included. The measured result is `knowledge/original-result.json`. | The result is a citation. The frozen archive stays in the source repository. |
| R6 inputs | `inputs/r6/`, hashed by `inputs/r6-pin.json`. | Decision records from the assigned relay copy. |

`npm install` is not required. GitHub credentials are not required.
