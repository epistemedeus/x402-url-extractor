# Composition route knowledge

Read-only consumer for one later task. It cites the verified VF14
compatibility result and compares quote terms. It does not rank routes,
publish a price, spend, sign, or take custody.

## Inputs that already landed

Pilot240 `f65cdfcb534b5fbcf5ad10a0062aa287bdb8c9c4` is the quote inspector in
`experiments/s20-route-compare-ro`. One local amendment: a matched disclosed
basis reports `omittedComponents` as `excluded_not_priced` instead of
`incomparable`.

Pilot235 `d524bd43dc86fcbe716de0032ae2d6c8fcc3425a` has no unique code delta
left to apply. Its comparison blob and freeze blob are already on main. Main
also has the later sandbox and RPC classifier, which that commit does not.
Those files stay. This package cites the measured result and does not edit
`freeze/`.

R6 text is the relay copy `control/inputs/R6-100142` from Pilot252
`c9d479960aefaf4448bc92ec75a60806259ac32d`, stored under `inputs/r6/` with
`inputs/r6-pin.json`. L13 asks for a read-only comparison. L20 asks for a
changed later task that includes review cost and refuses a savings claim the
later task did not measure.

## Later task

The original verified class is `different-adapter`: reuse returned JSON-RPC
`-32602` for non-object params; direct returned `-32600` and missed that
fault. Preflight admitted none of the five classes. Cash is null.

The later task is `read-only-quote-comparison`. It is a different consumer.
The packet is not applied. Adaptation and review steps are the ones this
process actually runs, with measured elapsed milliseconds. `savingsObserved`
stays false. A request that declares savings, or that replays a VF14 class
id as reuse, is refused.

Quote ids and provenance stay on the decision. Unknown fee, interval, or
topology abstains with a next check. A stale or not-yet-effective quote is
judged at this process's clock. A changed quote id does not keep the previous
decision current. Revoking the retained record blocks application of the
packet. Support-file hash mismatches and authority fields (`wallet`, `signer`,
`spend`, and the same family) refuse the request.

## Run

From this directory, on Node 22:

```bash
node bin/decide.mjs self-check
node --test --test-concurrency=1 test/*.test.mjs
node bin/decide.mjs inspect --case ../s20-route-compare-ro/fixtures/cases/live-x402-vs-payai.json
```

Retention is a directory another process can read:

```bash
node bin/decide.mjs retain --store /tmp/composition-store
node bin/decide.mjs changed-task --store /tmp/composition-store --request request.json
node bin/decide.mjs show --store /tmp/composition-store
```

`export/NEOMORPHIC-RECEIVING.json` is the single host action. This repository
is the source, not the public download host.

`evidence/public-readback.json` is one bounded GET of the four documented
support catalogs. PayAI's body hash moved and its terms, after ignoring
`recentBlockhash` and `lastValidBlockHeight`, did not. The frozen captures
were not rewritten. The catalogs are still not operation quotes.
