import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { cp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import test from "node:test";

import { seededFailureRequest } from "../../change-monitor/vendor/s12-observatory/projection.js";
import {
  cancelTask,
  deliverTask,
  openTask,
  pauseTask,
  reconcileTask,
  resumeTask,
  unpauseTask,
  vendorDir,
} from "../src/compose.mjs";
import { RetainedError } from "../src/errors.mjs";
import { verifyProjectionTree } from "../src/provenance.mjs";
import {
  LATER,
  NOW,
  cliPath,
  completeWindow,
  packageRoot,
  projectReading,
  readJson,
  receivers,
  repoRoot,
  startReceiver,
  tempHome,
  writeJson,
  x402Reading,
} from "./support.mjs";

function noCustomerNumber(receipt) {
  assert.equal(receipt.decision.customers, null);
  assert.equal(receipt.decision.payment.executed, false);
  assert.equal(receipt.decision.payment.billable, false);
  assert.equal(receipt.decision.payment.sku, null);
  assert.equal(receipt.decision.payment.price, null);
  assert.equal(receipt.observation.naturalCustomerDemand, false);
  assert.equal(receipt.effort.measured, true);
  assert.equal(Number.isInteger(receipt.effort.totalMs), true);
  const encoded = JSON.stringify(receipt);
  assert.equal(encoded.includes('"customers":0'), false);
  assert.equal(encoded.includes('"customers": 0'), false);
  assert.equal(encoded.includes('"paidCustomers":0'), false);
}

async function openMerchant(home, document, now = NOW) {
  return openTask(home, {
    task: "hold-sellers",
    source: "x402stats",
    owner: "ordinary-agent",
    now,
    document,
    receivers,
  });
}

test("archive bytes and sidecar qualification stay put", async () => {
  const archive = path.join(repoRoot, "public/downloads/change-monitor/0.1.0/change-monitor-0.1.0.tgz");
  const bytes = await readFile(archive);
  assert.equal(createHash("sha256").update(bytes).digest("hex"), "a5248cac86ae604b365d95e3c21da5c15cd09f1a962428eb7d60b4c3b210100f");
  assert.equal(bytes.length, 88319);
  const status = JSON.parse(await readFile(path.join(repoRoot, "public/downloads/change-monitor/0.1.0/release-status.json"), "utf8"));
  assert.equal(status.publicationStatus, "candidate");
  assert.equal(status.launched, false);
  assert.equal(status.sourceQualified, false);
  assert.equal(status.privateGitSource, "unavailable");
  assert.equal(status.ownerPayment, false);
  const installed = verifyProjectionTree(vendorDir());
  assert.equal(installed.ok, true);
  assert.equal(installed.commit, "1d9e6eb50ded038acd9511bc689a23f2fbb15eac");
});

test("tampered and incomplete projection trees are rejected before a decision", async () => {
  const dir = await tempHome("retained-tree-");
  try {
    const copy = path.join(dir.home, "vendor");
    await cp(vendorDir(), copy, { recursive: true });
    const projection = path.join(copy, "projection.js");
    const original = await readFile(projection);
    await writeFile(projection, Buffer.concat([original.subarray(0, original.length - 1), Buffer.from([original[original.length - 1] ^ 0xff])]));
    assert.throws(() => verifyProjectionTree(copy), { name: "RetainedError", code: "tampered_dependency" });
    await writeFile(projection, original);
    await rm(path.join(copy, "envelope.js"));
    assert.throws(() => verifyProjectionTree(copy), { name: "RetainedError", code: "incomplete_source" });
  } finally {
    await dir.cleanup();
  }
});

test("a changed or unavailable merchant reading repairs, and an unchanged reading is a valid negative", async () => {
  const dir = await tempHome("retained-later-");
  try {
    const baselineProjection = projectReading(x402Reading({ sellers: 10 }));
    const opened = await openMerchant(dir.home, baselineProjection);
    assert.equal(opened.observation.outcome, "baseline_established");
    assert.equal(opened.observation.eventId, null);
    assert.equal(opened.observation.outboxEvents, 0);
    assert.equal(opened.feedsNextDecision.action, "hold_baseline");
    assert.equal(opened.decision.coverage, "unknown");
    assert.equal(opened.decision.incompleteEvidence, true);
    assert.equal(opened.decision.merchantDemandSource, "x402stats");
    noCustomerNumber(opened);
    const stateText = await readFile(path.join(dir.home, "monitor.json"), "utf8");
    assert.equal(stateText.includes("http://"), false);
    assert.equal(stateText.includes("webhook"), false);

    const sameClock = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: NOW,
      document: projectReading(x402Reading({ sellers: 10, fetchedAt: LATER }), LATER),
    });
    assert.equal(sameClock.observation.outcome, "unchanged");
    assert.equal(sameClock.observation.eventId, null);
    assert.equal(sameClock.observation.outboxEvents, 0);
    assert.equal(sameClock.negative.valid, true);
    assert.equal(sameClock.negative.preventsWork, true);
    assert.equal(sameClock.negative.demandReading, "unchanged_negative");
    assert.equal(sameClock.negative.completeZeroDemand, false);
    assert.equal(sameClock.observation.seeded, false);
    assert.equal(sameClock.observation.publicSourceChanged, false);
    assert.equal(sameClock.feedsNextDecision.warrant, "negative");
    assert.equal(sameClock.feedsNextDecision.action, "no_work");
    noCustomerNumber(sameClock);

    const journal = await readJson(path.join(dir.home, "journal.json"));
    journal.tasks["hold-sellers"].lastFingerprint = "stale-fingerprint";
    await writeFile(path.join(dir.home, "journal.json"), `${JSON.stringify(journal, null, 2)}\n`);
    const negativeDespiteDecision = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: NOW,
      document: baselineProjection,
    });
    assert.equal(negativeDespiteDecision.observation.outcome, "unchanged");
    assert.equal(negativeDespiteDecision.decision.decisionChanged, true);
    assert.equal(negativeDespiteDecision.negative.valid, true);
    assert.equal(negativeDespiteDecision.negative.preventsWork, true);
    assert.equal(negativeDespiteDecision.observation.outboxEvents, 0);
    noCustomerNumber(negativeDespiteDecision);

    const unavailable = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: LATER,
      document: projectReading(x402Reading({ availability: "unavailable", sellers: 0 }), LATER, baselineProjection),
    });
    assert.equal(unavailable.observation.outcome, "evidence_unavailable");
    assert.equal(unavailable.feedsNextDecision.action, "repair_reading");
    assert.equal(unavailable.feedsNextDecision.paymentExecuted, false);
    assert.equal(unavailable.materialChange.unavailable, true);
    assert.equal(unavailable.materialChange.customers, null);
    assert.equal(unavailable.observation.seeded, false);
    assert.equal(unavailable.observation.publicSourceChanged, false);
    noCustomerNumber(unavailable);
    const unavailableState = await readJson(path.join(dir.home, "monitor.json"));
    assert.equal(unavailableState.evidence[unavailable.observation.evidenceId].material, null);

    const stillDown = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: LATER,
      document: projectReading(x402Reading({ availability: "unavailable", sellers: 0 }), LATER, baselineProjection),
    });
    assert.equal(stillDown.observation.outcome, "unchanged");
    assert.equal(stillDown.negative.valid, true);
    assert.equal(stillDown.feedsNextDecision.action, "no_work");
    assert.equal(stillDown.observation.outboxEvents, 1);
    noCustomerNumber(stillDown);
  } finally {
    await dir.cleanup();
  }
});

test("a seeded seller mutation is an unpaid re-read and is not an external customer change", async () => {
  const dir = await tempHome("retained-seed-");
  try {
    const baseline = projectReading(x402Reading({ sellers: 10, coverage: completeWindow }));
    const opened = await openMerchant(dir.home, baseline);
    assert.equal(opened.decision.coverage, "complete");
    assert.equal(opened.decision.customers, null);
    const seeded = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: LATER,
      document: baseline,
      seedKey: "sellers_30d",
    });
    assert.equal(seeded.observation.outcome, "content_changed");
    assert.equal(seeded.observation.seeded, true);
    assert.equal(seeded.observation.publicSourceChanged, false);
    assert.equal(seeded.observation.observedExternalChange, false);
    assert.equal(seeded.feedsNextDecision.action, "unpaid_reread");
    assert.equal(seeded.feedsNextDecision.paymentExecuted, false);
    assert.equal(seeded.materialChange.changedKeys.some((row) => row.key === "sellers_30d"), true);
    assert.equal(seeded.decision.decisionChanged, true);
    noCustomerNumber(seeded);
    const again = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: LATER,
      document: baseline,
      seedKey: "sellers_30d",
    });
    assert.equal(again.observation.outcome, "unchanged");
    assert.equal(again.negative.valid, true);
    assert.equal(again.observation.outboxEvents, 1);

    const corrected = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: LATER,
      document: baseline,
      correctsEvidenceId: seeded.observation.evidenceId,
    });
    assert.equal(corrected.materialChange.correctsEvidenceId, seeded.observation.evidenceId);
    assert.equal(corrected.observation.seeded, false);
    assert.equal(corrected.feedsNextDecision.paymentExecuted, false);
    const state = await readJson(path.join(dir.home, "monitor.json"));
    assert.equal(state.events[seeded.observation.eventId].capture, "seeded");
    assert.equal(state.events[corrected.observation.eventId].correctsEvidenceId, seeded.observation.evidenceId);
    assert.notEqual(state.events[seeded.observation.eventId].materialDigest, state.events[corrected.observation.eventId].materialDigest);
  } finally {
    await dir.cleanup();
  }
});

test("partial coverage and a seeded market-wide sum do not become zero customers", async () => {
  const dir = await tempHome("retained-partial-");
  try {
    const partial = await openMerchant(dir.home, projectReading(x402Reading({ sellers: 0, dropOrganic: true })));
    assert.equal(partial.observation.outcome, "evidence_unavailable");
    assert.equal(partial.feedsNextDecision.action, "repair_reading");
    assert.equal(partial.decision.coverage, "unknown");
    noCustomerNumber(partial);
    const state = await readJson(path.join(dir.home, "monitor.json"));
    assert.equal(state.evidence[partial.observation.evidenceId].material, null);
    assert.equal(JSON.stringify(state.events).includes('"transition":"content_changed"'), false);

    const home2 = await tempHome("retained-sum-");
    try {
      const rejected = await openTask(home2.home, {
        task: "reject-sum",
        source: "x402stats",
        owner: "ordinary-agent",
        now: NOW,
        document: seededFailureRequest(),
        receivers,
      });
      assert.equal(rejected.observation.outcome, "evidence_unavailable");
      assert.equal(rejected.materialChange.failureCode, "mixed_population_sum");
      assert.equal(rejected.feedsNextDecision.action, "repair_reading");
      noCustomerNumber(rejected);
      const sumState = await readJson(path.join(home2.home, "monitor.json"));
      assert.equal(sumState.evidence[rejected.observation.evidenceId].nonSemantic.total, null);
      assert.equal(sumState.evidence[rejected.observation.evidenceId].nonSemantic.marketWideTraffic, null);
      assert.equal(Object.values(sumState.events).some((event) => event.transition === "content_changed"), false);
    } finally {
      await home2.cleanup();
    }
  } finally {
    await dir.cleanup();
  }
});

test("concurrent checks dedup to one outbox event", async () => {
  const dir = await tempHome("retained-race-");
  try {
    const baseline = projectReading(x402Reading({ sellers: 10 }));
    await openMerchant(dir.home, baseline);
    const changed = projectReading(x402Reading({ sellers: 12, fetchedAt: LATER }), LATER);
    const [left, right] = await Promise.all([
      resumeTask(dir.home, { task: "hold-sellers", now: LATER, document: changed }),
      resumeTask(dir.home, { task: "hold-sellers", now: LATER, document: changed }),
    ]);
    const outcomes = [left.observation.outcome, right.observation.outcome].sort();
    assert.deepEqual(outcomes, ["content_changed", "unchanged"]);
    assert.equal(left.observation.outboxEvents, 1);
    assert.equal(right.observation.outboxEvents, 1);
    const ids = [left, right].map((receipt) => receipt.observation.eventId).filter(Boolean);
    assert.equal(ids.length, 1);
    noCustomerNumber(left);
    noCustomerNumber(right);
  } finally {
    await dir.cleanup();
  }
});

test("restart, pause, and cancel use the monitor contracts", async () => {
  const dir = await tempHome("retained-control-");
  try {
    const baseline = projectReading(x402Reading({ sellers: 10 }));
    await openMerchant(dir.home, baseline);
    const restarted = await resumeTask(dir.home, { task: "hold-sellers", now: LATER, document: baseline });
    assert.equal(restarted.observation.outcome, "unchanged");
    await pauseTask(dir.home, { task: "hold-sellers", now: LATER });
    const paused = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: LATER,
      document: projectReading(x402Reading({ sellers: 20, fetchedAt: LATER }), LATER),
    });
    assert.equal(paused.observation.outcome, "paused");
    assert.equal(paused.feedsNextDecision.action, "admission_refused");
    assert.equal(paused.negative, null);
    assert.equal(paused.observation.outboxEvents, 0);
    await unpauseTask(dir.home, { task: "hold-sellers", now: LATER });
    const after = await resumeTask(dir.home, { task: "hold-sellers", now: LATER, document: baseline });
    assert.equal(after.observation.outcome, "unchanged");
    await cancelTask(dir.home, { task: "hold-sellers", now: LATER });
    const cancelled = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: LATER,
      document: projectReading(x402Reading({ sellers: 20, fetchedAt: LATER }), LATER),
    });
    assert.equal(cancelled.observation.outcome, "cancelled");
    assert.equal(cancelled.observation.outboxEvents, 0);
    await assert.rejects(
      () => openTask(dir.home, { task: "hold-sellers", source: "https://example.invalid/hook", owner: "ordinary-agent", now: NOW, document: baseline, receivers }),
      (error) => error instanceof RetainedError && error.code === "bad_source",
    );
    await assert.rejects(
      () => openTask(dir.home, { task: "other-task", source: "x402stats", owner: "ordinary-agent", now: NOW, document: baseline, receivers, webhook: "http://127.0.0.1:9/deliver" }),
      (error) => error instanceof RetainedError && error.code === "url_rejected",
    );
  } finally {
    await dir.cleanup();
  }
});

test("unknown delivery is reconciled instead of replayed, and failed stays failed", async () => {
  const dir = await tempHome("retained-delivery-");
  const receiver = await startReceiver();
  const enrolled = { "local-vm": { kind: "local-http", baseUrl: receiver.baseUrl } };
  try {
    const baseline = projectReading(x402Reading({ sellers: 10 }));
    await openTask(dir.home, {
      task: "hold-sellers",
      source: "x402stats",
      owner: "ordinary-agent",
      now: NOW,
      document: baseline,
      receivers: enrolled,
    });
    receiver.state.mode = "unknown";
    const changed = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: LATER,
      document: baseline,
      seedKey: "sellers_30d",
      receivers: enrolled,
    });
    assert.equal(changed.delivery.state, "pending");
    const unknown = await deliverTask(dir.home, { task: "hold-sellers", now: LATER, receivers: enrolled });
    assert.equal(unknown.deliveries[0].state, "unknown");
    assert.equal(unknown.deliveries[0].delivered, false);
    assert.equal(receiver.state.posts, 1);
    const replay = await deliverTask(dir.home, { task: "hold-sellers", now: LATER, receivers: enrolled });
    assert.deepEqual(replay.deliveries, []);
    assert.equal(receiver.state.posts, 1);
    const reconciled = await reconcileTask(dir.home, { task: "hold-sellers", now: LATER, receivers: enrolled });
    assert.equal(reconciled.reconciled[0].state, "accepted");
    assert.equal(reconciled.reconciled[0].delivered, true);
    assert.equal(receiver.state.posts, 1);

    const next = projectReading(x402Reading({ sellers: 30, fetchedAt: LATER }), LATER);
    const second = await resumeTask(dir.home, {
      task: "hold-sellers",
      now: LATER,
      document: next,
      receivers: enrolled,
    });
    assert.equal(second.observation.outcome, "content_changed");
    assert.equal(second.observation.seeded, false);
    receiver.state.mode = "fail";
    const failed = await deliverTask(dir.home, { task: "hold-sellers", now: LATER, receivers: enrolled });
    assert.equal(failed.deliveries[0].state, "failed");
    assert.equal(failed.deliveries[0].delivered, false);
    receiver.state.mode = "accept";
    const stillFailed = await reconcileTask(dir.home, { task: "hold-sellers", now: LATER, receivers: enrolled });
    assert.deepEqual(stillFailed.reconciled, []);
    const stored = await readJson(path.join(dir.home, "monitor.json"));
    const states = Object.values(stored.deliveries).map((row) => row.state).sort();
    assert.deepEqual(states, ["accepted", "failed"]);
  } finally {
    await receiver.close();
    await dir.cleanup();
  }
});

test("a second process consumes the retained negative", async () => {
  const dir = await tempHome("retained-proc-");
  try {
    const baseline = projectReading(x402Reading({ sellers: 10 }));
    const capture = path.join(dir.home, "capture.json");
    await writeJson(capture, baseline);
    await openMerchant(dir.home, baseline);
    const child = await runCli([
      "resume",
      "--home", dir.home,
      "--task", "hold-sellers",
      "--file", capture,
      "--now", LATER,
    ]);
    assert.equal(child.code, 0, child.stderr);
    const receipt = JSON.parse(child.stdout);
    assert.equal(receipt.observation.outcome, "unchanged");
    assert.equal(receipt.negative.valid, true);
    assert.equal(receipt.feedsNextDecision.action, "no_work");
    assert.equal(receipt.observation.outboxEvents, 0);
    assert.equal(receipt.decision.customers, null);
    const shown = await runCli(["show", "--home", dir.home, "--task", "hold-sellers"]);
    assert.equal(shown.code, 0, shown.stderr);
    assert.equal(JSON.parse(shown.stdout).observation.outcome, "unchanged");
  } finally {
    await dir.cleanup();
  }
});

test("a cold copy of the two packages classifies a capture without the repo root", async () => {
  const dir = await tempHome("retained-cold-");
  try {
    const packages = path.join(dir.home, "packages");
    await mkdir(packages, { recursive: true });
    await cp(path.join(repoRoot, "packages/change-monitor"), path.join(packages, "change-monitor"), { recursive: true });
    await cp(packageRoot, path.join(packages, "retained-task"), {
      recursive: true,
      filter: (source) => !source.includes(`${path.sep}test${path.sep}`),
    });
    const capture = path.join(dir.home, "capture.json");
    await writeJson(capture, projectReading(x402Reading({ sellers: 4 })));
    const home = path.join(dir.home, "home");
    const opened = await runCli([
      "open", "--home", home, "--task", "cold-sellers", "--source", "x402stats",
      "--owner", "ordinary-agent", "--file", capture, "--now", NOW,
      "--receivers", await receiversFile(dir.home),
    ], path.join(packages, "retained-task/src/cli.mjs"));
    assert.equal(opened.code, 0, opened.stderr);
    const again = await runCli([
      "resume", "--home", home, "--task", "cold-sellers", "--file", capture, "--now", LATER,
    ], path.join(packages, "retained-task/src/cli.mjs"));
    assert.equal(again.code, 0, again.stderr);
    const receipt = JSON.parse(again.stdout);
    assert.equal(receipt.negative.valid, true);
    assert.equal(receipt.decision.customers, null);
    assert.equal(receipt.observation.outboxEvents, 0);
  } finally {
    await dir.cleanup();
  }
});

async function receiversFile(home) {
  const file = path.join(home, "receivers.json");
  await writeJson(file, receivers);
  return file;
}

function runCli(args, script = cliPath) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [script, ...args], { cwd: path.dirname(script) });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => {
      stdout += chunk;
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", reject);
    child.on("close", (code) => resolve({ code, stdout, stderr }));
  });
}
