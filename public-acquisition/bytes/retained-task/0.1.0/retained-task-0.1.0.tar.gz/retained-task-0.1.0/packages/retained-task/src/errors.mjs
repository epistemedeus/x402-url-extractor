export class RetainedError extends Error {
  constructor(message, code = "retained_error") {
    super(message);
    this.name = "RetainedError";
    this.code = code;
  }
}
