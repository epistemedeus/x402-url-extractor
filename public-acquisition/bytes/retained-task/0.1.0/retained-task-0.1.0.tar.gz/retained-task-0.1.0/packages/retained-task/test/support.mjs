import { createServer } from "node:http";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { applySourceUpdate, emptyProjection } from "../../change-monitor/vendor/s12-observatory/projection.js";

export const NOW = "2026-10-01T12:00:00.000Z";
export const LATER = "2026-10-01T13:00:00.000Z";
export const packageRoot = fileURLToPath(new URL("..", import.meta.url));
export const cliPath = fileURLToPath(new URL("../src/cli.mjs", import.meta.url));
export const repoRoot = fileURLToPath(new URL("../../..", import.meta.url));

export const receivers = {
  "local-vm": { kind: "local-http", baseUrl: "http://127.0.0.1:9" },
};

function metric(key, value, population) {
  return {
    key,
    value,
    state: "ok",
    unit: key.includes("volume") ? "USD" : "count",
    population,
    window: "30d",
  };
}

export function x402Reading({
  sellers = 10,
  fetchedAt = NOW,
  availability = "ok",
  dropOrganic = false,
  coverage = undefined,
} = {}) {
  const metrics = [
    metric("sellers_30d", sellers, "provider_indexed_sellers"),
    metric("volume_usd_30d", 100, "provider_indexed_volume"),
  ];
  if (!dropOrganic) metrics.push(metric("organic_sellers_30d", 4, "provider_heuristic_organic_sellers"));
  const reading = {
    sourceId: "x402stats",
    sourceKind: "settlement",
    availability,
    fetchedAt,
    providerTimestamp: fetchedAt,
    providerTimestampState: "ok",
    metrics,
  };
  if (coverage !== undefined) reading.coverage = coverage;
  return reading;
}

export const completeWindow = {
  kind: "window",
  complete: true,
  window: "30d",
  population: "provider_indexed_sellers",
  additivity: "not_additive",
};

export function projectReading(reading, observedAt = NOW, prior = null) {
  const base = prior || emptyProjection({ observedAt });
  return applySourceUpdate(base, reading, { observedAt }).projection;
}

export async function tempHome(prefix) {
  const home = await mkdtemp(path.join(tmpdir(), prefix));
  return {
    home,
    async cleanup() {
      await rm(home, { recursive: true, force: true });
    },
  };
}

export async function writeJson(file, value) {
  await writeFile(file, `${JSON.stringify(value, null, 2)}\n`);
}

export async function readJson(file) {
  return JSON.parse(await readFile(file, "utf8"));
}

export function startReceiver() {
  const events = new Map();
  const state = { mode: "accept", posts: 0, gets: 0 };
  const server = createServer((request, response) => {
    const url = new URL(request.url || "/", "http://127.0.0.1");
    if (request.method === "GET" && url.pathname.startsWith("/events/")) {
      state.gets += 1;
      const key = decodeURIComponent(url.pathname.slice("/events/".length));
      if (state.mode === "absent" || !events.has(key)) {
        response.writeHead(404, { "content-type": "application/json" });
        response.end(JSON.stringify({ found: false }));
        return;
      }
      response.writeHead(200, { "content-type": "application/json" });
      response.end(JSON.stringify({ found: true, idempotencyKey: key, event: events.get(key) }));
      return;
    }
    if (request.method === "POST" && url.pathname === "/deliver") {
      const chunks = [];
      request.on("data", (chunk) => chunks.push(chunk));
      request.on("end", () => {
        state.posts += 1;
        let body;
        try {
          body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
        } catch {
          response.writeHead(400, { "content-type": "application/json" });
          response.end(JSON.stringify({ accepted: false, error: "invalid_json" }));
          return;
        }
        const key = request.headers["idempotency-key"];
        if (state.mode === "fail") {
          response.writeHead(400, { "content-type": "application/json" });
          response.end(JSON.stringify({ accepted: false, error: "rejected", idempotencyKey: key }));
          return;
        }
        if (state.mode === "unknown") {
          events.set(key, body.event);
          response.writeHead(500, { "content-type": "application/json" });
          response.end(JSON.stringify({ error: "boom", idempotencyKey: key }));
          return;
        }
        const duplicate = events.has(key);
        events.set(key, body.event);
        response.writeHead(200, { "content-type": "application/json" });
        response.end(JSON.stringify({ accepted: true, duplicate, idempotencyKey: key }));
      });
      return;
    }
    response.writeHead(404);
    response.end();
  });
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      resolve({
        state,
        baseUrl: `http://127.0.0.1:${address.port}`,
        close: () => new Promise((done) => server.close(() => done())),
      });
    });
  });
}
