#!/usr/bin/env node
import { readFile } from "node:fs/promises";

import { receiversFromConfig } from "../../change-monitor/src/receivers.mjs";
import { MonitorError } from "../../change-monitor/src/errors.mjs";

import {
  cancelTask,
  correctTask,
  deliverTask,
  exitCodeFor,
  openTask,
  pauseTask,
  reconcileTask,
  resumeTask,
  showTask,
  unpauseTask,
} from "./compose.mjs";
import { RetainedError } from "./errors.mjs";

function parseArgs(argv) {
  const [command, ...rest] = argv;
  const flags = {};
  for (let index = 0; index < rest.length; index += 1) {
    const token = rest[index];
    if (!token.startsWith("--")) throw new RetainedError(`unexpected argument ${token}`, "bad_args");
    const key = token.slice(2);
    const value = rest[index + 1];
    if (value === undefined || value.startsWith("--")) flags[key] = true;
    else {
      flags[key] = value;
      index += 1;
    }
  }
  return { command, flags };
}

function required(flags, key) {
  if (!flags[key] || flags[key] === true) throw new RetainedError(`--${key} is required`, "bad_args");
  return flags[key];
}

async function readJson(file, label) {
  if (!file || file === true) throw new RetainedError(`${label} file is required`, "bad_args");
  try {
    return JSON.parse(await readFile(file, "utf8"));
  } catch {
    throw new RetainedError(`${label} file is not readable JSON`, "bad_json");
  }
}

function print(value) {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

async function receiversOf(flags) {
  if (!flags.receivers) return {};
  return receiversFromConfig(await readJson(flags.receivers, "receivers"));
}

async function main() {
  const { command, flags } = parseArgs(process.argv.slice(2));
  if (!command || command === "help") {
    print({
      commands: ["open", "resume", "correct", "deliver", "reconcile", "pause", "unpause", "cancel", "show"],
      source: ["moltjobs", "x402stats", "smithery_mcp"],
      merchantDemandSource: "x402stats",
      exits: { ok: 0, rejected: 2, admissionRefused: 3, deliveryUnknown: 4 },
    });
    return 0;
  }
  const home = required(flags, "home");
  const task = required(flags, "task");
  const now = flags.now && flags.now !== true ? flags.now : null;
  const timeoutMs = flags["timeout-ms"] && flags["timeout-ms"] !== true ? Number(flags["timeout-ms"]) : undefined;
  if (command === "show") {
    print(await showTask(home, task));
    return 0;
  }
  if (command === "pause") {
    print(await pauseTask(home, { task, now }));
    return 0;
  }
  if (command === "unpause") {
    print(await unpauseTask(home, { task, now }));
    return 0;
  }
  if (command === "cancel") {
    print(await cancelTask(home, { task, now }));
    return 0;
  }
  const receivers = await receiversOf(flags);
  if (command === "deliver") {
    const result = await deliverTask(home, { task, now, receivers });
    print(result);
    return result.deliveries.some((row) => row.state === "unknown") ? 4 : 0;
  }
  if (command === "reconcile") {
    const result = await reconcileTask(home, { task, now, receivers });
    print(result);
    return result.reconciled.some((row) => row.state === "unknown") ? 4 : 0;
  }
  const document = flags.file ? await readJson(flags.file, "capture") : null;
  const common = {
    task,
    now,
    timeoutMs,
    receivers,
    document,
    live: flags.live === true,
    seedKey: flags["seed-key"] && flags["seed-key"] !== true ? flags["seed-key"] : null,
    owner: flags.owner && flags.owner !== true ? flags.owner : undefined,
    receiverId: flags.receiver && flags.receiver !== true ? flags.receiver : undefined,
    source: flags.source && flags.source !== true ? flags.source : undefined,
  };
  if (command === "open") {
    const receipt = await openTask(home, common);
    print(receipt);
    return exitCodeFor(receipt);
  }
  if (command === "resume") {
    const receipt = await resumeTask(home, common);
    print(receipt);
    return exitCodeFor(receipt);
  }
  if (command === "correct") {
    const receipt = await correctTask(home, { ...common, evidenceId: required(flags, "evidence"), live: false, seedKey: null });
    print(receipt);
    return exitCodeFor(receipt);
  }
  throw new RetainedError(`unknown command ${command}`, "bad_args");
}

main()
  .then((code) => {
    process.exitCode = code;
  })
  .catch((error) => {
    const payload = {
      error: error instanceof Error ? error.message : "failed",
      code: error instanceof RetainedError || error instanceof MonitorError ? error.code : "failed",
    };
    process.stderr.write(`${JSON.stringify(payload)}\n`);
    process.exitCode = 2;
  });
