import { randomBytes } from "node:crypto";
import { mkdir, open, readFile, rename, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  assertProjectionProvenance,
  createMonitor,
  frozenClock,
  openFileStore,
  PUBLIC_SNAPSHOT_URL,
  readMaintainedProjection,
  seedMeaningfulMutation,
  systemClock,
} from "../../change-monitor/src/index.mjs";
import { MonitorError } from "../../change-monitor/src/errors.mjs";

import { assertReceipt, diffMaterial, MERCHANT_DEMAND_SOURCE, RECEIPT_SCHEMA, sellerIntegrityDecision } from "./decision.mjs";
import { RetainedError } from "./errors.mjs";
import { verifyProjectionTree } from "./provenance.mjs";
import { assertAgreesWithMonitorSidecar } from "./qualification.mjs";

const TASK_NAME = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,64}$/;
const OWNER = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,80}$/;
const SOURCES = new Set(["moltjobs", "x402stats", "smithery_mcp"]);
const JOURNAL_SCHEMA = "retained-task.journal.v1";
const VENDOR_DIR = fileURLToPath(new URL("../../change-monitor/vendor/s12-observatory/", import.meta.url));

const journalChains = new Map();

export function vendorDir() {
  return VENDOR_DIR;
}

export function assertInstalledSources() {
  assertProjectionProvenance();
  const projection = verifyProjectionTree(VENDOR_DIR);
  const qualification = assertAgreesWithMonitorSidecar();
  return { ...projection, qualification };
}

function elapsed(started) {
  return Math.max(0, Math.round(performance.now() - started));
}

function boundTimeout(value) {
  if (value == null) return 8000;
  const timeout = Number(value);
  if (!Number.isInteger(timeout) || timeout < 1000 || timeout > 20000) {
    throw new RetainedError("timeoutMs must be an integer from 1000 to 20000", "bad_timeout");
  }
  return timeout;
}

function assertTaskName(task) {
  if (typeof task !== "string" || !TASK_NAME.test(task)) {
    throw new RetainedError("task name must be a short token", "bad_task");
  }
  return task;
}

function assertOwner(owner) {
  if (typeof owner !== "string" || !OWNER.test(owner)) {
    throw new RetainedError("owner must be a short name", "bad_owner");
  }
  return owner;
}

function assertSource(source) {
  if (typeof source !== "string" || source.includes("://") || source.includes("/") || !SOURCES.has(source)) {
    throw new RetainedError("source must be moltjobs, x402stats, or smithery_mcp", "bad_source");
  }
  return source;
}

function rejectCommand(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new RetainedError("command input must be an object", "bad_args");
  }
  for (const key of ["url", "uri", "webhook", "endpoint", "callback", "href"]) {
    if (Object.prototype.hasOwnProperty.call(input, key)) {
      throw new RetainedError(`${key} is not accepted. Destinations stay in the receiver registry.`, "url_rejected");
    }
  }
  if (typeof input.receiverId === "string" && input.receiverId.includes("://")) {
    throw new RetainedError("receiverId is a registry name, not a URL", "url_rejected");
  }
}

function subscriptionIdFor(task) {
  return `rt-${task}`;
}

function emptyJournal() {
  return { schema: JOURNAL_SCHEMA, tasks: {} };
}

async function readJournal(file) {
  try {
    const parsed = JSON.parse(await readFile(file, "utf8"));
    if (!parsed || parsed.schema !== JOURNAL_SCHEMA || !parsed.tasks || typeof parsed.tasks !== "object") {
      throw new RetainedError("journal schema is not retained-task.journal.v1", "journal_schema");
    }
    return parsed;
  } catch (error) {
    if (error && error.code === "ENOENT") return emptyJournal();
    throw error;
  }
}

async function atomicWrite(file, value) {
  const tmp = `${file}.${process.pid}.${randomBytes(4).toString("hex")}.tmp`;
  await writeFile(tmp, `${JSON.stringify(value, null, 2)}\n`);
  await rename(tmp, file);
}

function lockHeld(info) {
  if (!info || !Number.isInteger(info.pid)) return false;
  if (info.pid === process.pid) return true;
  try {
    process.kill(info.pid, 0);
    return true;
  } catch {
    return false;
  }
}

async function acquire(lockPath) {
  const started = Date.now();
  for (;;) {
    try {
      const handle = await open(lockPath, "wx");
      try {
        await handle.writeFile(JSON.stringify({ pid: process.pid, at: new Date().toISOString() }));
      } finally {
        await handle.close();
      }
      return;
    } catch (error) {
      if (!error || error.code !== "EEXIST") throw error;
      let info = null;
      try {
        info = JSON.parse(await readFile(lockPath, "utf8"));
      } catch {
        info = null;
      }
      if (!lockHeld(info)) {
        await unlink(lockPath).catch(() => {});
        continue;
      }
      if (Date.now() - started > 15000) throw new RetainedError("journal lock timed out", "lock_timeout");
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
  }
}

async function withJournal(home, fn) {
  const previous = journalChains.get(home) || Promise.resolve();
  const run = previous.then(async () => {
    const lockPath = path.join(home, "journal.lock");
    await acquire(lockPath);
    try {
      return await fn(path.join(home, "journal.json"));
    } finally {
      await unlink(lockPath).catch(() => {});
    }
  });
  journalChains.set(home, run.then(() => {}, () => {}));
  return run;
}

function normalizeSupplied(document) {
  if (!document || typeof document !== "object" || Array.isArray(document)) {
    throw new RetainedError("supplied capture must be a JSON object", "bad_capture");
  }
  if (document.seeded === true || document.capture === "seeded") {
    return { ...document, capture: "seeded", publicSourceChanged: false };
  }
  return { ...document, capture: "fixture", publicSourceChanged: false, integration: document.integration || "maintained" };
}

function projectionOf(reading) {
  if (!reading || typeof reading !== "object") return null;
  if (reading.projection && reading.projection.projectionId) return reading.projection;
  if (reading.projectionId && Array.isArray(reading.sources)) return reading;
  if (reading.document && reading.document.projectionId) return reading.document;
  return null;
}

function documentForObserve(reading) {
  if (reading && typeof reading === "object" && (
    reading.projection || reading.projectionId || reading.schemaVersion || reading.observations
    || reading.seeded === true || reading.status === "source_failure" || reading.capture
  )) {
    return reading;
  }
  return {
    capture: "live",
    integration: "maintained",
    status: "source_failure",
    failureCode: "source_unreachable",
    reason: null,
    projection: null,
    publicSourceChanged: false,
  };
}

async function readSource({ live, document, seedKey, sourceId, now, timeoutMs, fetchImpl }) {
  const started = performance.now();
  try {
    if (seedKey) {
      if (live) throw new RetainedError("a seeded mutation is not a live public read", "seed_not_live");
      const seeded = seedMeaningfulMutation(normalizeSupplied(document), { sourceId, key: seedKey, now });
      return finishRead(started, seeded, "seeded", null, null, timeoutMs);
    }
    if (live) {
      const reading = await readMaintainedProjection({
        now: () => now,
        timeoutMs,
        fetchImpl,
      });
      return finishRead(started, reading, "live", reading.fetch?.httpStatus ?? null, reading.fetch?.failureKind ?? null, timeoutMs);
    }
    if (document) return finishRead(started, normalizeSupplied(document), "fixture", null, null, timeoutMs);
    throw new RetainedError("a live read or a supplied capture is required", "source_required");
  } catch (error) {
    if (error instanceof MonitorError) throw new RetainedError(error.message, error.code);
    throw error;
  }
}

function finishRead(started, reading, mode, httpStatus, failureKind, timeoutMs) {
  return {
    ms: elapsed(started),
    reading,
    mode,
    httpStatus,
    failureKind,
    timeoutMs,
    url: mode === "live" ? PUBLIC_SNAPSHOT_URL : null,
  };
}

function monitorClock(now) {
  return now ? frozenClock(now) : systemClock();
}

async function openMonitor(home, receivers, now) {
  await mkdir(home, { recursive: true });
  return createMonitor({
    store: await openFileStore(path.join(home, "monitor.json")),
    clock: monitorClock(now),
    receivers: receivers || {},
  });
}

function outboxCount(state, subscriptionId) {
  return Object.values(state.events).filter((event) => event.subscriptionId === subscriptionId).length;
}

function buildReceipt({ task, record, observed, state, read, decision, effort, priorMaterial, now }) {
  const event = observed.eventId ? state.events[observed.eventId] : null;
  const delivery = observed.eventId ? state.deliveries[observed.eventId] : null;
  const capture = event?.capture || read.reading?.capture || read.mode;
  const publicSourceChanged = capture === "live" && observed.outcome === "content_changed";
  const seeded = capture === "seeded";
  const acted = decision.warrant === "act";
  const negative = decision.warrant === "negative";
  let materialChange = null;
  if (acted && observed.outcome === "evidence_unavailable") {
    materialChange = {
      transition: observed.outcome,
      evidenceClass: observed.evidenceClass,
      failureCode: event?.failureCode || state.evidence[observed.evidenceId]?.failureCode || null,
      eventId: observed.eventId,
      correctsEvidenceId: event?.correctsEvidenceId ?? null,
      unavailable: true,
      customers: null,
      changedKeys: [],
      capture,
      seeded,
      publicSourceChanged,
    };
  } else if (acted) {
    materialChange = {
      transition: observed.outcome,
      evidenceClass: observed.evidenceClass,
      eventId: observed.eventId,
      materialDigest: event?.materialDigest ?? null,
      correctsEvidenceId: event?.correctsEvidenceId ?? null,
      changedKeys: diffMaterial(priorMaterial, event?.material || null),
      restored: observed.outcome === "service_restored",
      customers: null,
      capture,
      seeded,
      publicSourceChanged,
    };
  }
  const negativeRecord = negative
    ? {
        valid: true,
        preventsWork: true,
        reason: "unchanged",
        demandReading: "unchanged_negative",
        completeZeroDemand: false,
        decisionChanged: decision.decisionChanged,
        customers: null,
      }
    : null;
  const feedsNextDecision = acted
    ? {
        warrant: "act",
        task,
        action: decision.action,
        materialChange,
        customers: null,
        paymentExecuted: false,
      }
    : negative
      ? {
          warrant: "negative",
          task,
          action: "no_work",
          negative: negativeRecord,
          customers: null,
          paymentExecuted: false,
        }
      : {
          warrant: decision.warrant,
          task,
          action: decision.action,
          customers: null,
          paymentExecuted: false,
        };
  return assertReceipt({
    schema: RECEIPT_SCHEMA,
    task,
    source: record.source,
    owner: record.owner,
    at: now,
    phase: record.openedAt === now && !record.lastReceipt ? "open" : record.phase,
    observation: {
      outcome: observed.outcome,
      evidenceClass: observed.evidenceClass,
      evidenceId: observed.evidenceId,
      eventId: observed.eventId,
      outboxAdmitted: observed.admitted === true,
      outboxEvents: outboxCount(state, record.subscriptionId),
      capture,
      publicSourceChanged,
      seeded,
      observedExternalChange: publicSourceChanged,
      naturalCustomerDemand: false,
      failureCode: materialChange?.failureCode || event?.failureCode || null,
      monitorTask: event?.task || null,
    },
    materialChange,
    negative: negativeRecord,
    decision,
    feedsNextDecision,
    delivery: delivery
      ? { state: delivery.state, delivered: delivery.delivered === true, attempts: delivery.attempts.length }
      : null,
    read: {
      attempted: true,
      mode: read.mode,
      timeoutMs: read.timeoutMs,
      httpStatus: read.httpStatus,
      failureKind: read.failureKind,
      url: read.url,
      elapsedMs: read.ms,
    },
    effort: {
      measured: true,
      unit: "ms",
      readMs: effort.readMs,
      classifyMs: effort.classifyMs,
      reviewMs: effort.reviewMs,
      totalMs: effort.readMs + effort.classifyMs + effort.reviewMs,
    },
  });
}

async function remember(home, task, receipt, patch) {
  return withJournal(home, async (file) => {
    const journal = await readJournal(file);
    const current = journal.tasks[task];
    if (!current) throw new RetainedError("task is not in the journal", "unknown_task");
    const history = Array.isArray(current.history) ? current.history : [];
    history.push({
      at: receipt.at,
      outcome: receipt.observation.outcome,
      warrant: receipt.feedsNextDecision.warrant,
      action: receipt.decision.action,
      eventId: receipt.observation.eventId,
      decisionChanged: receipt.decision.decisionChanged,
      fingerprint: receipt.decision.fingerprint,
    });
    journal.tasks[task] = {
      ...current,
      ...patch,
      phase: receipt.phase,
      lastFingerprint: receipt.decision.fingerprint,
      lastReceipt: receipt,
      history: history.slice(-30),
    };
    await atomicWrite(file, journal);
    return journal.tasks[task];
  });
}

async function requireTask(home, task) {
  const journal = await readJournal(path.join(home, "journal.json"));
  const record = journal.tasks[task];
  if (!record) throw new RetainedError("task is not in the journal", "unknown_task");
  return record;
}

function stamp(now) {
  return now || new Date().toISOString();
}

export async function openTask(home, input) {
  assertInstalledSources();
  rejectCommand(input);
  const task = assertTaskName(input.task);
  const sourceId = assertSource(input.source || MERCHANT_DEMAND_SOURCE);
  const owner = assertOwner(input.owner || "retained-task");
  const receiverId = input.receiverId || "local-vm";
  if (typeof receiverId !== "string" || receiverId.includes("://")) {
    throw new RetainedError("receiverId is a registry name, not a URL", "bad_receiver");
  }
  const now = stamp(input.now);
  const timeoutMs = boundTimeout(input.timeoutMs);
  await mkdir(home, { recursive: true });
  const monitor = await openMonitor(home, input.receivers || {}, now);
  await withJournal(home, async (file) => {
    const journal = await readJournal(file);
    if (journal.tasks[task]) throw new RetainedError("task already exists; resume it", "task_exists");
    journal.tasks[task] = {
      task,
      owner,
      subscriptionId: subscriptionIdFor(task),
      receiverId,
      source: { kind: "source-projection", scope: `source-projection:${sourceId}`, merchantDemand: sourceId === MERCHANT_DEMAND_SOURCE },
      openedAt: now,
      status: "opening",
      history: [],
      lastReceipt: null,
      lastFingerprint: null,
    };
    await atomicWrite(file, journal);
  });
  const record = await requireTask(home, task);
  try {
    await monitor.subscribe({
      subscriptionId: record.subscriptionId,
      owner,
      source: { kind: "source-projection", scope: record.source.scope },
      comparison: { policy: "material-fields" },
      destination: { receiverId },
      budget: { maxUsefulEvents: 20 },
      expiresAt: input.expiresAt || new Date(Date.parse(now) + 400 * 24 * 60 * 60 * 1000).toISOString(),
    });
  } catch (error) {
    await withJournal(home, async (file) => {
      const journal = await readJournal(file);
      delete journal.tasks[task];
      await atomicWrite(file, journal);
    });
    if (error instanceof MonitorError) throw new RetainedError(error.message, error.code);
    throw error;
  }
  return observeTask(home, { ...input, task, now, timeoutMs, phase: "open" });
}

export async function resumeTask(home, input) {
  assertInstalledSources();
  rejectCommand(input);
  const task = assertTaskName(input.task);
  await requireTask(home, task);
  const now = stamp(input.now);
  return observeTask(home, { ...input, task, now, timeoutMs: boundTimeout(input.timeoutMs), phase: "resume" });
}

async function observeTask(home, input) {
  const record = await requireTask(home, input.task);
  const now = input.now;
  const monitor = await openMonitor(home, input.receivers || {}, now);
  const before = await monitor.read();
  const subscription = before.subscriptions[record.subscriptionId];
  if (!subscription) throw new RetainedError("monitor subscription is missing", "incomplete_source");
  const priorMaterial = subscription.baseline?.material || null;
  const priorFingerprint = record.lastFingerprint;
  const sourceId = record.source.scope.slice("source-projection:".length);
  const read = await readSource({
    live: input.live === true,
    document: input.document,
    seedKey: input.seedKey || null,
    sourceId,
    now,
    timeoutMs: input.timeoutMs,
    fetchImpl: input.fetchImpl,
  });
  const classifyStarted = performance.now();
  let observed;
  try {
    observed = input.correctsEvidenceId
      ? await monitor.correct({
          subscriptionId: record.subscriptionId,
          correctsEvidenceId: input.correctsEvidenceId,
          document: documentForObserve(read.reading),
        })
      : await monitor.observe({
          subscriptionId: record.subscriptionId,
          document: documentForObserve(read.reading),
        });
  } catch (error) {
    if (error instanceof MonitorError) throw new RetainedError(error.message, error.code);
    throw error;
  }
  const classifyMs = elapsed(classifyStarted);
  const reviewStarted = performance.now();
  const projection = projectionOf(read.reading);
  const decision = sellerIntegrityDecision({
    sourceId,
    projection,
    outcome: observed.outcome,
    priorFingerprint,
  });
  const reviewMs = elapsed(reviewStarted);
  const state = await monitor.read();
  const receipt = buildReceipt({
    task: input.task,
    record: { ...record, phase: input.phase },
    observed,
    state,
    read,
    decision,
    effort: { readMs: read.ms, classifyMs, reviewMs },
    priorMaterial,
    now,
  });
  if (observed.outcome === "paused" || observed.outcome === "cancelled" || observed.outcome === "expired" || observed.outcome === "budget_exhausted") {
    receipt.phase = input.phase;
    await remember(home, input.task, receipt, { status: observed.outcome });
    return receipt;
  }
  await remember(home, input.task, receipt, { status: "active" });
  return receipt;
}

export async function correctTask(home, input) {
  if (!input.evidenceId) throw new RetainedError("evidenceId is required", "bad_args");
  return resumeTask(home, { ...input, correctsEvidenceId: input.evidenceId, live: false, seedKey: null });
}

async function withControl(home, input, fn) {
  assertInstalledSources();
  const task = assertTaskName(input.task);
  const record = await requireTask(home, task);
  const now = stamp(input.now);
  const monitor = await openMonitor(home, input.receivers || {}, now);
  const result = await fn(monitor, record, now);
  return { task, subscriptionId: record.subscriptionId, ...result };
}

export async function pauseTask(home, input) {
  return withControl(home, input, async (monitor, record) => ({ monitor: await monitor.pause(record.subscriptionId) }));
}

export async function unpauseTask(home, input) {
  return withControl(home, input, async (monitor, record) => ({ monitor: await monitor.resume(record.subscriptionId) }));
}

export async function cancelTask(home, input) {
  return withControl(home, input, async (monitor, record) => ({ monitor: await monitor.cancel(record.subscriptionId) }));
}

export async function deliverTask(home, input) {
  return withControl(home, input, async (monitor, record) => {
    const deliveries = await monitor.deliver({ subscriptionId: record.subscriptionId });
    return { deliveries };
  });
}

export async function reconcileTask(home, input) {
  return withControl(home, input, async (monitor, record) => {
    const reconciled = await monitor.reconcile({ subscriptionId: record.subscriptionId });
    return { reconciled };
  });
}

export async function showTask(home, task) {
  const record = await requireTask(home, assertTaskName(task));
  if (!record.lastReceipt) throw new RetainedError("task has no receipt yet", "no_receipt");
  return record.lastReceipt;
}

export function exitCodeFor(receipt) {
  const outcome = receipt?.observation?.outcome;
  if (outcome === "paused" || outcome === "cancelled" || outcome === "expired" || outcome === "budget_exhausted") return 3;
  if (receipt?.delivery?.state === "unknown") return 4;
  return 0;
}
