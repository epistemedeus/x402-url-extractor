import { SCHEMA_VERSION } from "../../change-monitor/vendor/s12-observatory/contract.js";
import {
  buildOperatorDecision,
  metricByKey,
  missingNotZero,
  moltjobsDrilldown,
  refuseOrganicAsPaidCustomers,
  smitheryDrilldown,
  x402Drilldown,
} from "../../change-monitor/vendor/s12-observatory/paid-activity.js";

export const MERCHANT_DEMAND_SOURCE = "x402stats";
export const RECEIPT_SCHEMA = "retained-task.receipt.v1";

const CUSTOMER_KEYS = new Set(["customers", "customerCount", "paidCustomers", "uniqueCustomers"]);

function slotToObservation(slot) {
  if (!slot) return null;
  const availability = slot.availability === "unprojected" ? "missing_from_snapshot" : slot.availability;
  return {
    sourceId: slot.sourceId,
    availability,
    fetchedAt: slot.freshness?.fetchedAt ?? null,
    providerTimestamp: slot.freshness?.providerTimestamp ?? null,
    metrics: Array.isArray(slot.metrics) ? slot.metrics : [],
    coverage: slot.coverage?.envelopeCoverage ?? null,
  };
}

function windowCoverage(slot) {
  if (!slot || slot.availability === "unprojected" || slot.availability == null) return "unknown";
  const envelope = slot.coverage?.envelopeCoverage;
  if (!envelope || typeof envelope !== "object") return "unknown";
  if (envelope.complete == null || envelope.window == null || envelope.window === "") return "unknown";
  if (envelope.complete !== true || slot.coverage?.state !== "covered") return "incomplete";
  return "complete";
}

function drillFor(sourceId, observation) {
  if (sourceId === "x402stats") return x402Drilldown(observation);
  if (sourceId === "moltjobs") return moltjobsDrilldown(observation);
  return smitheryDrilldown(observation);
}

function snapshotFromProjection(projection) {
  return {
    schemaVersion: SCHEMA_VERSION,
    fetchedAt: projection?.observedAt ?? null,
    observations: (projection?.sources || []).map((slot) => slotToObservation(slot)).filter(Boolean),
  };
}

function stable(value) {
  return JSON.stringify(sortValue(value));
}

function sortValue(value) {
  if (Array.isArray(value)) return value.map(sortValue);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, sortValue(value[key])]));
}

export function actionFor(outcome) {
  if (outcome === "baseline_established") return { warrant: "none", action: "hold_baseline" };
  if (outcome === "unchanged") return { warrant: "negative", action: "no_work" };
  if (outcome === "content_changed" || outcome === "service_restored") return { warrant: "act", action: "unpaid_reread" };
  if (outcome === "evidence_unavailable") return { warrant: "act", action: "repair_reading" };
  return { warrant: "refused", action: "admission_refused" };
}

export function diffMaterial(before, after) {
  const left = new Map((before?.metrics || []).map((metric) => [metric.key, metric]));
  const right = new Map((after?.metrics || []).map((metric) => [metric.key, metric]));
  const keys = [...new Set([...left.keys(), ...right.keys()])].sort();
  const changedKeys = [];
  for (const key of keys) {
    const prior = left.get(key);
    const next = right.get(key);
    const priorValue = prior ? { value: prior.value ?? null, state: prior.state ?? null } : null;
    const nextValue = next ? { value: next.value ?? null, state: next.state ?? null } : null;
    if (stable(priorValue) === stable(nextValue)) continue;
    changedKeys.push({ key, before: priorValue, after: nextValue });
  }
  return changedKeys;
}

function scanCustomerClaims(value, path, problems) {
  if (!value || typeof value !== "object") return;
  if (Array.isArray(value)) {
    value.forEach((entry, index) => scanCustomerClaims(entry, `${path}[${index}]`, problems));
    return;
  }
  for (const [key, entry] of Object.entries(value)) {
    const here = `${path}.${key}`;
    if (CUSTOMER_KEYS.has(key) && entry !== null) problems.push(`${here} must stay null`);
    if (key === "naturalCustomerDemand" && entry !== false) problems.push(`${here} must stay false`);
    if (key === "completeZeroDemand" && entry !== false) problems.push(`${here} must stay false`);
    if (key === "demandReading" && entry === "complete_zero_demand") problems.push(`${here} is not an unchanged negative`);
    if ((key === "sku" || key === "price") && entry !== null) problems.push(`${here} must stay null`);
    if ((key === "executed" || key === "paymentExecuted") && entry !== false) problems.push(`${here} must stay false`);
    if (key === "billable" && entry !== false) problems.push(`${here} must stay false`);
    if (key === "purchaseExecuted" && entry !== false) problems.push(`${here} must stay false`);
    scanCustomerClaims(entry, here, problems);
  }
}

export function assertReceipt(receipt) {
  const problems = [];
  if (!receipt || receipt.schema !== RECEIPT_SCHEMA) problems.push("schema");
  scanCustomerClaims(receipt, "$", problems);
  if (problems.length > 0) {
    throw new Error(`receipt violated the unpaid customer boundary: ${problems.join("; ")}`);
  }
  return receipt;
}

export function sellerIntegrityDecision({ sourceId, projection, outcome, priorFingerprint = null }) {
  const slot = projection?.sources?.find((entry) => entry && entry.sourceId === sourceId) || null;
  const merchantSlot = projection?.sources?.find((entry) => entry && entry.sourceId === MERCHANT_DEMAND_SOURCE) || null;
  const observation = slotToObservation(slot);
  const merchantObservation = slotToObservation(merchantSlot);
  const drill = drillFor(sourceId, observation);
  const merchantDrill = x402Drilldown(merchantObservation);
  const organic = refuseOrganicAsPaidCustomers(null);
  const sellerMetric = metricByKey(merchantObservation, "sellers_30d");
  const sellers = missingNotZero(sellerMetric);
  const coverage = windowCoverage(merchantSlot);
  let operator = null;
  if (projection && Array.isArray(projection.sources)) {
    try {
      const built = buildOperatorDecision(snapshotFromProjection(projection));
      operator = {
        status: built.status,
        action: built.purchaseExecuted === true ? "none" : built.action,
        purchaseExecuted: false,
        bidExecuted: false,
        operatorPurchaseIgnored: built.purchaseExecuted === true,
      };
    } catch {
      operator = null;
    }
  }
  const fingerprint = stable({
    coverage,
    merchantAvailability: merchantObservation?.availability ?? "missing_from_snapshot",
    sellers: sellers.text,
    organicPaidCustomers: null,
    operatorStatus: operator?.status ?? null,
  });
  const decisionChanged = typeof priorFingerprint === "string" ? priorFingerprint !== fingerprint : false;
  const chosen = actionFor(outcome);
  const incomplete = coverage !== "complete";
  return {
    schema: "retained-task.seller-integrity.v1",
    interface: "s12.paid-activity",
    sourceId,
    merchantDemandSource: MERCHANT_DEMAND_SOURCE,
    action: chosen.action,
    warrant: chosen.warrant,
    payment: { executed: false, billable: false, sku: null, price: null, currency: null },
    customers: null,
    coverage,
    fullWindowKnown: coverage === "complete",
    incompleteEvidence: incomplete,
    note: incomplete
      ? "Unknown or incomplete full-window coverage is incomplete evidence. It is not zero customers. Indexed sellers are not customers."
      : "A complete seller window is still not a customer count. Indexed sellers and organic heuristics are not paid customers.",
    sellers,
    organicPaidCustomers: organic.paidCustomers,
    organicReason: organic.reason,
    taskSource: {
      sourceId: drill.sourceId,
      availability: drill.availability,
      reason: drill.reason || null,
    },
    merchantDemand: {
      sourceId: merchantDrill.sourceId,
      availability: merchantDrill.availability,
      reason: merchantDrill.reason || null,
      doesNotEstablish: merchantDrill.doesNotEstablish || null,
    },
    operator,
    fingerprint,
    decisionChanged,
  };
}
