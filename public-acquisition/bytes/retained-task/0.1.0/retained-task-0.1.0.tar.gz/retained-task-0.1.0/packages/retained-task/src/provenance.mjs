import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { join } from "node:path";

import { RetainedError } from "./errors.mjs";

export function verifyProjectionTree(dir) {
  let provenance;
  try {
    provenance = JSON.parse(readFileSync(join(dir, "PROVENANCE.json"), "utf8"));
  } catch {
    throw new RetainedError("projection provenance is not readable", "incomplete_source");
  }
  const files = provenance && provenance.files;
  if (!files || typeof files !== "object" || Array.isArray(files) || Object.keys(files).length === 0) {
    throw new RetainedError("projection provenance lists no files", "incomplete_source");
  }
  const missing = [];
  const mismatched = [];
  for (const [name, pinned] of Object.entries(files)) {
    if (!pinned || typeof pinned.sha256 !== "string" || !pinned.sha256) {
      missing.push(name);
      continue;
    }
    let bytes;
    try {
      bytes = readFileSync(join(dir, name));
    } catch {
      missing.push(name);
      continue;
    }
    const actual = createHash("sha256").update(bytes).digest("hex");
    if (actual !== pinned.sha256) mismatched.push({ name, actual, expected: pinned.sha256 });
  }
  if (missing.length > 0) {
    throw new RetainedError(`projection source is incomplete: ${missing.join(", ")}`, "incomplete_source");
  }
  if (mismatched.length > 0) {
    const error = new RetainedError(
      `projection bytes do not match PROVENANCE.json: ${mismatched.map((row) => row.name).join(", ")}`,
      "tampered_dependency",
    );
    error.mismatches = mismatched;
    throw error;
  }
  return { ok: true, commit: provenance.commit || null, files: Object.keys(files).length };
}
