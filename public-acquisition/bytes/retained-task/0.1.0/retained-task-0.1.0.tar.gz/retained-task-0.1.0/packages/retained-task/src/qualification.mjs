import { readFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";

import { RetainedError } from "./errors.mjs";

/** Neo234 public sidecar for change-monitor 0.1.0. Agreement is exact on these fields. */
export const MONITOR_SIDECAR_AGREEMENT = Object.freeze({
  schema: "neomorphic.change-monitor.release-status.v1",
  packageName: "change-monitor",
  version: "0.1.0",
  sha256: "a5248cac86ae604b365d95e3c21da5c15cd09f1a962428eb7d60b4c3b210100f",
  bytes: 88319,
  hostedAcquisitionVerified: true,
  sourceQualified: false,
  privateGitSource: "unavailable",
  launched: false,
  paidServiceLaunch: false,
  ownerPayment: false,
  publicationStatus: "candidate",
  naturalCustomerDemand: false,
});

const CANDIDATES = [
  new URL("../../../public/downloads/change-monitor/0.1.0/release-status.json", import.meta.url),
  new URL("../support/change-monitor-0.1.0-release-status.json", import.meta.url),
];

function readSidecar(url) {
  const file = fileURLToPath(url);
  if (!existsSync(file)) return null;
  try {
    return { file, status: JSON.parse(readFileSync(file, "utf8")) };
  } catch {
    throw new RetainedError("change-monitor release status is not readable JSON", "sidecar_unreadable");
  }
}

export function loadMonitorSidecars() {
  const found = CANDIDATES.map(readSidecar).filter(Boolean);
  if (found.length === 0) {
    throw new RetainedError("change-monitor 0.1.0 release status is missing", "sidecar_missing");
  }
  const first = JSON.stringify(found[0].status);
  for (const extra of found.slice(1)) {
    if (JSON.stringify(extra.status) !== first) {
      throw new RetainedError("bundled monitor sidecar disagrees with the public sidecar", "sidecar_disagreement");
    }
  }
  return found[0].status;
}

export function assertAgreesWithMonitorSidecar(status = loadMonitorSidecars()) {
  const problems = [];
  for (const key of [
    "schema",
    "packageName",
    "version",
    "sha256",
    "bytes",
    "hostedAcquisitionVerified",
    "sourceQualified",
    "privateGitSource",
    "launched",
    "paidServiceLaunch",
    "ownerPayment",
    "publicationStatus",
  ]) {
    if (status?.[key] !== MONITOR_SIDECAR_AGREEMENT[key]) problems.push(key);
  }
  if (status?.readback?.naturalCustomerDemand !== false) problems.push("readback.naturalCustomerDemand");
  if (status?.readback?.sourceQualification !== "unavailable") problems.push("readback.sourceQualification");
  if (problems.length > 0) {
    throw new RetainedError(
      `monitor sidecar does not agree with the Neo234 public qualification: ${problems.join(", ")}`,
      "sidecar_disagreement",
    );
  }
  return {
    agreesWith: "public/downloads/change-monitor/0.1.0/release-status.json",
    privateGitSource: "unavailable",
    sourceQualified: false,
    hostedAcquisitionVerified: true,
    paidServiceLaunch: false,
    freshnessObservedAt: status.readback?.observedAt ?? null,
    coverage: "unknown_or_incomplete_is_not_zero_demand",
    naturalCustomerDemand: false,
  };
}
