# retained-task

Caller-owned composition over `packages/change-monitor`. An agent names a task and one supported source, keeps the baseline in the monitor store, and resumes later. The receipt is either the material change or the unchanged negative that decides the next unpaid step.

The merchant demand source is `x402stats` (indexed sellers). Unknown or incomplete full-window coverage is incomplete evidence. Customer counts stay null. A seeded local mutation is not an observed public change. Nothing here starts a scheduler, stores a telemetry warehouse, adds a page, accepts a webhook URL, or sets a price.

```bash
node src/cli.mjs open --home ./var/merchant --task hold-sellers --source x402stats \
  --receivers ./receivers.json --file ./capture.json --now 2026-10-01T12:00:00.000Z
node src/cli.mjs resume --home ./var/merchant --task hold-sellers --file ./capture.json
node src/cli.mjs resume --home ./var/merchant --task hold-sellers --live --timeout-ms 8000
node src/cli.mjs deliver --home ./var/merchant --task hold-sellers --receivers ./receivers.json
node src/cli.mjs reconcile --home ./var/merchant --task hold-sellers --receivers ./receivers.json
node src/cli.mjs pause --home ./var/merchant --task hold-sellers
node src/cli.mjs unpause --home ./var/merchant --task hold-sellers
node src/cli.mjs cancel --home ./var/merchant --task hold-sellers
```

`receivers.json` is `{ "local-vm": { "kind": "local-http", "baseUrl": "http://127.0.0.1:<port>" } }`. The subscription stores the receiver id. Pause, cancel, and delivery use the monitor contracts. An unknown send is reconciled; it is not posted again while it is unknown.

Exit 0 means the observation was classified. Exit 2 means the command or the installed projection bytes were rejected. Exit 3 means admission was refused. Exit 4 means a delivery is still unknown.

Seller integrity uses the pinned S12 paid-activity drilldown. `payment.executed` stays false. A valid unchanged negative does not need the decision fingerprint to change.

Public archive: `public/downloads/retained-task/0.1.0/retained-task-0.1.0.tar.gz`.
It contains this package and the change-monitor 0.1.0 runtime files. Those
runtime bytes match frozen archive sha256
`a5248cac86ae604b365d95e3c21da5c15cd09f1a962428eb7d60b4c3b210100f`.
That archive is not rebuilt. `sourceQualified` stays false and
`privateGitSource` stays `unavailable`, agreeing with the Neo234 sidecar.
`hostedAcquisitionVerified` on this new pack stays false until an external
readback. A loopback fetch is not hosted acceptance.
