import assert from "node:assert/strict";
import test from "node:test";

import { readMaintainedProjection } from "../../change-monitor/src/index.mjs";
import { openTask, resumeTask } from "../src/compose.mjs";
import { receivers, tempHome } from "./support.mjs";

function slotSummary(projection, sourceId) {
  const slot = projection?.sources?.find((entry) => entry.sourceId === sourceId);
  if (!slot) return null;
  const sellers = Array.isArray(slot.metrics) ? slot.metrics.find((metric) => metric.key === "sellers_30d") : null;
  return {
    availability: slot.availability,
    coverage: slot.coverage?.state ?? null,
    envelopeComplete: slot.coverage?.envelopeCoverage?.complete ?? null,
    envelopeWindow: slot.coverage?.envelopeCoverage?.window ?? null,
    missingPopulations: slot.coverage?.missingPopulations ?? [],
    sellersState: sellers?.state ?? null,
    sellersValue: sellers?.state === "ok" ? sellers.value : null,
  };
}

test("a live public snapshot is read with a bounded timeout and is not skipped", { timeout: 40000 }, async () => {
  const dir = await tempHome("retained-live-");
  try {
    const opened = await openTask(dir.home, {
      task: "live-sellers",
      source: "x402stats",
      owner: "ordinary-agent",
      live: true,
      timeoutMs: 8000,
      receivers,
    });
    assert.equal(opened.read.attempted, true);
    assert.equal(opened.read.mode, "live");
    assert.equal(opened.read.url, "https://samedaydesk.com/api/observatory/snapshot");
    assert.equal(opened.read.timeoutMs, 8000);
    assert.equal(opened.observation.capture === "live" || opened.read.failureKind != null, true);
    assert.ok(opened.read.httpStatus != null || opened.read.failureKind != null);
    assert.equal(opened.decision.customers, null);
    assert.equal(opened.decision.payment.executed, false);
    assert.equal(opened.observation.naturalCustomerDemand, false);
    assert.equal(opened.observation.seeded, false);
    assert.equal(opened.effort.measured, true);
    if (opened.decision.coverage !== "complete") {
      assert.equal(opened.decision.incompleteEvidence, true);
    }
    const resumed = await resumeTask(dir.home, {
      task: "live-sellers",
      live: true,
      timeoutMs: 8000,
      receivers,
    });
    assert.equal(resumed.read.mode, "live");
    assert.equal(resumed.decision.customers, null);
    assert.equal(resumed.decision.payment.executed, false);
    assert.ok(resumed.read.httpStatus != null || resumed.read.failureKind != null);
    if (resumed.observation.outcome === "unchanged") {
      assert.equal(resumed.negative.valid, true);
      assert.equal(resumed.feedsNextDecision.action, "no_work");
      assert.equal(resumed.observation.eventId, null);
    } else {
      assert.equal(resumed.feedsNextDecision.paymentExecuted, false);
      assert.ok(resumed.feedsNextDecision.action === "unpaid_reread" || resumed.feedsNextDecision.action === "repair_reading" || resumed.feedsNextDecision.action === "hold_baseline");
    }
    const captured = await readMaintainedProjection({ timeoutMs: 8000 });
    const captureDocument = captured.projection || {
      capture: "live",
      integration: "maintained",
      status: "source_failure",
      failureCode: captured.failureCode,
      reason: captured.reason,
      fetch: captured.fetch,
      projection: null,
      publicSourceChanged: false,
    };
    const replayed = await openTask(dir.home, {
      task: "captured-sellers",
      source: "x402stats",
      owner: "ordinary-agent",
      document: captureDocument,
      receivers,
    });
    const replayedAgain = await resumeTask(dir.home, {
      task: "captured-sellers",
      document: captureDocument,
    });
    assert.equal(replayedAgain.observation.outcome, "unchanged");
    assert.equal(replayedAgain.negative.valid, true);
    assert.equal(replayedAgain.feedsNextDecision.action, "no_work");
    assert.equal(replayedAgain.observation.eventId, null);
    assert.equal(replayedAgain.observation.outboxEvents, replayed.observation.outboxEvents);
    assert.equal(replayedAgain.decision.customers, null);
    assert.equal(replayedAgain.observation.publicSourceChanged, false);
    assert.equal(replayedAgain.observation.seeded, false);
    process.stdout.write(`${JSON.stringify({
      open: {
        outcome: opened.observation.outcome,
        httpStatus: opened.read.httpStatus,
        failureKind: opened.read.failureKind,
        coverage: opened.decision.coverage,
        action: opened.feedsNextDecision.action,
        failureCode: opened.observation.failureCode,
        customers: opened.decision.customers,
      },
      resume: {
        outcome: resumed.observation.outcome,
        httpStatus: resumed.read.httpStatus,
        failureKind: resumed.read.failureKind,
        action: resumed.feedsNextDecision.action,
        warrant: resumed.feedsNextDecision.warrant,
        customers: resumed.decision.customers,
        publicSourceChanged: resumed.observation.publicSourceChanged,
        failureCode: resumed.observation.failureCode,
      },
      capture: {
        httpStatus: captured.fetch?.httpStatus ?? null,
        failureKind: captured.fetch?.failureKind ?? null,
        x402: slotSummary(captured.projection, "x402stats"),
        replayOutcome: replayed.observation.outcome,
        replayFailure: replayed.observation.failureCode,
        replayAction: replayed.feedsNextDecision.action,
        replayCoverage: replayed.decision.coverage,
        replayCustomers: replayed.decision.customers,
        secondOutcome: replayedAgain.observation.outcome,
        secondAction: replayedAgain.feedsNextDecision.action,
        secondNegative: replayedAgain.negative?.valid ?? false,
        secondDecisionChanged: replayedAgain.decision.decisionChanged,
      },
    })}\n`);
  } finally {
    await dir.cleanup();
  }
});
