# samedaydesk-seller-audit-buyer 0.1.0

Machine contract for GET /commerce/seller-integrity-audit.
Default mode does not read a wallet or sign. Live payment stays refused until --approve.

```sh
node bin/seller-audit.mjs contract
node bin/seller-audit.mjs preflight --authorization authorization.json
node bin/seller-audit.mjs purchase --approve --authorization authorization.json --private-key-env SELLER_AUDIT_PRIVATE_KEY --attempt-receipt attempt.json
node bin/seller-audit.mjs reconcile --attempt-receipt attempt.json --rpc-url https://example-rpc.invalid
```

Preflight is unpaid. Purchase signs once and sends once. A lost response stays unknown until reconcile.
Reconcile is read-only and is not a second spend. Feedback is not required.
SDK pin: @x402/fetch@2.16.0. Product samedaydesk-seller-integrity-audit 1.3.0.
