/**
 * Read-only GoFrantic public board adapter (GET /v1/board).
 * price_usd is a published USD display field. Currency is USD and the asset
 * stays unknown unless the source explicitly names USDC.
 * funded===true is a source_published promise, not reserved_observed.
 * settled_at is a poster/source timestamp, not settled_observed.
 * Never follows POST/claim actions.
 */

import {
  SCHEMA_VERSION,
  classifyRewardPlanes,
  validateListing,
  adapterError,
  FORBIDDEN_ACTIONS,
} from "../contract.mjs";

export const PROVIDER = "gofrantic";
export const BOARD_URL = "https://gofrantic.com/v1/board";
export const SITE_ORIGIN = "https://gofrantic.com";

const HUMAN_IDENTITY_RE =
  /your own reddit account|own reddit account|from your own [a-z][a-z0-9_-]* account/i;

function isoNow(now) {
  if (typeof now === "function") return isoNow(now());
  if (now instanceof Date) return now.toISOString();
  if (typeof now === "number" && Number.isFinite(now)) return new Date(now).toISOString();
  if (typeof now === "string" && Number.isFinite(Date.parse(now))) {
    return now.endsWith("Z") ? now : new Date(now).toISOString();
  }
  return new Date().toISOString();
}

function toIsoZ(value) {
  if (typeof value === "string" && Number.isFinite(Date.parse(value))) {
    return value.endsWith("Z") ? value : new Date(value).toISOString();
  }
  if (typeof value === "number" && Number.isFinite(value)) return new Date(value).toISOString();
  return null;
}

function locatorOf(bounty) {
  const url = bounty?.url;
  if (typeof url === "string" && url.trim()) {
    try {
      return new URL(url, SITE_ORIGIN).href;
    } catch {
      // fall through to number path
    }
  }
  if (bounty?.number != null) return `${SITE_ORIGIN}/bounties/${encodeURIComponent(String(bounty.number))}`;
  return BOARD_URL;
}

function advertisedFromPriceUsd(bounty, locator) {
  if (!bounty || !Object.prototype.hasOwnProperty.call(bounty, "price_usd") || bounty.price_usd == null) {
    return { amount: null, currency: null, asset: null, plane: "unknown", evidenceRef: null };
  }
  const named = [bounty.currency, bounty.asset, bounty.token, bounty.asset_symbol]
    .map((value) => (typeof value === "string" ? value.trim() : ""))
    .find(Boolean);
  const usdc = Boolean(named && /^usdc$/i.test(named));
  return {
    amount: String(bounty.price_usd),
    currency: usdc ? "USDC" : "USD",
    asset: usdc ? "USDC" : null,
    plane: "source_published",
    evidenceRef: locator,
  };
}

function reservedFromFunded(bounty, locator) {
  if (bounty?.funded === true) {
    return {
      state: "promised",
      amount: null,
      currency: null,
      asset: null,
      plane: "source_published",
      evidenceRef: locator,
    };
  }
  return { state: "unknown", amount: null, currency: null, asset: null, plane: "unknown", evidenceRef: null };
}

function eligibilityOf(bounty) {
  const note = typeof bounty?.note === "string" ? bounty.note : "";
  if (HUMAN_IDENTITY_RE.test(note)) {
    return {
      agentAccess: "HUMAN_ONLY",
      humanGates: Object.freeze(["human_identity_text"]),
      plane: "source_published",
      evidenceRef: "note",
    };
  }
  return {
    agentAccess: "AGENT_ALLOWED",
    humanGates: Object.freeze([]),
    plane: "source_published",
    evidenceRef: "open_bounties",
  };
}

function slotsOf(bounty) {
  const slots = bounty?.claim_slots;
  if (!slots || typeof slots !== "object") return null;
  const capacity = Number.isFinite(Number(slots.capacity)) ? Number(slots.capacity) : null;
  const occupied = Number.isFinite(Number(slots.occupied)) ? Number(slots.occupied) : null;
  const available = Number.isFinite(Number(slots.available)) ? Number(slots.available) : null;
  return Object.freeze({ capacity, occupied, available });
}

function boardEnvelope({
  observedAt,
  outcome,
  reason = null,
  listings = [],
  httpStatus = null,
  provenanceKind = "test",
  channel = null,
}) {
  return {
    schemaVersion: SCHEMA_VERSION,
    sourceId: PROVIDER,
    listingId: "_adapter",
    locator: BOARD_URL,
    observedAt,
    outcome,
    reason,
    freshness: { state: outcome === "observed" ? "current" : "unknown", observedAt, sourceTimestamp: null },
    provenance: { kind: provenanceKind, capturedAt: observedAt, httpStatus, productionSettlement: false },
    eligibility: { agentAccess: "UNKNOWN", humanGates: [], plane: "unknown", evidenceRef: null },
    reward: classifyRewardPlanes({}),
    claim: { method: null, conditions: [], exclusive: null, slots: null, plane: "unknown" },
    acceptance: { criteria: [], adjudicator: null, deterministic: null, plane: "unknown" },
    status: { listing: null, sourceIssue: null },
    contributorSignals: { submissions: null, comments: null, claims: null, lastUpdate: null, plane: "unknown" },
    ingest: { method: "json_get", pagination: null },
    pagination: null,
    channel: channel ?? null,
    listings,
    forbiddenAttempted: [],
  };
}

function mapBounty(bounty, { observedAt, provenanceKind, httpStatus }) {
  if (!bounty || typeof bounty !== "object" || bounty.number == null) return null;
  const listingId = String(bounty.number);
  const locator = locatorOf(bounty);
  const slots = slotsOf(bounty);
  const settledAt = toIsoZ(bounty.settled_at);
  const postedAt = toIsoZ(bounty.posted_at);
  const workStatus = bounty.work_status == null ? null : String(bounty.work_status);

  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    sourceId: PROVIDER,
    listingId,
    locator,
    observedAt,
    outcome: "observed",
    freshness: {
      state: "current",
      observedAt,
      sourceTimestamp: postedAt,
    },
    provenance: {
      kind: provenanceKind,
      capturedAt: observedAt,
      httpStatus,
      productionSettlement: false,
    },
    eligibility: eligibilityOf(bounty),
    reward: classifyRewardPlanes({
      advertised: advertisedFromPriceUsd(bounty, locator),
      reserved: reservedFromFunded(bounty, locator),
      settled: { state: "unknown" },
    }),
    claim: {
      method: "marketplace_claim",
      conditions: [],
      exclusive: slots?.capacity === 1 ? true : slots?.capacity != null ? false : null,
      slots,
      plane: "source_published",
    },
    acceptance: {
      criteria: [],
      adjudicator: "poster",
      deterministic: false,
      plane: "source_published",
    },
    status: { listing: workStatus, sourceIssue: settledAt },
    contributorSignals: {
      submissions: null,
      comments: null,
      claims: slots?.occupied ?? null,
      lastUpdate: settledAt,
      plane: "source_published",
    },
    ingest: { method: "json_get", pagination: null },
    forbiddenAttempted: [],
    title: typeof bounty.title === "string" ? bounty.title : listingId,
    raw: Object.freeze({
      price_usd: bounty.price_usd ?? null,
      funded: bounty.funded === true,
      work_status: workStatus,
      settled_at: bounty.settled_at ?? null,
      posted_at: bounty.posted_at ?? null,
      note: typeof bounty.note === "string" ? bounty.note : null,
      api_url: bounty.api_url ?? null,
      claim_slots: slots,
    }),
  });
}

export function createAdapter({ fetchImpl, now } = {}) {
  function observeBoard(body, options = {}) {
    const observedAt = options.observedAt ?? isoNow(now);
    const provenanceKind = options.provenanceKind ?? "fixture";
    const httpStatus = options.httpStatus ?? null;
    const channel = body && typeof body === "object" ? body.channel ?? null : null;

    if (!body || typeof body !== "object") {
      return adapterError({ sourceId: PROVIDER, reason: "unknown", observedAt, provenanceKind });
    }
    if (body.ok !== true) {
      return adapterError({
        sourceId: PROVIDER,
        reason: body.ok === false ? "error" : "unknown",
        observedAt,
        provenanceKind,
      });
    }

    const open = body.board?.open_bounties;
    if (!Array.isArray(open)) {
      return boardEnvelope({
        observedAt,
        outcome: "unknown",
        reason: "malformed",
        httpStatus,
        provenanceKind,
        channel,
      });
    }

    const listings = open
      .map((bounty) => mapBounty(bounty, { observedAt, provenanceKind, httpStatus }))
      .filter(Boolean)
      .map((listing) => {
        validateListing(listing);
        return listing;
      });

    if (open.length === 0) {
      return boardEnvelope({
        observedAt,
        outcome: "empty",
        reason: "empty",
        listings: [],
        httpStatus,
        provenanceKind,
        channel,
      });
    }

    return boardEnvelope({
      observedAt,
      outcome: "observed",
      listings,
      httpStatus,
      provenanceKind,
      channel,
    });
  }

  async function ingest() {
    const observedAt = isoNow(now);
    if (typeof fetchImpl !== "function") {
      return adapterError({ sourceId: PROVIDER, reason: "error", observedAt, provenanceKind: "test" });
    }
    let response;
    try {
      response = await fetchImpl(BOARD_URL, {
        method: "GET",
        redirect: "follow",
        headers: {
          accept: "application/json",
          "user-agent": "W5-H02-public-ingest/0.1 (+https://samedaydesk.com; read-only)",
        },
      });
    } catch {
      return adapterError({ sourceId: PROVIDER, reason: "error", observedAt, provenanceKind: "test" });
    }

    const httpStatus = response?.status ?? 0;
    let body = null;
    try {
      if (typeof response?.json === "function") body = await response.json();
      else if (typeof response?.text === "function") {
        const text = await response.text();
        body = text ? JSON.parse(text) : null;
      }
    } catch {
      return boardEnvelope({
        observedAt,
        outcome: "unknown",
        reason: "malformed",
        httpStatus,
        provenanceKind: "test",
      });
    }

    if (!response || response.ok === false || httpStatus === 0) {
      return adapterError({ sourceId: PROVIDER, reason: "error", observedAt, provenanceKind: "test" });
    }

    return observeBoard(body, {
      observedAt,
      provenanceKind: "test",
      httpStatus,
    });
  }

  return Object.freeze({
    provider: PROVIDER,
    capabilities: Object.freeze({
      read: true,
      write: false,
      login: false,
      claim: false,
      wallet: false,
      ingestMethod: "json_get",
      pagination: null,
      forbidden: FORBIDDEN_ACTIONS,
    }),
    ingest,
    observeBoard,
  });
}
