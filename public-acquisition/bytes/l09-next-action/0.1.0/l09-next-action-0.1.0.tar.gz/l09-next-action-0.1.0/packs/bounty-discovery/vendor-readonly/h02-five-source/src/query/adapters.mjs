import { createAdapter as createSuperteam } from "../adapters/superteam.mjs";
import { createAdapter as createTaskmarket } from "../adapters/taskmarket.mjs";
import { createAdapter as createGibwork } from "../adapters/gibwork.mjs";
import { createAdapter as createGofrantic } from "../adapters/gofrantic.mjs";
import { createAdapter as createAgentbounties } from "../adapters/agentbounties.mjs";
import { createAdapter as createBountyhub } from "../adapters/bountyhub-unsupported.mjs";

export const UNION_SOURCES = Object.freeze([
  {
    adapter: "superteam",
    sourceId: "superteam-earn",
    supported: true,
    observer: "observeListings",
    listUrl: ({ page } = {}) => {
      const url = new URL("https://superteam.fun/api/listings/");
      url.searchParams.set("take", "100");
      if (page?.skip != null) url.searchParams.set("skip", String(page.skip));
      return url.href;
    },
  },
  {
    adapter: "taskmarket",
    sourceId: "taskmarket",
    supported: true,
    observer: "observeListings",
    listUrl: ({ page } = {}) => {
      const url = new URL("https://api.taskmarket.dev/api/tasks");
      if (page?.cursor) url.searchParams.set("cursor", String(page.cursor));
      return url.href;
    },
  },
  {
    adapter: "gibwork",
    sourceId: "gibwork",
    supported: true,
    observer: "observeListings",
    listUrl: ({ page } = {}) => {
      const url = new URL("https://api.gib.work/explore");
      url.searchParams.set("page", String(page?.page ?? 1));
      return url.href;
    },
  },
  {
    adapter: "gofrantic",
    sourceId: "gofrantic",
    supported: true,
    observer: "observeBoard",
    listUrl: () => "https://gofrantic.com/v1/board",
  },
  {
    adapter: "agentbounties",
    sourceId: "agentbounties",
    supported: true,
    observer: "observeListings",
    listUrl: () =>
      "https://api.agentbounties.app/v1/base/autonomous-bounties/feed?network=base-mainnet&claimable_only=true",
  },
  {
    adapter: "bountyhub-unsupported",
    sourceId: "bountyhub",
    supported: false,
    observer: "observeListings",
    listUrl: () => "https://api.bountyhub.dev/api/bounties?page=1&limit=1",
    bodyAsText: true,
  },
]);

const FACTORIES = {
  superteam: createSuperteam,
  taskmarket: createTaskmarket,
  gibwork: createGibwork,
  gofrantic: createGofrantic,
  agentbounties: createAgentbounties,
  "bountyhub-unsupported": createBountyhub,
};

export function createUnionAdapter(name, options) {
  const factory = FACTORIES[name];
  if (typeof factory !== "function") {
    const error = new TypeError(`unknown adapter ${name}`);
    error.code = "unknown_adapter";
    throw error;
  }
  return factory(options);
}

export function listingsFromPage(page) {
  if (Array.isArray(page?.listings)) return page.listings;
  if (page?.listingId && page.listingId !== "_adapter" && page.outcome === "observed") return [page];
  return [];
}
