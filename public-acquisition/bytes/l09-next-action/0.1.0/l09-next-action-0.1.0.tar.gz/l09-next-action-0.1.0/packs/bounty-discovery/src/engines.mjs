/**
 * Load vendored C05–C07 APIs from this extract. No W5_C10_READONLY, no /tmp pins.
 * Exact shipped vendor inputs are validated from ENGINE-CONTENT-MANIFEST.json.
 */
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

import { ENGINE_PINS, describePins } from "./five-source/engine-pins.mjs";
import { assertShippedEngineContent } from "./five-source/engine-content.mjs";

export const KIT_ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");

assertShippedEngineContent(KIT_ROOT);

const searchRoot = join(KIT_ROOT, "vendor/c05");
const freshnessRoot = join(KIT_ROOT, "vendor/c06");
const gateRoot = join(KIT_ROOT, "vendor/c07");

const ingestUrl = pathToFileURL(join(searchRoot, "src/ingest.mjs")).href;
const searchUrl = pathToFileURL(join(searchRoot, "src/search.mjs")).href;
const observationUrl = pathToFileURL(join(searchRoot, "src/observation.mjs")).href;
const freshnessUrl = pathToFileURL(join(freshnessRoot, "src/report.mjs")).href;
const reservationUrl = pathToFileURL(join(gateRoot, "src/reservation.mjs")).href;

const [ingestMod, searchMod, observationMod, freshnessMod, reservationMod] = await Promise.all([
  import(ingestUrl),
  import(searchUrl),
  import(observationUrl),
  import(freshnessUrl),
  import(reservationUrl),
]);

export const engineRoots = Object.freeze({
  "discovery-search-index": searchRoot,
  "source-freshness-consumer": freshnessRoot,
  "workability-gate-composer": gateRoot,
});

export const enginePins = describePins(engineRoots);

export const c05 = Object.freeze({
  ingestDirectory: ingestMod.ingestDirectory,
  ingestJobCardFile: ingestMod.ingestJobCardFile,
  search: searchMod.search,
  observationKey: observationMod.observationKey,
  sameObservation: observationMod.sameObservation,
  observationIdentityFromRecord: observationMod.observationIdentityFromRecord,
  source: ENGINE_PINS["discovery-search-index"].sha,
});

export const c06 = Object.freeze({
  freshnessReport: freshnessMod.freshnessReport,
  source: ENGINE_PINS["source-freshness-consumer"].sha,
});

export const c07 = Object.freeze({
  reservationHonesty: reservationMod.reservationHonesty,
  source: ENGINE_PINS["workability-gate-composer"].sha,
});

export { ENGINE_PINS };
