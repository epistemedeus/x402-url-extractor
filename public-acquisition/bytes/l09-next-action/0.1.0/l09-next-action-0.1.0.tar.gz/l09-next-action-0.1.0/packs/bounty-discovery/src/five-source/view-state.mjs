/**
 * Viewer-clock freshness for a dated snapshot.
 * Never returns live/realtime. Missing or unparseable stamps are unknown.
 */
import { isIsoClock } from "./clock.mjs";
import { STALE_AFTER_SECONDS } from "./policy.mjs";

export { isIsoClock };

export const VIEW_STATES = Object.freeze(["fresh", "stale", "unknown"]);

export function evaluateViewState({
  observedAt = null,
  capturedAt = null,
  staleAfterSeconds = STALE_AFTER_SECONDS,
  now,
} = {}) {
  const stamp = isIsoClock(observedAt) ? observedAt : capturedAt;
  if (!isIsoClock(stamp) || !isIsoClock(now)) return "unknown";
  const ttl = Number(staleAfterSeconds);
  if (!Number.isFinite(ttl) || ttl < 0) return "unknown";
  const ageMs = Date.parse(now) - Date.parse(stamp);
  if (!Number.isFinite(ageMs)) return "unknown";
  if (ageMs < 0) return "unknown";
  if (ageMs > ttl * 1000) return "stale";
  return "fresh";
}

export function evaluateSnapshotView(snapshot, now) {
  const capturedAt = snapshot?.capturedAt || null;
  const ttl = snapshot?.staleAfterSeconds ?? STALE_AFTER_SECONDS;
  const snapshotState = evaluateViewState({ capturedAt, staleAfterSeconds: ttl, now });
  const opportunities = Array.isArray(snapshot?.opportunities) ? snapshot.opportunities : [];
  return {
    now,
    snapshotViewState: snapshotState,
    opportunities: opportunities.map((row) => ({
      identity: row.identity,
      viewState: evaluateViewState({
        observedAt: row.observedAt,
        capturedAt,
        staleAfterSeconds: row.staleAfterSeconds ?? ttl,
        now,
      }),
    })),
  };
}
