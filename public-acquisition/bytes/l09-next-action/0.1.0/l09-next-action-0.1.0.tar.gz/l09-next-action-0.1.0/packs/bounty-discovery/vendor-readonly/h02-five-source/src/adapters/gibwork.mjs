import {
  SCHEMA_VERSION,
  classifyRewardPlanes,
  validateListing,
  adapterError,
  FORBIDDEN_ACTIONS,
} from "../contract.mjs";
import { createPublicGet } from "../http.mjs";

export const SOURCE_ID = "gibwork";
export const EXPLORE_URL = "https://api.gib.work/explore";
export const BOUNTY_LOCATOR_PREFIX = "https://app.gib.work/bounty/";

const HUMAN_PRESENCE_RE = /attend|x spaces?|live session|no ai generated/i;

function resolveNow(now) {
  const value = typeof now === "function" ? now() : now;
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string" && value.endsWith("Z") && Number.isFinite(Date.parse(value))) {
    return value;
  }
  return new Date().toISOString();
}

function finiteNumber(value) {
  if (value == null || value === "") return null;
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : null;
}

function publishedText(value) {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function listingStatus(task) {
  if (task?.isHidden === true) return "hidden";
  if (task?.isOpen === false) return "closed";
  const published = publishedText(task?.status);
  return published ? published : "open";
}

function classifyEligibility(task, locator) {
  const gates = [];
  if (task?.allowOnlyVerifiedSubmissions === true) gates.push("verified_subscription");
  const text = `${task?.title || ""}\n${task?.content || ""}`;
  if (HUMAN_PRESENCE_RE.test(text)) gates.push("human_presence_text");

  let agentAccess = "AGENT_ALLOWED";
  if (gates.includes("human_presence_text")) agentAccess = "HUMAN_ONLY";
  else if (gates.includes("verified_subscription")) agentAccess = "UNKNOWN";

  return Object.freeze({
    agentAccess,
    humanGates: Object.freeze(gates),
    plane: "source_published",
    evidenceRef: locator,
  });
}

function classifyReward(task, locator) {
  const asset = task?.asset && typeof task.asset === "object" ? task.asset : null;
  const price = finiteNumber(asset?.price);
  const remaining = finiteNumber(task?.remainingAmount);
  const symbol = publishedText(asset?.symbol);
  const mint = publishedText(asset?.mintAddress);

  const advertised = {
    amount: price == null ? null : String(asset.price),
    currency: symbol,
    asset: mint,
    plane: "source_published",
    evidenceRef: locator,
  };

  // remainingAmount + mint is a published remaining pool, not independently
  // verified escrow. Never promote this pair to reserved_observed.
  const reserved =
    remaining != null && remaining > 0 && mint
      ? {
          state: "promised",
          amount: String(task.remainingAmount),
          currency: symbol,
          asset: mint,
          plane: "source_published",
          evidenceRef: mint,
        }
      : undefined;

  return classifyRewardPlanes({
    advertised,
    reserved,
    settled: { state: "unknown", plane: "unknown", evidenceRef: null },
  });
}

function paginationFrom(raw) {
  const page = finiteNumber(raw?.page);
  const lastPage = finiteNumber(raw?.lastPage);
  const limit = finiteNumber(raw?.limit);
  const total = finiteNumber(raw?.total);
  return Object.freeze({
    page: page == null ? null : page,
    lastPage: lastPage == null ? null : lastPage,
    limit: limit == null ? null : limit,
    total: total == null ? null : total,
    hasMore: page != null && lastPage != null ? page < lastPage : false,
  });
}

function mapListing(task, { observedAt, provenanceKind, httpStatus, pagination }) {
  if (task == null || (typeof task.id !== "string" && typeof task.id !== "number")) return null;
  const listingId = String(task.id);
  if (!listingId) return null;
  const locator = `${BOUNTY_LOCATOR_PREFIX}${listingId}`;
  const sourceTimestamp =
    typeof task.deadline === "string" && task.deadline.endsWith("Z") && Number.isFinite(Date.parse(task.deadline))
      ? task.deadline
      : null;

  const listing = {
    schemaVersion: SCHEMA_VERSION,
    sourceId: SOURCE_ID,
    listingId,
    locator,
    observedAt,
    outcome: "observed",
    title: typeof task.title === "string" ? task.title : null,
    type: typeof task.type === "string" ? task.type : null,
    tags: Array.isArray(task.tags) ? Object.freeze([...task.tags]) : Object.freeze([]),
    deadline: sourceTimestamp,
    poster: publishedText(task.user?.username) || (task.user?.id != null ? String(task.user.id) : null),
    freshness: Object.freeze({
      state: "current",
      observedAt,
      sourceTimestamp,
    }),
    provenance: Object.freeze({
      kind: provenanceKind,
      capturedAt: observedAt,
      httpStatus,
      productionSettlement: false,
    }),
    eligibility: classifyEligibility(task, locator),
    reward: classifyReward(task, locator),
    claim: Object.freeze({
      method: "source_submission",
      conditions: Object.freeze([]),
      exclusive: null,
      slots: null,
      plane: "source_published",
    }),
    acceptance: Object.freeze({
      criteria: Object.freeze([]),
      adjudicator: "poster",
      deterministic: false,
      plane: "source_published",
    }),
    status: Object.freeze({
      listing: listingStatus(task),
      sourceIssue: null,
    }),
    contributorSignals: Object.freeze({
      submissions: null,
      comments: null,
      claims: null,
      lastUpdate: null,
      plane: "unknown",
    }),
    ingest: Object.freeze({ method: "json_get", pagination }),
    forbiddenAttempted: Object.freeze([]),
  };
  validateListing(listing);
  return Object.freeze(listing);
}

function collectionResult({
  observedAt,
  provenanceKind,
  httpStatus,
  locator,
  outcome,
  reason,
  listings,
  pagination,
  ingestStatus,
  challenge = null,
}) {
  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    sourceId: SOURCE_ID,
    listingId: "_adapter",
    locator,
    observedAt,
    outcome,
    reason,
    ingestStatus,
    challenge,
    listings: Object.freeze(listings),
    freshness: Object.freeze({ state: outcome === "observed" ? "current" : "unknown", observedAt, sourceTimestamp: null }),
    provenance: Object.freeze({
      kind: provenanceKind,
      capturedAt: observedAt,
      httpStatus,
      productionSettlement: false,
    }),
    eligibility: Object.freeze({
      agentAccess: "UNKNOWN",
      humanGates: Object.freeze([]),
      plane: "unknown",
      evidenceRef: null,
    }),
    reward: classifyRewardPlanes({}),
    claim: Object.freeze({ method: null, conditions: Object.freeze([]), exclusive: null, slots: null, plane: "unknown" }),
    acceptance: Object.freeze({
      criteria: Object.freeze([]),
      adjudicator: null,
      deterministic: null,
      plane: "unknown",
    }),
    status: Object.freeze({ listing: null, sourceIssue: null }),
    contributorSignals: Object.freeze({
      submissions: null,
      comments: null,
      claims: null,
      lastUpdate: null,
      plane: "unknown",
    }),
    ingest: Object.freeze({ method: "json_get", pagination }),
    forbiddenAttempted: Object.freeze([]),
  });
}

function failedCollection({ sourceId = SOURCE_ID, reason, observedAt, provenanceKind, httpStatus, locator, ingestStatus, challenge = null }) {
  return Object.freeze({
    ...adapterError({ sourceId, reason, observedAt, provenanceKind }),
    locator,
    ingestStatus,
    challenge,
    provenance: Object.freeze({
      kind: provenanceKind,
      capturedAt: observedAt,
      httpStatus,
      productionSettlement: false,
    }),
  });
}

export function createAdapter({
  now = () => new Date().toISOString(),
  fetchImpl,
  provenanceKind = "test",
} = {}) {
  const publicGet = createPublicGet({ fetchImpl });

  function observeListings(raw, meta = {}) {
    const observedAt = meta.observedAt || resolveNow(now);
    const httpStatus = meta.httpStatus ?? 200;
    const locator = meta.locator || EXPLORE_URL;
    const pagination = paginationFrom(raw);
    const rows = Array.isArray(raw?.results) ? raw.results : [];
    const listings = [];
    for (const task of rows) {
      const mapped = mapListing(task, { observedAt, provenanceKind, httpStatus, pagination });
      if (mapped) listings.push(mapped);
    }
    const total = pagination.total;
    const empty = listings.length === 0 && (total === 0 || total == null);
    if (empty) {
      return collectionResult({
        observedAt,
        provenanceKind,
        httpStatus,
        locator,
        outcome: "empty",
        reason: "empty",
        listings: [],
        pagination,
        ingestStatus: "supported",
      });
    }
    return collectionResult({
      observedAt,
      provenanceKind,
      httpStatus,
      locator,
      outcome: "observed",
      reason: null,
      listings,
      pagination,
      ingestStatus: "supported",
    });
  }

  async function ingest({ page = 1 } = {}) {
    const observedAt = resolveNow(now);
    const url = new URL(EXPLORE_URL);
    url.searchParams.set("page", String(page));
    const response = await publicGet(url.href);
    if (response.status === 404) {
      return failedCollection({
        reason: "tombstone",
        observedAt,
        provenanceKind,
        httpStatus: 404,
        locator: url.href,
        ingestStatus: "supported",
      });
    }
    if (response.challenge) {
      return failedCollection({
        reason: "error",
        observedAt,
        provenanceKind,
        httpStatus: response.status,
        locator: url.href,
        ingestStatus: "unsupported",
        challenge: response.challenge,
      });
    }
    if (!response.ok || response.status === 0 || !response.json || typeof response.json !== "object" || Array.isArray(response.json)) {
      return failedCollection({
        reason: "error",
        observedAt,
        provenanceKind,
        httpStatus: response.status,
        locator: url.href,
        ingestStatus: "unknown",
        challenge: response.challenge,
      });
    }
    return observeListings(response.json, {
      observedAt,
      httpStatus: response.status,
      locator: url.href,
    });
  }

  return Object.freeze({
    provider: SOURCE_ID,
    sourceId: SOURCE_ID,
    forbidden: FORBIDDEN_ACTIONS,
    capabilities: Object.freeze({ read: true, forbidden: FORBIDDEN_ACTIONS }),
    observeListings,
    ingest,
  });
}

export const createGibWorkAdapter = createAdapter;
