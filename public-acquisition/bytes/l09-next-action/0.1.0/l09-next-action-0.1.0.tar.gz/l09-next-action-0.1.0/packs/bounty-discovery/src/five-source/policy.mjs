/**
 * One freshness window for H02 ingest, C06 cards, and snapshot view-state.
 * 6 hours; age strictly greater than the window is stale (6h+1ms).
 */
export const FRESHNESS_MAX_AGE_MS = 6 * 60 * 60 * 1000;
export const STALE_AFTER_SECONDS = Math.floor(FRESHNESS_MAX_AGE_MS / 1000);
export const MAX_PAGES_CAP = 20;
export const MAX_RESPONSE_BYTES = 2_000_000;
export const MAX_REDIRECTS = 5;

export const C05_QUERY_FIELDS = Object.freeze([
  "adapter",
  "funding.class",
  "eligibility.agentAccess",
  "deadlineExpired",
  "do_not_start_work",
  "sourceQuality.grade",
  "freshness.stale",
]);

export const C05_QUERY_GRAMMAR =
  "C05 DSL: field=value clauses joined by AND. Allowed fields: " + C05_QUERY_FIELDS.join(", ") + ".";

export function freshnessPolicy(options = {}) {
  const raw = options.maxAgeMs;
  const maxAgeMs =
    raw == null || raw === ""
      ? FRESHNESS_MAX_AGE_MS
      : Number(raw);
  if (!Number.isFinite(maxAgeMs) || maxAgeMs < 0) {
    const err = new Error("maxAgeMs must be a non-negative number");
    err.code = "invalid_max_age";
    throw err;
  }
  return {
    maxAgeMs,
    staleAfterSeconds: Math.floor(maxAgeMs / 1000),
  };
}

export function parseMaxPages(raw, fallback = 1) {
  if (raw == null || raw === "") return fallback;
  if (typeof raw === "string" && String(raw).trim() === "") return fallback;
  const n = typeof raw === "number" ? raw : Number(raw);
  if (!Number.isInteger(n) || n < 1) {
    const err = new Error("maxPages must be a positive integer");
    err.code = "invalid_max_pages";
    err.hint = `Pass an integer from 1 to ${MAX_PAGES_CAP}.`;
    throw err;
  }
  return Math.min(n, MAX_PAGES_CAP);
}

export function adapterPageState({ cursor = null, pageNum = 1, take = 100 } = {}) {
  const page = Number(pageNum);
  const skip = Number.isInteger(page) && page > 1 ? (page - 1) * take : undefined;
  return {
    skip,
    cursor: cursor == null || cursor === "" ? undefined : cursor,
    page: Number.isInteger(page) && page > 0 ? page : 1,
    take,
  };
}

export function acquisitionKindFromCapture(capture) {
  const kind = capture?.provenanceKind || capture?.provenance?.kind;
  if (kind === "live_public") return "live_public";
  if (kind === "fixture" || kind === "test") return "fixture";
  if (capture?.mode === "live") return "live_public";
  return "fixture";
}
