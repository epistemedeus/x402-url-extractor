/**
 * Read-only TaskMarket public tasks adapter (GET /api/tasks).
 * Reward strings with Number(reward) >= 1000 are 6-decimal atomic USDC
 * (same /1e6 scale as tools/opportunity-radar). Raw atomic stays on listing.raw.
 * An escrowTxHash is a published promise, not independent chain verification.
 */

import {
  SCHEMA_VERSION,
  classifyRewardPlanes,
  validateListing,
  adapterError,
  FORBIDDEN_ACTIONS,
} from "../contract.mjs";

export const PROVIDER = "taskmarket";
export const TASKS_URL = "https://api.taskmarket.dev/api/tasks";
export const LISTING_BASE = "https://taskmarket.dev/tasks";

const ATOMIC_THRESHOLD = 1000;
const USDC_DECIMALS = 1e6;
const TX_HASH = /^0x[0-9a-fA-F]{8,}$/;

function isoNow(now) {
  if (typeof now === "function") return isoNow(now());
  if (now instanceof Date) return now.toISOString();
  if (typeof now === "number" && Number.isFinite(now)) return new Date(now).toISOString();
  if (typeof now === "string" && Number.isFinite(Date.parse(now))) {
    return now.endsWith("Z") ? now : new Date(now).toISOString();
  }
  return new Date().toISOString();
}

function toIsoZ(value) {
  if (typeof value === "string" && Number.isFinite(Date.parse(value))) {
    return value.endsWith("Z") ? value : new Date(value).toISOString();
  }
  if (typeof value === "number" && Number.isFinite(value)) return new Date(value).toISOString();
  return null;
}

function isTxHash(value) {
  return typeof value === "string" && TX_HASH.test(value);
}

function advertisedFromReward(reward) {
  if (reward == null || reward === "") {
    return { amount: null, currency: null, asset: null, plane: "unknown", evidenceRef: null };
  }
  const numeric = Number(reward);
  if (!Number.isFinite(numeric)) {
    return { amount: null, currency: null, asset: null, plane: "unknown", evidenceRef: null };
  }
  const amount = numeric >= ATOMIC_THRESHOLD ? (numeric / USDC_DECIMALS).toString() : numeric.toString();
  return {
    amount,
    currency: "USDC",
    asset: "USDC",
    plane: "source_published",
    evidenceRef: "reward",
  };
}

function paginationOf(body) {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return { hasMore: null, nextCursor: null };
  }
  const hasMore = typeof body.hasMore === "boolean" ? body.hasMore : null;
  const nextCursor = body.nextCursor == null || body.nextCursor === "" ? null : String(body.nextCursor);
  return { hasMore, nextCursor };
}

function pageEnvelope({
  observedAt,
  outcome,
  reason = null,
  listings = [],
  hasMore = null,
  nextCursor = null,
  cursor = null,
  httpStatus = null,
  provenanceKind = "test",
}) {
  return {
    schemaVersion: SCHEMA_VERSION,
    sourceId: PROVIDER,
    listingId: "_adapter",
    locator: TASKS_URL,
    observedAt,
    outcome,
    reason,
    freshness: { state: outcome === "observed" ? "current" : "unknown", observedAt, sourceTimestamp: null },
    provenance: { kind: provenanceKind, capturedAt: observedAt, httpStatus, productionSettlement: false },
    eligibility: { agentAccess: "UNKNOWN", humanGates: [], plane: "unknown", evidenceRef: null },
    reward: classifyRewardPlanes({}),
    claim: { method: null, conditions: [], exclusive: null, slots: null, plane: "unknown" },
    acceptance: { criteria: [], adjudicator: null, deterministic: null, plane: "unknown" },
    status: { listing: null, sourceIssue: null },
    contributorSignals: { submissions: null, comments: null, claims: null, lastUpdate: null, plane: "unknown" },
    ingest: { method: "json_get", pagination: { hasMore, nextCursor, cursor } },
    hasMore,
    nextCursor,
    listings,
    forbiddenAttempted: [],
  };
}

function eligibilityOf(task) {
  if (task.hasAccessPassword === true) {
    return {
      agentAccess: "UNKNOWN",
      humanGates: ["access_password"],
      plane: "source_published",
      evidenceRef: "hasAccessPassword",
    };
  }
  return {
    agentAccess: "AGENT_ALLOWED",
    humanGates: [],
    plane: "source_published",
    evidenceRef: "mode",
  };
}

function mapTask(task, { observedAt, provenanceKind, httpStatus }) {
  if (!task || typeof task !== "object" || task.id == null || String(task.id).trim() === "") return null;
  const listingId = String(task.id);
  const expiryIso = toIsoZ(task.expiryTime);
  const createdIso = toIsoZ(task.createdAt);
  const sourceTimestamp = expiryIso || createdIso;
  const expired = expiryIso != null && Date.parse(expiryIso) < Date.parse(observedAt);
  const sourceStatus = task.status == null ? null : String(task.status);
  const listingStatus = expired && sourceStatus !== "completed" ? "expired" : sourceStatus;
  const windowOpen = task.submissionWindowOpen !== false;
  const submissions = Number.isFinite(Number(task.submissionCount)) ? Number(task.submissionCount) : null;
  const advertised = advertisedFromReward(task.reward);
  const reserved = isTxHash(task.escrowTxHash)
    ? {
        state: "promised",
        amount: null,
        currency: null,
        asset: null,
        plane: "source_published",
        evidenceRef: task.escrowTxHash,
      }
    : { state: "unknown", amount: null, currency: null, asset: null, plane: "unknown", evidenceRef: null };
  const benchmark = task.mode === "benchmark" && task.metricTarget != null && String(task.metricTarget).trim() !== "";
  const criteria = [task.metricDescription, task.metricTarget].filter((value) => value != null && String(value).trim() !== "").map(String);

  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    sourceId: PROVIDER,
    listingId,
    locator: `${LISTING_BASE}/${encodeURIComponent(listingId)}`,
    observedAt,
    outcome: "observed",
    freshness: {
      state: "current",
      observedAt,
      sourceTimestamp,
    },
    provenance: {
      kind: provenanceKind,
      capturedAt: observedAt,
      httpStatus,
      productionSettlement: false,
    },
    eligibility: eligibilityOf(task),
    reward: classifyRewardPlanes({ advertised, reserved, settled: { state: "unknown" } }),
    claim: {
      method: "source_submission",
      conditions: windowOpen ? [] : ["submission_window_closed"],
      exclusive: null,
      slots: null,
      accepting: windowOpen,
      submissions,
      plane: "source_published",
    },
    acceptance: {
      criteria,
      adjudicator: benchmark ? "metric" : "poster",
      deterministic: benchmark,
      plane: "source_published",
    },
    status: { listing: listingStatus, sourceIssue: sourceStatus },
    contributorSignals: {
      submissions,
      comments: null,
      claims: null,
      lastUpdate: toIsoZ(task.claimedAt),
      plane: "source_published",
    },
    ingest: { method: "json_get", pagination: null },
    forbiddenAttempted: [],
    title: typeof task.description === "string" ? task.description.slice(0, 120) : listingId,
    raw: Object.freeze({
      rawAtomic: task.reward == null ? null : String(task.reward),
      netReward: task.netReward == null ? null : String(task.netReward),
      escrowTxHash: task.escrowTxHash ?? null,
      mode: task.mode ?? null,
      referenceCode: task.referenceCode ?? null,
      platformFeeBps: task.platformFeeBps ?? null,
      hasAccessPassword: task.hasAccessPassword === true,
      stakeRequired: task.stakeRequired ?? null,
      requester: task.requester ?? null,
      claimedAt: task.claimedAt ?? null,
      claimedBy: task.claimedBy ?? null,
      submissionWindowOpen: task.submissionWindowOpen ?? null,
      metricDescription: task.metricDescription ?? null,
      metricTarget: task.metricTarget ?? null,
      tags: Array.isArray(task.tags) ? task.tags : [],
    }),
  });
}

export function createAdapter({ fetchImpl, now } = {}) {
  function observeListings(body, options = {}) {
    const observedAt = options.observedAt ?? isoNow(now);
    const provenanceKind = options.provenanceKind ?? "fixture";
    const httpStatus = options.httpStatus ?? null;
    const cursor = options.cursor ?? null;
    const { hasMore, nextCursor } = paginationOf(body);

    if (!body || typeof body !== "object" || !Array.isArray(body.tasks)) {
      return pageEnvelope({
        observedAt,
        outcome: "unknown",
        reason: "malformed",
        hasMore,
        nextCursor,
        cursor,
        httpStatus,
        provenanceKind,
      });
    }

    const listings = body.tasks
      .map((task) => mapTask(task, { observedAt, provenanceKind, httpStatus }))
      .filter(Boolean)
      .map((listing) => {
        validateListing(listing);
        return listing;
      });

    if (body.tasks.length === 0) {
      return pageEnvelope({
        observedAt,
        outcome: "empty",
        reason: "empty",
        listings: [],
        hasMore,
        nextCursor,
        cursor,
        httpStatus,
        provenanceKind,
      });
    }

    return pageEnvelope({
      observedAt,
      outcome: "observed",
      listings,
      hasMore,
      nextCursor,
      cursor,
      httpStatus,
      provenanceKind,
    });
  }

  async function ingest({ cursor } = {}) {
    const observedAt = isoNow(now);
    if (typeof fetchImpl !== "function") {
      return adapterError({ sourceId: PROVIDER, reason: "error", observedAt, provenanceKind: "test" });
    }
    const url = new URL(TASKS_URL);
    if (cursor != null && String(cursor).length > 0) url.searchParams.set("cursor", String(cursor));
    let response;
    try {
      response = await fetchImpl(url.href, {
        method: "GET",
        redirect: "follow",
        headers: {
          accept: "application/json",
          "user-agent": "W5-H02-public-ingest/0.1 (+https://samedaydesk.com; read-only)",
        },
      });
    } catch {
      return adapterError({ sourceId: PROVIDER, reason: "error", observedAt, provenanceKind: "test" });
    }

    const httpStatus = response?.status ?? 0;
    let body = null;
    try {
      if (typeof response?.json === "function") body = await response.json();
      else if (typeof response?.text === "function") {
        const text = await response.text();
        body = text ? JSON.parse(text) : null;
      }
    } catch {
      return pageEnvelope({
        observedAt,
        outcome: "unknown",
        reason: "malformed",
        httpStatus,
        provenanceKind: "test",
        cursor: cursor ?? null,
      });
    }

    if (!response || response.ok === false || httpStatus === 0) {
      return adapterError({ sourceId: PROVIDER, reason: "error", observedAt, provenanceKind: "test" });
    }

    return observeListings(body, {
      observedAt,
      provenanceKind: "test",
      httpStatus,
      cursor: cursor ?? null,
    });
  }

  return Object.freeze({
    provider: PROVIDER,
    capabilities: Object.freeze({
      read: true,
      write: false,
      login: false,
      claim: false,
      wallet: false,
      ingestMethod: "json_get",
      forbidden: FORBIDDEN_ACTIONS,
    }),
    ingest,
    observeListings,
  });
}
