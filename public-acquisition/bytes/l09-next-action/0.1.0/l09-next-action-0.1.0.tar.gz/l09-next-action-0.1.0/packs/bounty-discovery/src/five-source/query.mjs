/**
 * Canonical five-source query: clock, H02 ingest, F03/C06/C07 compile.
 */
import { compileFiveSourceQuery } from "./compile.mjs";
import { assertQueryClock } from "./clock.mjs";
import { c05, c06, c07, enginePins } from "../engines.mjs";

export { assertQueryClock } from "./clock.mjs";
export { jobCardFromListing } from "./job-card-from-listing.mjs";
export { compileFiveSourceQuery } from "./compile.mjs";

export function fiveSourceEngines() {
  return { c05, c06, c07, enginePins };
}

export async function queryFiveSource(options = {}) {
  assertQueryClock(options.now, { allowDefault: false });
  return compileFiveSourceQuery(fiveSourceEngines(), {
    ...options,
    allowFixtureSeed: options.allowFixtureSeed === true,
  });
}
