import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { queryFiveSource } from "./five-source/query.mjs";
import { projectSnapshot } from "./five-source/snapshot.mjs";
import { evaluateSnapshotView } from "./five-source/view-state.mjs";
import { parseMaxPages } from "./five-source/policy.mjs";
import { KIT_ROOT } from "./engines.mjs";

const DEFAULT_CAPTURE = join(KIT_ROOT, "captures/live-2026-09-11T23-24-00-000Z");
const USAGE = `bounty-discovery query - dated five-source compile

Usage:
  node bin/query.mjs query --mode cached --now 2026-09-11T23:24:00.000Z [--capture-dir DIR] [--query adapter=taskmarket]
  node bin/query.mjs query --mode live --now <ISO-Z> [--max-pages 1]
  node bin/query.mjs snapshot --mode cached --now 2026-09-11T23:24:00.000Z [--out FILE]
  node bin/query.mjs view --snapshot FILE --now <ISO-Z>

Invalid now is refused before any public GET.
cached mode cannot take a fetch implementation.
Live mode performs bounded public GETs (default maxPages=1, cap 20).
This CLI does not claim, bid, or pay. claimAuthority is none.
`;

function argValue(argv, name) {
  const prefix = `${name}=`;
  const eq = argv.find((item) => item.startsWith(prefix));
  if (eq) return eq.slice(prefix.length);
  const index = argv.indexOf(name);
  if (index === -1) return null;
  return argv[index + 1] || null;
}

function fail(code, message) {
  const err = new Error(message);
  err.code = code;
  throw err;
}

export async function main(argv = process.argv.slice(2)) {
  const command = argv[0] || "help";
  if (command === "help" || command === "--help" || command === "-h") {
    process.stdout.write(USAGE);
    return 0;
  }

  if (command === "view") {
    const snapshotPath = argValue(argv, "--snapshot");
    const now = argValue(argv, "--now");
    if (!snapshotPath) fail("missing_operand", "--snapshot is required");
    const { readFileSync } = await import("node:fs");
    const snapshot = JSON.parse(readFileSync(resolve(snapshotPath), "utf8"));
    const view = evaluateSnapshotView(snapshot, now);
    process.stdout.write(`${JSON.stringify(view, null, 2)}\n`);
    return 0;
  }

  if (command !== "query" && command !== "snapshot") {
    fail("unknown_command", `unknown command ${command}`);
  }

  const mode = argValue(argv, "--mode");
  const now = argValue(argv, "--now");
  const captureDir = argValue(argv, "--capture-dir") || (mode === "cached" ? DEFAULT_CAPTURE : undefined);
  const maxPages = parseMaxPages(argValue(argv, "--max-pages") || 1);
  const query = argValue(argv, "--query");
  const out = argValue(argv, "--out");

  const compiled = await queryFiveSource({
    mode,
    now,
    maxPages,
    captureDir,
    query,
    allowFixtureSeed: false,
  });

  const payload = command === "snapshot" ? projectSnapshot(compiled, { maxPages }) : compiled;
  const text = `${JSON.stringify(payload, null, 2)}\n`;
  if (out) {
    mkdirSync(dirname(resolve(out)), { recursive: true });
    writeFileSync(out, text);
  } else {
    process.stdout.write(text);
  }
  return 0;
}

const thisFile = fileURLToPath(import.meta.url);
if (process.argv[1] && resolve(process.argv[1]) === thisFile) {
  main().catch((err) => {
    process.stderr.write(`${err.code || "error"}: ${err.message}\n`);
    process.exit(err.code === "invalid_now" || err.code === "mode_mix_rejected" ? 2 : 1);
  });
}
