import { classifyRewardPlanes } from "./contract.mjs";

function fail(code, detail = code) {
  const error = new TypeError(detail);
  error.code = code;
  throw error;
}

function blankToNull(value) {
  if (value == null) return null;
  if (typeof value === "string" && value.trim() === "") return null;
  return value;
}

function nonBlankRef(value) {
  if (typeof value !== "string") return null;
  return value.trim() ? value : null;
}

function hasOwnEvidence(plane) {
  return Boolean(String(plane?.evidenceRef || "").trim());
}

function amountsMatch(left, right) {
  if (left == null || right == null) return false;
  if (String(left) === String(right)) return true;
  const a = Number(left);
  const b = Number(right);
  return Number.isFinite(a) && Number.isFinite(b) && a === b;
}

function coercePlane(value) {
  if (value == null) return { amount: null, evidenceRef: null };
  if (typeof value === "number" || typeof value === "string") {
    return { amount: value, evidenceRef: null };
  }
  return value;
}

function remainingIsPromised(remainingAmount) {
  if (remainingAmount == null || remainingAmount === "") return false;
  const n = Number(remainingAmount);
  return Number.isFinite(n) && n > 0;
}

const STATUS_LABELS_THAT_ARE_NOT_SETTLEMENT = Object.freeze([
  "PAID",
  "completed",
  "winners_announced",
  "funded",
]);

/**
 * Never copy advertised.amount into reserved/settled.
 * A published display figure is advertised-only unless reserved arrives with its own evidence.
 */
export function fromSourcePublished({
  advertisedAmount,
  advertisedCurrency,
  advertisedRef,
  reserved,
} = {}) {
  const advertised = {
    amount: advertisedAmount ?? null,
    currency: blankToNull(advertisedCurrency),
    asset: null,
    plane:
      advertisedAmount != null || blankToNull(advertisedCurrency) != null || nonBlankRef(advertisedRef)
        ? "source_published"
        : "unknown",
    evidenceRef: advertisedRef ?? null,
  };
  const reservedPlane = reserved && typeof reserved === "object" ? reserved : undefined;
  rejectPromotion(advertised, reservedPlane, undefined);
  return classifyRewardPlanes({
    advertised,
    reserved: reservedPlane,
  });
}

/**
 * An escrow hash is source_published promised, not reserved_observed.
 * This helper does not verify chain inclusion.
 */
export function fromEscrowHash({
  advertisedAmount,
  advertisedCurrency,
  advertisedRef,
  escrowTxHash,
} = {}) {
  const hash = nonBlankRef(escrowTxHash);
  const advertised = {
    amount: advertisedAmount ?? null,
    currency: blankToNull(advertisedCurrency),
    asset: null,
    plane:
      advertisedAmount != null || nonBlankRef(advertisedRef)
        ? "source_published"
        : "unknown",
    evidenceRef: advertisedRef ?? null,
  };
  const reserved = hash
    ? {
        state: "promised",
        amount: null,
        currency: null,
        asset: null,
        plane: "source_published",
        evidenceRef: hash,
      }
    : undefined;
  rejectPromotion(advertised, reserved, undefined);
  return classifyRewardPlanes({ advertised, reserved });
}

/**
 * remaining may equal pool because remaining is its own field, not a copy of advertised.
 * remaining === pool is never settlement. remaining null keeps reserved unknown.
 */
export function fromRemainingPool({
  poolAmount,
  remainingAmount,
  currency,
  assetRef,
  locator,
} = {}) {
  const asset = blankToNull(assetRef);
  const unit = blankToNull(currency);
  const advertised = {
    amount: poolAmount ?? null,
    currency: unit,
    asset,
    plane: poolAmount != null || nonBlankRef(locator) ? "source_published" : "unknown",
    evidenceRef: locator ?? null,
  };
  const reserved = remainingIsPromised(remainingAmount)
    ? {
        state: "promised",
        amount: remainingAmount,
        currency: unit,
        asset,
        plane: "source_published",
        evidenceRef: locator ?? null,
      }
    : undefined;
  return classifyRewardPlanes({ advertised, reserved });
}

/**
 * Throws if reserved/settled amounts were copied from advertised without their own evidence.
 */
export function rejectPromotion(advertised, reserved, settled) {
  let adv = advertised;
  let res = reserved;
  let set = settled;
  if (
    arguments.length <= 1 &&
    advertised &&
    typeof advertised === "object" &&
    advertised.amount === undefined &&
    ("advertised" in advertised || "reserved" in advertised || "settled" in advertised)
  ) {
    adv = advertised.advertised;
    res = advertised.reserved;
    set = advertised.settled;
  }
  adv = coercePlane(adv);
  res = coercePlane(res);
  set = coercePlane(set);

  if (amountsMatch(adv.amount, res.amount) && !hasOwnEvidence(res)) {
    fail("reward_promotion", "reserved amount copied from advertised without evidence");
  }
  if (amountsMatch(adv.amount, set.amount) && !hasOwnEvidence(set)) {
    fail("reward_promotion", "settled amount copied from advertised without evidence");
  }
  return true;
}

/** currency/asset null stays unknown, does not default USDC */
export function missingAsset(advertised = {}) {
  const currency = blankToNull(advertised?.currency);
  const asset = blankToNull(advertised?.asset);
  return classifyRewardPlanes({
    advertised: {
      amount: advertised?.amount ?? null,
      currency,
      asset,
      plane: advertised?.plane ?? (advertised?.amount != null ? "source_published" : "unknown"),
      evidenceRef: advertised?.evidenceRef ?? null,
    },
  });
}

/**
 * Status labels are not settlement. Settlement requires a funded plane plus evidenceRef.
 */
export function labelIsNotSettlement(label) {
  if (label == null) return true;
  const raw = String(label);
  const lower = raw.trim().toLowerCase();
  for (const item of STATUS_LABELS_THAT_ARE_NOT_SETTLEMENT) {
    if (raw === item || lower === item.toLowerCase()) return true;
  }
  return true;
}

/** Source JSON with no reward field stays unknown on every plane. */
export function fromSourceJson(source) {
  if (source == null || typeof source !== "object") {
    return fromSourcePublished();
  }
  if (!Object.hasOwn(source, "reward") || source.reward == null) {
    return fromSourcePublished();
  }
  const reward = source.reward;
  if (typeof reward === "object") {
    return fromSourcePublished({
      advertisedAmount: reward.amount ?? null,
      advertisedCurrency: reward.currency ?? null,
      advertisedRef: reward.evidenceRef ?? source.locator ?? null,
      reserved: reward.reserved,
    });
  }
  return fromSourcePublished({ advertisedAmount: reward });
}
