# bounty-discovery

Node 22+ extract. Compile public listings through H02 ingest and C05/C06/C07.

```
node --experimental-strip-types --disable-warning=ExperimentalWarning bin/query.mjs help
node bin/query.mjs snapshot --mode cached --now 2026-09-11T23:24:00.000Z
node bin/query.mjs query --mode live --now 2026-09-12T00:00:00.000Z --max-pages 1
node --test --experimental-strip-types --disable-warning=ExperimentalWarning tests/*.test.mjs
```

`cached` replays `captures/`. `live` does bounded public GETs. Invalid `now` fails before fetch. Cached mode rejects a fetch implementation.

Output contract: `neomorphic.bounty-discovery.snapshot.v1` / `1.0.0`. Pack `1.0.3`. Dated snapshot, not a live feed. This extract has no HTTP daemon and no MCP server. claimAuthority remains none.
