const NAMES = Object.freeze([
  "superteam",
  "taskmarket",
  "gibwork",
  "gofrantic",
  "agentbounties",
  "bountyhub-unsupported",
]);

export async function loadAdapters() {
  const loaded = [];
  const missing = [];
  for (const name of NAMES) {
    try {
      const mod = await import(`./${name}.mjs`);
      loaded.push({ name, createAdapter: mod.createAdapter });
    } catch {
      missing.push(name);
    }
  }
  return { loaded, missing, names: NAMES };
}

export { NAMES as ADAPTER_NAMES };
