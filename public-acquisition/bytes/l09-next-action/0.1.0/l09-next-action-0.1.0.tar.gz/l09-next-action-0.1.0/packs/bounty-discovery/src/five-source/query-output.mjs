/**
 * Isolated atomic per-query artifacts. Acquisition (captures) is never rewritten
 * by replay. Card filenames hash the full opaque observation key.
 */
import { createHash, randomBytes } from "node:crypto";
import { lstatSync, mkdirSync, mkdtempSync, renameSync, rmSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { tmpdir } from "node:os";

export function observationArtifactId(observationKey) {
  return createHash("sha256").update(String(observationKey ?? ""), "utf8").digest("hex");
}

function requireVacant(path) {
  try {
    lstatSync(path);
  } catch (err) {
    if (err.code === "ENOENT") return;
    throw err;
  }
  const err = new Error("query output already exists; choose a new directory");
  err.code = "query_output_exists";
  throw err;
}

export function createAtomicQueryOutput({ queriedAt, queryOutputDir } = {}) {
  const stamp = String(queriedAt || "clock").replace(/[:.]/g, "-");
  const nonce = randomBytes(6).toString("hex");
  const finalDir = resolve(
    queryOutputDir || join(tmpdir(), "c10-query-output", `q-${stamp}-${nonce}`),
  );
  requireVacant(finalDir);
  mkdirSync(dirname(finalDir), { recursive: true });
  const staging = mkdtempSync(`${finalDir}.staging-`);
  mkdirSync(join(staging, "f03-cards"));
  let committed = false;
  return {
    staging,
    finalDir,
    cardsDir: join(staging, "f03-cards"),
    commit() {
      requireVacant(finalDir);
      // Every committed target contains f03-cards. A concurrent directory rename
      // therefore cannot replace a committed result, even after the check above.
      renameSync(staging, finalDir);
      committed = true;
      return { queryOutputDir: finalDir, cardsDir: join(finalDir, "f03-cards") };
    },
    abort() {
      if (!committed) rmSync(staging, { recursive: true, force: true });
    },
  };
}
