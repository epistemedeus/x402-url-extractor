import { AGENT_ACCESS } from "./contract.mjs";

const KNOWN = new Set(AGENT_ACCESS);

/**
 * Classify agent eligibility from already-public fields only.
 * Never fetches login walls, never infers eligibility from HTTP 401 on a claim URL.
 * This is H02 source-field labeling. C10 claimability is F03 packetFromRecord.
 */
export function classifyAgentEligibility({
  agentAccessField,
  humanGateFields = [],
  textSignals = [],
} = {}) {
  const gates = [];
  for (const gate of humanGateFields) {
    if (gate) gates.push(String(gate));
  }
  for (const signal of textSignals) {
    if (signal) gates.push(String(signal));
  }

  let agentAccess = "UNKNOWN";
  if (typeof agentAccessField === "string" && KNOWN.has(agentAccessField)) {
    agentAccess = agentAccessField;
  }

  const uniqueGates = [...new Set(gates)];
  if (agentAccess === "UNKNOWN" && uniqueGates.includes("human_claimant_required")) {
    agentAccess = "HUMAN_ONLY";
  }

  return Object.freeze({
    agentAccess,
    humanGates: Object.freeze(uniqueGates),
    plane: typeof agentAccessField === "string" && KNOWN.has(agentAccessField) ? "source_published" : (uniqueGates.length ? "source_published" : "unknown"),
    probedLogin: false,
  });
}

export function eligibilityFromSuperteam(listing) {
  return classifyAgentEligibility({
    agentAccessField: listing?.agentAccess,
    humanGateFields: listing?.agentAccess === "HUMAN_ONLY" ? ["human_claimant_required"] : [],
  });
}

export function eligibilityFromTaskmarket(listing) {
  const gates = [];
  if (listing?.hasAccessPassword === true) gates.push("access_password");
  return classifyAgentEligibility({
    agentAccessField: gates.length ? "UNKNOWN" : "AGENT_ALLOWED",
    humanGateFields: gates,
  });
}

export function eligibilityFromGibwork(listing) {
  const gates = [];
  if (listing?.allowOnlyVerifiedSubmissions === true) gates.push("verified_subscription");
  const text = `${listing?.title || ""}\n${listing?.content || ""}`;
  if (/attend|x spaces?|live session|no ai generated/i.test(text)) gates.push("human_presence_text");
  const access = gates.includes("human_presence_text") ? "HUMAN_ONLY" : "AGENT_ALLOWED";
  return classifyAgentEligibility({
    agentAccessField: access,
    humanGateFields: gates,
  });
}
