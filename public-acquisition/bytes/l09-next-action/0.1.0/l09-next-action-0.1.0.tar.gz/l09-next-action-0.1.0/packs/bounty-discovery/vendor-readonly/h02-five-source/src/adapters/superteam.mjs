import {
  SCHEMA_VERSION,
  classifyRewardPlanes,
  adapterError,
  AGENT_ACCESS,
  FORBIDDEN_ACTIONS,
} from "../contract.mjs";
import { eligibilityFromSuperteam } from "../eligibility.mjs";
import { createPublicGet } from "../http.mjs";

export const SOURCE_ID = "superteam-earn";
export const LISTINGS_URL = "https://superteam.fun/api/listings/";
const DEFAULT_TAKE = 100;
const KNOWN_ACCESS = new Set(AGENT_ACCESS.filter((value) => value !== "UNKNOWN"));

function resolveNow(now) {
  const value = typeof now === "function" ? now() : now;
  if (typeof value === "string" && Number.isFinite(Date.parse(value)) && value.endsWith("Z")) {
    return value;
  }
  if (value instanceof Date && Number.isFinite(value.getTime())) return value.toISOString();
  return new Date().toISOString();
}

function asIsoZ(value) {
  if (value == null || value === "") return null;
  if (typeof value === "string" && Number.isFinite(Date.parse(value))) {
    return value.endsWith("Z") ? value : new Date(value).toISOString();
  }
  if (typeof value === "number" && Number.isFinite(value)) return new Date(value).toISOString();
  return null;
}

function normalizePage(page) {
  if (page == null) return { take: DEFAULT_TAKE, skip: undefined };
  if (typeof page === "number" && Number.isFinite(page)) return { take: page, skip: undefined };
  const takeRaw = page.take ?? page.limit;
  const take = Number.isFinite(Number(takeRaw)) ? Number(takeRaw) : DEFAULT_TAKE;
  const skip = page.skip === undefined || page.skip === null ? undefined : Number(page.skip);
  return { take, skip: Number.isFinite(skip) ? skip : undefined };
}

function listingsUrl({ take, skip }) {
  const url = new URL(LISTINGS_URL);
  url.searchParams.set("take", String(take));
  if (skip !== undefined) url.searchParams.set("skip", String(skip));
  return url.href;
}

function decorate(envelope, { httpStatus, pagination, locator } = {}) {
  return Object.freeze({
    ...envelope,
    locator: locator === undefined ? envelope.locator : locator,
    provenance: Object.freeze({
      ...envelope.provenance,
      httpStatus: httpStatus === undefined ? envelope.provenance.httpStatus : httpStatus,
    }),
    ingest: Object.freeze({
      method: "json_get",
      pagination: pagination === undefined ? envelope.ingest.pagination : pagination,
    }),
  });
}

function locatorFor(raw) {
  return typeof raw?.slug === "string" && raw.slug
    ? `https://superteam.fun/earn/listing/${raw.slug}`
    : null;
}

function isDeleted(raw) {
  return raw?.deleted === true || raw?.tombstone === true || raw?.status === "DELETED";
}

function advertisedReward(raw, locator) {
  const range = raw?.compensationType === "range";
  const amount =
    !range && typeof raw?.rewardAmount === "number" && Number.isFinite(raw.rewardAmount)
      ? String(raw.rewardAmount)
      : null;
  return {
    amount,
    currency: typeof raw?.token === "string" ? raw.token : null,
    plane: "source_published",
    evidenceRef: locator,
  };
}

function rewardRangeOf(raw) {
  if (raw?.compensationType !== "range") return null;
  return Object.freeze({
    min: raw.minRewardAsk ?? null,
    max: raw.maxRewardAsk ?? null,
    currency: typeof raw.token === "string" ? raw.token : null,
  });
}

function mapListing(raw, { observedAt, provenanceKind, httpStatus, pagination }) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
  const listingId = raw.id != null ? String(raw.id) : typeof raw.slug === "string" ? raw.slug : "";
  if (!listingId) return null;

  const locator = locatorFor(raw);
  const classified = eligibilityFromSuperteam(raw);
  const agentAccess = KNOWN_ACCESS.has(raw.agentAccess) ? raw.agentAccess : classified.agentAccess;
  const deleted = isDeleted(raw);
  const listingStatus = typeof raw.status === "string" ? raw.status : null;
  const sourceTimestamp = asIsoZ(raw.deadline) || asIsoZ(raw.winnersAnnouncedAt);

  const listing = {
    schemaVersion: SCHEMA_VERSION,
    sourceId: SOURCE_ID,
    listingId,
    locator,
    title: typeof raw.title === "string" ? raw.title : null,
    type: typeof raw.type === "string" ? raw.type : null,
    observedAt,
    outcome: deleted ? "tombstone" : "observed",
    freshness: Object.freeze({
      state: deleted ? "deleted" : "current",
      observedAt,
      sourceTimestamp,
    }),
    provenance: Object.freeze({
      kind: provenanceKind,
      capturedAt: observedAt,
      httpStatus: httpStatus ?? null,
      productionSettlement: false,
    }),
    eligibility: Object.freeze({
      agentAccess,
      humanGates: classified.humanGates,
      plane: classified.plane,
      evidenceRef: locator ?? "agentAccess",
    }),
    // Public rewardAmount is display only. Earn listings do not expose escrow.
    reward: classifyRewardPlanes({
      advertised: advertisedReward(raw, locator),
      reserved: { state: "unknown", plane: "unknown", evidenceRef: null },
      settled: { state: "unknown", plane: "unknown", evidenceRef: null },
    }),
    rewardRange: rewardRangeOf(raw),
    claim: Object.freeze({
      method: typeof raw.type === "string" ? raw.type : null,
      conditions: Object.freeze([]),
      exclusive: null,
      slots: null,
      plane: "source_published",
    }),
    // Winners announced is poster adjudication, not a settlement observation.
    acceptance: Object.freeze({
      criteria: Object.freeze([]),
      adjudicator: "poster",
      deterministic: false,
      plane: "source_published",
    }),
    status: Object.freeze({
      listing: deleted ? listingStatus || "DELETED" : listingStatus,
      sourceIssue: null,
    }),
    contributorSignals: Object.freeze({
      submissions: Number.isFinite(raw._count?.Submission) ? raw._count.Submission : null,
      comments: Number.isFinite(raw._count?.Comments) ? raw._count.Comments : null,
      claims: null,
      lastUpdate: null,
      plane: "source_published",
    }),
    ingest: Object.freeze({ method: "json_get", pagination: pagination ?? null }),
    forbiddenAttempted: Object.freeze([]),
    sponsor: raw.sponsor && typeof raw.sponsor === "object"
      ? Object.freeze({
          name: raw.sponsor.name ?? null,
          slug: raw.sponsor.slug ?? null,
          isVerified: raw.sponsor.isVerified ?? null,
        })
      : null,
    compensationType: typeof raw.compensationType === "string" ? raw.compensationType : null,
    isWinnersAnnounced: raw.isWinnersAnnounced === true,
  };
  return Object.freeze(listing);
}

function failEnvelope({ provenanceKind, now, reason, httpStatus, pagination, locator }) {
  return decorate(
    adapterError({
      sourceId: SOURCE_ID,
      reason,
      observedAt: resolveNow(now),
      provenanceKind,
    }),
    { httpStatus, pagination, locator },
  );
}

export function createAdapter({ fetchImpl, now, provenanceKind = "fixture" } = {}) {
  const kind = provenanceKind === "live_public" || provenanceKind === "test" || provenanceKind === "fixture"
    ? provenanceKind
    : "fixture";

  function observeListings(raw, extra = {}) {
    const observedAt = resolveNow(now);
    const httpStatus = extra.httpStatus ?? null;
    const locator = extra.locator ?? LISTINGS_URL;
    if (!Array.isArray(raw)) {
      return failEnvelope({
        provenanceKind: kind,
        now: observedAt,
        reason: "malformed",
        httpStatus,
        pagination: extra.pagination ?? null,
        locator,
      });
    }

    const take = extra.pagination?.take ?? extra.take ?? raw.length;
    const pagination = extra.pagination ?? {
      take,
      count: raw.length,
      hasMore: raw.length === take && take > 0,
    };

    if (raw.length === 0) {
      return failEnvelope({
        provenanceKind: kind,
        now: observedAt,
        reason: "empty",
        httpStatus,
        pagination: { take: pagination.take, count: 0, hasMore: false },
        locator,
      });
    }

    const listings = [];
    for (const item of raw) {
      const mapped = mapListing(item, {
        observedAt,
        provenanceKind: kind,
        httpStatus,
        pagination,
      });
      if (mapped) listings.push(mapped);
    }

    if (listings.length === 0) {
      return failEnvelope({
        provenanceKind: kind,
        now: observedAt,
        reason: "malformed",
        httpStatus,
        pagination,
        locator,
      });
    }

    return Object.freeze({
      schemaVersion: SCHEMA_VERSION,
      sourceId: SOURCE_ID,
      listingId: "_adapter",
      locator,
      observedAt,
      outcome: "observed",
      freshness: Object.freeze({ state: "current", observedAt, sourceTimestamp: null }),
      provenance: Object.freeze({
        kind,
        capturedAt: observedAt,
        httpStatus,
        productionSettlement: false,
      }),
      eligibility: Object.freeze({
        agentAccess: "UNKNOWN",
        humanGates: Object.freeze([]),
        plane: "unknown",
        evidenceRef: null,
      }),
      reward: classifyRewardPlanes({}),
      claim: Object.freeze({
        method: null,
        conditions: Object.freeze([]),
        exclusive: null,
        slots: null,
        plane: "unknown",
      }),
      acceptance: Object.freeze({
        criteria: Object.freeze([]),
        adjudicator: null,
        deterministic: null,
        plane: "unknown",
      }),
      status: Object.freeze({ listing: null, sourceIssue: null }),
      contributorSignals: Object.freeze({
        submissions: null,
        comments: null,
        claims: null,
        lastUpdate: null,
        plane: "unknown",
      }),
      ingest: Object.freeze({ method: "json_get", pagination }),
      reason: null,
      listings: Object.freeze(listings),
      forbiddenAttempted: Object.freeze([]),
    });
  }

  async function ingest(page) {
    const observedAt = resolveNow(now);
    const { take, skip } = normalizePage(page);
    const url = listingsUrl({ take, skip });
    const pagination = { take, count: 0, hasMore: false };
    if (typeof fetchImpl !== "function") {
      return failEnvelope({
        provenanceKind: kind,
        now: observedAt,
        reason: "error",
        pagination,
        locator: url,
      });
    }

    const publicGet = createPublicGet({ fetchImpl });
    let response;
    try {
      response = await publicGet(url);
    } catch {
      return failEnvelope({
        provenanceKind: kind,
        now: observedAt,
        reason: "error",
        httpStatus: 0,
        pagination,
        locator: url,
      });
    }

    const httpStatus = response.status;
    if (httpStatus === 404) {
      return failEnvelope({
        provenanceKind: kind,
        now: observedAt,
        reason: "tombstone",
        httpStatus,
        pagination,
        locator: url,
      });
    }
    if (response.error || httpStatus === 0 || !response.ok) {
      return failEnvelope({
        provenanceKind: kind,
        now: observedAt,
        reason: "error",
        httpStatus,
        pagination,
        locator: url,
      });
    }

    const body = response.json;
    const count = Array.isArray(body) ? body.length : 0;
    return observeListings(body, {
      httpStatus,
      locator: url,
      take,
      pagination: { take, count, hasMore: Array.isArray(body) && count === take },
    });
  }

  return Object.freeze({
    provider: SOURCE_ID,
    capabilities: Object.freeze({ read: true, forbidden: FORBIDDEN_ACTIONS }),
    ingest,
    observeListings,
  });
}
