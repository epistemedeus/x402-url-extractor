/**
 * Five-source public GET ingest. Adapter code only.
 * Does not score, claim, or invent F03/C06 field names.
 */
import { readFile } from "node:fs/promises";
import { basename, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createPublicGet } from "../http.mjs";
import { evaluateFreshness, turnPage } from "../freshness.mjs";
import { assertMode, recordKindForMode } from "./modes.mjs";
import { listingIdentity } from "./identity.mjs";
import {
  listCaptures,
  readCapturePages,
  writeCapture,
  writeManifest,
} from "./capture.mjs";
import { UNION_SOURCES, createUnionAdapter, listingsFromPage } from "./adapters.mjs";
import { assertQueryClock } from "../../../../src/five-source/clock.mjs";
import {
  adapterPageState,
  acquisitionKindFromCapture,
  freshnessPolicy,
  parseMaxPages,
} from "../../../../src/five-source/policy.mjs";

const H02_ROOT = join(dirname(fileURLToPath(import.meta.url)), "..", "..");
const DISCOVERY_PACK_ROOT = join(H02_ROOT, "..", "..");
export const H02_FIXTURES = join(H02_ROOT, "fixtures");
export const DEFAULT_CAPTURE_DIR = join(DISCOVERY_PACK_ROOT, "captures", "cached-default");

function paginationOf(page) {
  return page?.ingest?.pagination || {
    hasMore: page?.hasMore ?? null,
    nextCursor: page?.nextCursor ?? null,
    page: page?.ingest?.pagination?.page ?? null,
    lastPage: page?.ingest?.pagination?.lastPage ?? null,
  };
}

function annotateListing(listing, { queriedAt, recordKind, maxAgeMs, acquisitionKind, captureRef }) {
  const identity = listingIdentity(listing);
  const queryFreshness = evaluateFreshness({
    observedAt: listing?.observedAt,
    sourceTimestamp: listing?.freshness?.sourceTimestamp,
    now: queriedAt,
    maxAgeMs,
  });
  return Object.freeze({
    ...listing,
    identity,
    recordKind,
    acquisitionKind,
    captureRef: captureRef
      ? Object.freeze({ ...captureRef, identity })
      : Object.freeze({ identity, listingId: listing.listingId, observedAt: listing.observedAt }),
    queryFreshness,
    fieldKinds: Object.freeze({
      advertisedAmount: "source_statement",
      reservedState: "source_statement",
      settledState: "source_statement",
      agentAccess: "source_statement",
      listingStatus: "source_statement",
      queryFreshness: "derived_at_query",
    }),
  });
}

function rateLimited(page) {
  const status = page?.provenance?.httpStatus;
  return status === 429 || page?.reason === "rate_limit";
}

async function loadCachedPages(spec, captureDir, { now }) {
  const captures = await readCapturePages(captureDir, spec.adapter);
  if (!captures.length) {
    const error = new Error(`cached capture missing for ${spec.adapter}`);
    error.code = "cached_missing";
    throw error;
  }
  const pages = [];
  for (const capture of captures) {
    const acquisitionKind = acquisitionKindFromCapture(capture);
    const adapter = createUnionAdapter(spec.adapter, {
      now: () => capture.observedAt || now,
      provenanceKind: acquisitionKind,
      fetchImpl: async () => {
        const error = new Error("cached_mode_must_not_fetch");
        error.code = "mode_mix_rejected";
        throw error;
      },
    });
    const observe = adapter[spec.observer];
    if (typeof observe !== "function") {
      pages.push({
        outcome: "error",
        reason: `no_${spec.observer}`,
        listings: [],
        _capture: capture,
        _acquisitionKind: acquisitionKind,
      });
      continue;
    }
    const page = observe(capture.body, {
      observedAt: capture.observedAt,
      httpStatus: capture.httpStatus ?? null,
      provenanceKind: acquisitionKind,
    });
    pages.push({
      ...(page && typeof page === "object" ? page : { outcome: "error", listings: [] }),
      _capture: capture,
      _acquisitionKind: acquisitionKind,
    });
  }
  return pages;
}

function errorPage(reason, httpStatus = 0) {
  return { outcome: "error", reason, listings: [], provenance: { httpStatus } };
}

async function ingestLivePages(spec, { now, maxPages, publicGet, captureDir, provenanceKind }) {
  const adapter = createUnionAdapter(spec.adapter, {
    now: () => now,
    provenanceKind,
    fetchImpl: async () => {
      throw new Error("live_union_uses_publicGet");
    },
  });
  const observe = adapter[spec.observer];
  const pages = [];
  const pageRecords = [];
  let cursor = null;
  let pageNum = 1;
  const limit = spec.supported ? maxPages : 1;
  const seenUrls = new Set();
  const seenCursors = new Set();
  for (let i = 0; i < limit; i += 1) {
    const pageState = adapterPageState({ cursor, pageNum });
    const url = spec.listUrl({ page: pageState, cursor: pageState.cursor });
    if (seenUrls.has(url)) {
      pages.push(errorPage("repeated_page_url"));
      break;
    }
    seenUrls.add(url);
    let response;
    try {
      response = await publicGet(url);
    } catch (error) {
      const page = errorPage(error.code || error.message);
      pages.push(page);
      break;
    }
    const httpStatus = response.status;
    const rawBody = spec.bodyAsText || typeof response.json !== "object" ? response.text : response.json;
    const written = await writeCapture(captureDir, {
      adapter: spec.adapter,
      sourceId: spec.sourceId,
      mode: "live",
      observedAt: now,
      provenanceKind,
      httpStatus,
      observer: spec.observer,
      url: response.url || url,
      pageIndex: pageNum,
      challenge: response.challenge || null,
      body: spec.bodyAsText ? response.text : response.json,
    });
    const capture = {
      adapter: spec.adapter,
      sourceId: spec.sourceId,
      mode: "live",
      observedAt: now,
      provenanceKind,
      httpStatus,
      observer: spec.observer,
      url: response.url || url,
      pageIndex: pageNum,
      challenge: response.challenge || null,
      _file: basename(written),
    };
    pageRecords.push({
      adapter: spec.adapter,
      pageIndex: pageNum,
      url: response.url || url,
      file: capture._file,
    });
    const attach = (page) => ({
      ...(page && typeof page === "object" ? page : errorPage("error", httpStatus)),
      _capture: capture,
      _acquisitionKind: provenanceKind,
    });
    if (httpStatus === 429) {
      pages.push(attach(errorPage("rate_limit", 429)));
      break;
    }
    if (response.challenge === "cloudflare") {
      pages.push(attach(observe(response.text, { observedAt: now, httpStatus, provenanceKind })));
      break;
    }
    if (!response.ok) {
      const reason = httpStatus === 404 ? "tombstone" : "error";
      const page = observe(rawBody, { observedAt: now, httpStatus, provenanceKind });
      pages.push(
        attach({
          ...(page && typeof page === "object" ? page : errorPage(reason, httpStatus)),
          outcome: reason,
          reason: page?.reason || reason,
          provenance: { ...(page?.provenance || {}), httpStatus },
        }),
      );
      break;
    }
    const page = observe(spec.bodyAsText ? response.text : response.json, {
      observedAt: now,
      httpStatus,
      provenanceKind,
    });
    pages.push(attach(page));
    if (rateLimited(page) || page?.outcome === "tombstone" || page?.outcome === "error" || page?.outcome === "empty") {
      break;
    }
    const next = turnPage(paginationOf(page));
    if (next.done) break;
    const nextCursor = next.next?.nextCursor;
    if (nextCursor != null && nextCursor !== "") {
      if (seenCursors.has(String(nextCursor))) {
        pages.push(errorPage("repeated_page_cursor"));
        break;
      }
      seenCursors.add(String(nextCursor));
      cursor = nextCursor;
    }
    pageNum = next.next?.page ?? pageNum + 1;
  }
  return { pages, pageRecords };
}

async function seedCachedFromFixtures(captureDir) {
  const seeds = [
    { adapter: "superteam", file: "superteam/listings-open.json", observer: "observeListings" },
    { adapter: "taskmarket", file: "taskmarket/tasks-open-escrow.json", observer: "observeListings" },
    { adapter: "gibwork", file: "gibwork/explore-open.json", observer: "observeListings" },
    { adapter: "gofrantic", file: "gofrantic/board-open.json", observer: "observeBoard" },
    { adapter: "agentbounties", file: "agentbounties/feed-empty.json", observer: "observeListings" },
    { adapter: "bountyhub-unsupported", file: "bountyhub/cloudflare-403.html", observer: "observeListings", asText: true },
  ];
  for (const seed of seeds) {
    const text = await readFile(join(H02_FIXTURES, seed.file), "utf8");
    const body = seed.asText ? text : JSON.parse(text);
    await writeCapture(captureDir, {
      adapter: seed.adapter,
      mode: "cached",
      observedAt: "2026-09-11T22:40:00.000Z",
      provenanceKind: "fixture",
      httpStatus: seed.asText ? 403 : 200,
      observer: seed.observer,
      pageIndex: 1,
      body,
      seedFile: seed.file,
    });
  }
}

/**
 * Keep same native id when observedAt differs (C05 observation identity).
 * Collapse only exact source+id+observedAt repeats.
 */
export function keepDistinctObservations(listings) {
  const kept = [];
  const duplicates = [];
  const seen = new Map();
  for (const listing of listings) {
    const id = listingIdentity(listing);
    const observedAt = listing?.observedAt || "";
    if (!id) {
      duplicates.push({ identity: null, reason: "missing_native_id", listing });
      continue;
    }
    const key = `${id}\u001f${observedAt}`;
    if (seen.has(key)) {
      duplicates.push({
        identity: id,
        reason: "duplicate_source_native_id_same_observation",
        keptFrom: seen.get(key).sourceId,
        listing,
      });
      continue;
    }
    seen.set(key, listing);
    kept.push(listing);
  }
  return { listings: kept, duplicates };
}

export async function ingestFiveSource({
  mode,
  now,
  maxPages = 1,
  maxAgeMs,
  captureDir,
  fetchImpl,
  allowFixtureSeed = false,
} = {}) {
  assertMode(mode);
  const queriedAt = assertQueryClock(now, { allowDefault: false });
  if (mode === "cached" && fetchImpl) {
    const error = new TypeError("cached mode cannot take fetchImpl");
    error.code = "mode_mix_rejected";
    throw error;
  }
  const pagesLimit = parseMaxPages(maxPages, 1);
  const policy = freshnessPolicy({ maxAgeMs });
  const recordKind = recordKindForMode(mode);
  const dir =
    captureDir ||
    (mode === "cached"
      ? DEFAULT_CAPTURE_DIR
      : join(DISCOVERY_PACK_ROOT, "captures", `live-${String(queriedAt).replace(/[:.]/g, "-")}`));
  const provenanceKind = mode === "live" ? "live_public" : "fixture";
  const publicGet = mode === "live" ? createPublicGet({ fetchImpl: fetchImpl || fetch }) : null;

  if (mode === "cached") {
    const existing = await listCaptures(dir);
    if (existing.length === 0) {
      if (allowFixtureSeed !== true) {
        const error = new Error("cached captures missing");
        error.code = "cached_missing";
        throw error;
      }
      await seedCachedFromFixtures(dir);
    }
  }

  const sourceReports = [];
  const collected = [];
  const tombstones = [];
  const acquisitionPages = [];

  for (const spec of UNION_SOURCES) {
    let pages = [];
    if (mode === "cached") {
      try {
        pages = await loadCachedPages(spec, dir, { now: queriedAt });
      } catch (error) {
        pages = [{ outcome: "error", reason: error.code || error.message, listings: [] }];
      }
    } else {
      const live = await ingestLivePages(spec, {
        now: queriedAt,
        maxPages: pagesLimit,
        publicGet,
        captureDir: dir,
        provenanceKind,
      });
      pages = live.pages;
      acquisitionPages.push(...live.pageRecords);
    }

    const listings = [];
    let outcome = pages[0]?.outcome || "unknown";
    let reason = pages[0]?.reason || null;
    let httpStatus = pages[0]?.provenance?.httpStatus ?? null;
    for (const page of pages) {
      if (page?.outcome === "tombstone") tombstones.push({ sourceId: spec.sourceId, page });
      if (rateLimited(page)) {
        outcome = "error";
        reason = "rate_limit";
      }
      listings.push(...listingsFromPage(page));
      if (page?.outcome === "observed") outcome = "observed";
      if (page?.outcome === "empty" && outcome !== "observed") {
        outcome = "empty";
        reason = page.reason || "empty";
      }
      if (page?.reason === "malformed") {
        outcome = page.outcome || "unknown";
        reason = "malformed";
      }
      if (page?.reason === "repeated_page_cursor" || page?.reason === "repeated_page_url") {
        reason = page.reason;
      }
    }
    if (!spec.supported && outcome === "observed") {
      outcome = "error";
      reason = reason || "unsupported_source";
    }
    sourceReports.push({
      adapter: spec.adapter,
      sourceId: spec.sourceId,
      supported: spec.supported,
      outcome,
      reason,
      httpStatus,
      listingCount: listings.length,
      pages: pages.length,
      pagination: paginationOf(pages[pages.length - 1] || {}),
    });
    for (const listing of listings) {
      const pageForListing = pages.find((page) => listingsFromPage(page).includes(listing)) || pages[0];
      let acquisitionKind = pageForListing?._acquisitionKind;
      if (!acquisitionKind) {
        acquisitionKind =
          listing?.provenance?.kind === "live_public"
            ? "live_public"
            : acquisitionKindFromCapture(
                pageForListing?._capture || { provenanceKind: listing?.provenance?.kind, mode },
              );
      }
      collected.push(
        annotateListing(listing, {
          queriedAt,
          recordKind,
          maxAgeMs: policy.maxAgeMs,
          acquisitionKind,
          captureRef: {
            captureDir: dir,
            adapter: spec.adapter,
            sourceId: spec.sourceId,
            listingId: listing.listingId,
            observedAt: listing.observedAt,
            file: pageForListing?._capture?._file || null,
            pageIndex: pageForListing?._capture?.pageIndex ?? null,
          },
        }),
      );
    }
  }

  const { listings, duplicates } = keepDistinctObservations(collected);

  const result = {
    schemaVersion: "c10-five-source-ingest/1.0",
    mode,
    recordKind,
    queriedAt,
    captureDir: dir,
    freshness: policy,
    sources: sourceReports,
    listings,
    duplicates,
    tombstones: tombstones.map((row) => ({ sourceId: row.sourceId, reason: row.page?.reason || "tombstone" })),
  };

  if (mode === "live") {
    await writeManifest(dir, {
      mode,
      queriedAt,
      recordKind,
      acquisitionKind: "live_public",
      listingCount: listings.length,
      sources: sourceReports,
      pages: acquisitionPages,
    });
  }

  return result;
}

export { UNION_SOURCES, H02_ROOT };
