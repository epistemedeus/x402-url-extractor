/**
 * Source-native identity. Never invent a cross-source slug.
 */
export function listingIdentity(listing) {
  const sourceId = listing?.sourceId;
  const listingId = listing?.listingId;
  if (!sourceId || !listingId || listingId === "_adapter") return null;
  return `${sourceId}::${listingId}`;
}

export function firstSeenWins(listings) {
  const kept = [];
  const duplicates = [];
  const seen = new Map();
  for (const listing of listings) {
    const id = listingIdentity(listing);
    if (!id) {
      duplicates.push({ identity: null, reason: "missing_native_id", listing });
      continue;
    }
    if (seen.has(id)) {
      duplicates.push({
        identity: id,
        reason: "duplicate_source_native_id",
        keptFrom: seen.get(id).sourceId,
        listing,
      });
      continue;
    }
    seen.set(id, listing);
    kept.push(listing);
  }
  return { listings: kept, duplicates };
}
