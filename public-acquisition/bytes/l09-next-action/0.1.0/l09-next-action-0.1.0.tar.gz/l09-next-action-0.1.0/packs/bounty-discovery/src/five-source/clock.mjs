/**
 * Invalid now must fail closed before any public GET.
 * Uses C06's ISO-8601 UTC shape, not a fallback wall clock.
 */
const ISO_CLOCK = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?Z$/;

export function isIsoClock(value) {
  return typeof value === "string" && ISO_CLOCK.test(value) && Number.isFinite(Date.parse(value));
}

export function assertQueryClock(now, { allowDefault = false, defaultIso = null } = {}) {
  if (typeof now === "function") {
    return assertQueryClock(now(), { allowDefault, defaultIso });
  }
  if ((now == null || now === "") && allowDefault && defaultIso) {
    return assertQueryClock(defaultIso, { allowDefault: false });
  }
  if (!isIsoClock(now)) {
    const err = new Error("now must be an ISO-8601 UTC timestamp ending with Z");
    err.code = "invalid_now";
    err.hint = "Example: 2026-09-11T23:24:00.000Z. Invalid now is refused before fetch.";
    throw err;
  }
  return now;
}
