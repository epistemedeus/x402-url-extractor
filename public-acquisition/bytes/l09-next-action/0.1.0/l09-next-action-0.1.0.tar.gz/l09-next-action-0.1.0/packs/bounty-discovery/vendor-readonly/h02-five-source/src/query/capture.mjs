import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { assertMode } from "./modes.mjs";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..", "..");
export const DEFAULT_CAPTURE_DIR = join(ROOT, "evidence/live-captures/default");

const PAGED_NAME = /^(.+)\.page-(\d+)\.json$/;

export function capturePath(dir, adapterName) {
  return join(dir, `${adapterName}.json`);
}

export function pagedCaptureName(adapterName, pageIndex) {
  const page = Number.isInteger(pageIndex) && pageIndex > 0 ? pageIndex : 1;
  return `${adapterName}.page-${String(page).padStart(3, "0")}.json`;
}

export function pagedCapturePath(dir, adapterName, pageIndex) {
  return join(dir, pagedCaptureName(adapterName, pageIndex));
}

export async function writeCapture(dir, capture) {
  await mkdir(dir, { recursive: true });
  const pageIndex = Number.isInteger(capture.pageIndex) && capture.pageIndex > 0 ? capture.pageIndex : 1;
  const payload = { ...capture, pageIndex };
  const body = `${JSON.stringify(payload, null, 2)}\n`;
  const paged = pagedCapturePath(dir, capture.adapter, pageIndex);
  await writeFile(paged, body, "utf8");
  if (pageIndex === 1) {
    await writeFile(capturePath(dir, capture.adapter), body, "utf8");
  }
  return paged;
}

export async function readCapture(dir, adapterName) {
  const pages = await readCapturePages(dir, adapterName);
  if (!pages.length) {
    const error = new Error(`cached capture missing for ${adapterName}`);
    error.code = "cached_missing";
    throw error;
  }
  return pages[0];
}

export async function listCaptures(dir) {
  let names;
  try {
    names = await readdir(dir);
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
  return names.filter((name) => name.endsWith(".json") && name !== "manifest.json");
}

export function captureFilesForAdapter(names, adapterName) {
  const paged = names
    .map((name) => {
      const match = name.match(PAGED_NAME);
      if (!match || match[1] !== adapterName) return null;
      return { name, page: Number(match[2]) };
    })
    .filter(Boolean)
    .sort((a, b) => a.page - b.page);
  if (paged.length) return paged.map((row) => row.name);
  const legacy = `${adapterName}.json`;
  return names.includes(legacy) ? [legacy] : [];
}

export async function readCapturePages(dir, adapterName) {
  const names = await listCaptures(dir);
  const files = captureFilesForAdapter(names, adapterName);
  const pages = [];
  for (const name of files) {
    const text = await readFile(join(dir, name), "utf8");
    const capture = JSON.parse(text);
    capture._file = name;
    pages.push(capture);
  }
  return pages;
}

export async function writeManifest(dir, manifest) {
  await mkdir(dir, { recursive: true });
  await writeFile(join(dir, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
}

export async function readManifest(dir) {
  const text = await readFile(join(dir, "manifest.json"), "utf8");
  return JSON.parse(text);
}

export function assertCaptureMode(capture, mode) {
  assertMode(mode);
  if (capture?.mode && capture.mode !== mode) {
    const error = new TypeError(`capture mode ${capture.mode} cannot be used as ${mode}`);
    error.code = "mode_mix_rejected";
    throw error;
  }
}
