/**
 * Compile H02 listings through the terminal C05/C06/C07 APIs.
 * H02 is ingest only. Eligibility/score/next-step come from F03 packets,
 * C06 freshnessReport, and C07 reservationHonesty.
 */
import { writeFileSync } from "node:fs";
import { basename, join } from "node:path";
import { ingestFiveSource } from "../../vendor-readonly/h02-five-source/src/query/ingest.mjs";
import { assertQueryClock } from "./clock.mjs";
import { jobCardFromListing, isClosedStatus, isOpenStatus, isWindowExpired } from "./job-card-from-listing.mjs";
import { C05_QUERY_FIELDS, C05_QUERY_GRAMMAR, freshnessPolicy } from "./policy.mjs";
import { createAtomicQueryOutput, observationArtifactId } from "./query-output.mjs";

function fail(code, message, hint) {
  const err = new Error(message);
  err.code = code;
  err.hint = hint;
  throw err;
}

const OPENISH = new Set(["OPEN", "open", "BIDDING", "bidding", "claimable"]);

function taskClass({ packet, freshnessRow, listing, sourceReport, card }) {
  if (sourceReport?.supported === false) return "unsupported_provider";
  if (sourceReport?.reason === "malformed") return "malformed";
  if (sourceReport?.outcome === "error") return "error";
  if (sourceReport?.outcome === "empty" && !listing) return "empty";
  if (sourceReport?.outcome === "tombstone") return "tombstone";
  // Listing lifecycle before funding. A completed/closed row with an escrow
  // hash is still closed. Unknown source status is not promised_open.
  const life = observedListingState(listing, card);
  if (listing && life === "closed") return "closed";
  if (freshnessRow?.bucket === "expired_open" || packet?.deadline?.expired === true) return "expired_open";
  if (freshnessRow?.bucket === "stale" || packet?.sourceQuality?.reasons?.includes("stale_observation")) {
    return "stale";
  }
  const access = packet?.claimability?.agentAccess || card?.listing?.agentAccess;
  if (access === "HUMAN_ONLY") return "human_only";
  if (listing && life === "unknown") return "unknown";
  if (packet?.funding?.class === "promised" || card?.listing?.fundingClass === "promised") return "promised_open";
  if (packet?.claimability?.thisIsClaimable === true) return "claimable_with_prereqs";
  if (access === "AGENT_ALLOWED" && OPENISH.has(String(card?.listing?.status))) return "observe_open";
  if (access === "unknown" || packet?.claimability?.state === "unknown") return "unknown";
  return "observe_open";
}

function nextStep(taskClassName) {
  if (
    taskClassName === "human_only" ||
    taskClassName === "closed" ||
    taskClassName === "unknown" ||
    taskClassName === "expired_open" ||
    taskClassName === "unsupported_provider" ||
    taskClassName === "tombstone" ||
    taskClassName === "malformed"
  ) {
    return "do_not_start_work";
  }
  if (taskClassName === "claimable_with_prereqs") return "review_acceptance_locally";
  return "observe_only";
}

function usefulChoice(taskClassName) {
  return (
    taskClassName === "claimable_with_prereqs" ||
    taskClassName === "observe_open" ||
    taskClassName === "promised_open"
  );
}

function countBy(rows, key) {
  const out = {};
  for (const row of rows) {
    const k = row[key] || "unknown";
    out[k] = (out[k] || 0) + 1;
  }
  return out;
}

function observedListingState(listing, card) {
  const status = listing?.status?.listing ?? card?.listing?.status;
  const value = status == null ? "" : String(status);
  if (isClosedStatus(value) || value === "CLOSED") return "closed";
  if (isOpenStatus(value) || isWindowExpired(value) || value === "OPEN") return "open";
  return "unknown";
}

function rankingReasons({ packet, envelope, freshnessRow, reservation, klass, step }) {
  const out = [];
  const push = (engine, text) => {
    if (text == null || text === "") return;
    out.push({ engine, text: String(text) });
  };
  for (const reason of packet?.exclusionReasons || []) push("c05", reason);
  for (const reason of packet?.refuseReasons || []) push("c05", reason);
  for (const reason of packet?.sourceQuality?.reasons || []) push("c05", `sourceQuality:${reason}`);
  if (packet?.claimability?.state) push("c05", `claimability:${packet.claimability.state}`);
  if (packet?.claimability?.agentAccess) push("c05", `agentAccess:${packet.claimability.agentAccess}`);
  if (packet?.funding?.class) push("c05", `funding.class:${packet.funding.class}`);
  for (const reason of envelope?.diagnostics?.reasons || []) push("c05", reason);
  if (freshnessRow?.bucket) push("c06", `bucket:${freshnessRow.bucket}`);
  for (const reason of freshnessRow?.reasons || []) push("c06", reason);
  for (const reason of reservation?.reasons || []) push("c07", reason);
  if (reservation?.usableReservedOffer === false) push("c07", "usableReservedOffer:false");
  push("c10", `taskClass:${klass}`);
  push("c10", `nextStep:${step}`);
  const seen = new Set();
  return out.filter((row) => {
    const key = `${row.engine}:${row.text}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function claimConditions(listing, card) {
  const fromListing = Array.isArray(listing?.claim?.conditions) ? listing.claim.conditions.map(String) : [];
  const fromCard = Array.isArray(card?.claim?.requires) ? card.claim.requires.map(String) : [];
  const gates = Array.isArray(listing?.eligibility?.humanGates)
    ? listing.eligibility.humanGates.map((gate) => `human_gate:${gate}`)
    : [];
  const seen = new Set();
  return [...fromListing, ...fromCard, ...gates].filter((item) => {
    if (seen.has(item)) return false;
    seen.add(item);
    return true;
  });
}

function sourceReportFor(listing, ingest) {
  return (
    ingest.sources.find((s) => s.sourceId === listing.sourceId) ||
    ingest.sources.find((s) => s.adapter === listing.sourceId) ||
    ingest.sources.find((s) => s.adapter === listing.adapter) ||
    null
  );
}

function selectChoices(rows, searched, query, engines) {
  const hasQuery = query != null && String(query).trim() !== "";
  if (!hasQuery) return rows.filter((r) => r.usableChoice);
  const byPath = new Map(rows.map((row) => [row.file, row]));
  const byBase = new Map(rows.map((row) => [basename(row.file), row]));
  const byKey = new Map(rows.filter((row) => row.observationKey).map((row) => [row.observationKey, row]));
  const selected = [];
  const seen = new Set();
  for (const hit of searched.hits || []) {
    const key = hit.observation && engines.c05.observationKey ? engines.c05.observationKey(hit.observation) : null;
    const cardPath = hit.pointers?.cardPath || null;
    const row =
      (cardPath && byPath.get(cardPath)) ||
      (cardPath && byBase.get(basename(cardPath))) ||
      (key && byKey.get(key));
    if (!row || seen.has(row.file)) continue;
    seen.add(row.file);
    selected.push(row);
  }
  return selected;
}

export async function compileFiveSourceQuery(engines, options = {}) {
  const queriedAt = assertQueryClock(options.now, { allowDefault: false });
  const mode = options.mode;
  if (mode !== "cached" && mode !== "live") {
    fail("invalid_query_mode", `mode must be cached or live, got ${mode}`);
  }

  const policy = freshnessPolicy({ maxAgeMs: options.maxAgeMs });
  const query = options.query == null ? "" : String(options.query);

  const ingest = await ingestFiveSource({
    mode,
    now: queriedAt,
    maxPages: options.maxPages ?? 1,
    maxAgeMs: policy.maxAgeMs,
    captureDir: options.captureDir,
    fetchImpl: options.fetchImpl,
    allowFixtureSeed: options.allowFixtureSeed === true,
  });

  const output = createAtomicQueryOutput({ queriedAt, queryOutputDir: options.queryOutputDir });
  let cardsDir;
  let queryOutputDir;
  const drafted = [];
  try {
    for (const listing of ingest.listings) {
      const sourceReport = sourceReportFor(listing, ingest);
      const card = jobCardFromListing(listing, {
        queriedAt,
        recordKind: ingest.recordKind,
        acquisitionKind: listing.acquisitionKind,
        sourceReport,
        staleAfterSeconds: policy.staleAfterSeconds,
      });
      const observationKey = engines.c05.observationKey({
        adapter: card.source?.adapter,
        nativeId: card.source?.nativeId,
        observedAt: listing.observedAt,
        bodySha256: card.source?.bodySha256 || null,
      });
      const file = join(output.cardsDir, `${observationArtifactId(observationKey)}.card.json`);
      writeFileSync(file, `${JSON.stringify(card, null, 2)}\n`);
      drafted.push({ listing, card, sourceReport, observationKey });
    }

    const committed = output.commit();
    queryOutputDir = committed.queryOutputDir;
    cardsDir = committed.cardsDir;
  } catch (err) {
    output.abort();
    throw err;
  }

  const compiled = drafted.map((row) => ({
    listing: row.listing,
    card: row.card,
    file: join(cardsDir, `${observationArtifactId(row.observationKey)}.card.json`),
    sourceReport: row.sourceReport,
    observationKey: row.observationKey,
  }));

  const ingested = engines.c05.ingestDirectory(cardsDir, { now: queriedAt });
  let searched;
  try {
    searched = engines.c05.search(ingested, query, { now: queriedAt });
  } catch (err) {
    fail(err.code || "invalid_query", err.message, C05_QUERY_GRAMMAR);
  }
  const freshness = engines.c06.freshnessReport(
    compiled.map((row) => ({ path: row.file, card: row.card })),
    queriedAt,
  );
  const freshnessByPath = new Map(freshness.rows.map((row) => [row.path, row]));
  const docsByPath = new Map(ingested.documents.map((d) => [d.sourcePath, d]));

  const rows = compiled.map((row) => {
    const listing = row.listing;
    const doc = docsByPath.get(row.file);
    const packet = doc?.packet || null;
    const freshnessRow = freshnessByPath.get(row.file) || null;
    const observation = doc?.observation || null;
    const observationKey = observation
      ? engines.c05.observationKey(observation)
      : row.observationKey;
    const reservation = engines.c07.reservationHonesty({
      fundedFlag: row.card.listing.funded === true,
      fundingClass: packet?.funding?.class || row.card.listing.fundingClass,
      a3FundingClass: doc?.envelope?.packet?.funding?.class ?? null,
      assignmentReserved: row.card.assignment?.reserved === true,
      assignmentAssigned: row.card.assignment?.assigned === true,
      escrowTxHash: row.card.listing.escrowTxHash || row.card.reward?.reservedEvidenceRef || null,
    });
    const klass = taskClass({
      packet,
      freshnessRow,
      listing,
      sourceReport: row.sourceReport,
      card: row.card,
    });
    const step = nextStep(klass);
    const observedState = observedListingState(listing, row.card);
    const reasons = rankingReasons({
      packet,
      envelope: doc?.envelope || null,
      freshnessRow,
      reservation,
      klass,
      step,
    });
    return {
      identity: listing.identity,
      sourceId: listing.sourceId,
      listingId: listing.listingId,
      locator: listing.locator,
      sourceUrl: listing.locator || null,
      title: listing.title || row.card.listing.title,
      observedAt: listing.observedAt,
      observedState,
      observation,
      observationKey,
      acquisitionKind: listing.acquisitionKind || row.card.h02?.acquisitionKind || null,
      recordKind: listing.recordKind || ingest.recordKind,
      captureRef: listing.captureRef || row.card.h02?.captureRef || null,
      taskClass: klass,
      nextStep: step,
      claimAuthority: "none",
      paymentAuthority: "none",
      safeToStartWork: false,
      do_not_start_work: packet?.do_not_start_work !== false,
      thisIsClaimable: packet?.claimability?.thisIsClaimable === true,
      agentAccess: packet?.claimability?.agentAccess || row.card.listing.agentAccess,
      fundingClass: packet?.funding?.class || row.card.listing.fundingClass,
      advertised: {
        amount: listing.reward?.advertised?.amount ?? null,
        currency: listing.reward?.advertised?.currency ?? null,
        plane: listing.reward?.advertised?.plane || "unknown",
        kind: "source_statement",
      },
      reserved: {
        state: listing.reward?.reserved?.state || "unknown",
        plane: listing.reward?.reserved?.plane || "unknown",
        kind: "source_statement",
      },
      settled: {
        state: listing.reward?.settled?.state || "unknown",
        plane: listing.reward?.settled?.plane || "unknown",
        kind: "source_statement",
      },
      reservationHonesty: reservation,
      c06: {
        bucket: freshnessRow?.bucket || null,
        stale: freshnessRow?.bucket === "stale",
        deadlineExpired: freshnessRow?.bucket === "expired_open",
      },
      ingestError: ingested.errors.find((e) => e.path && row.file.endsWith(e.path)) || null,
      fieldKinds: listing.fieldKinds,
      usableChoice: usefulChoice(klass),
      publicListingIsNotClaimPermission: true,
      eligibility: {
        agentAccess: packet?.claimability?.agentAccess || listing?.eligibility?.agentAccess || row.card.listing.agentAccess || "unknown",
        humanGates: Array.isArray(listing?.eligibility?.humanGates) ? listing.eligibility.humanGates : [],
        plane: listing?.eligibility?.plane || "source_published",
        kind: "source_statement",
      },
      claimConditions: claimConditions(listing, row.card),
      rankingReasons: reasons,
      explanation: {
        observation,
        observationKey,
        reasons,
      },
      staleAfterSeconds: row.card.freshness?.staleAfterSeconds ?? policy.staleAfterSeconds,
      file: row.file,
    };
  });

  const choices = selectChoices(rows, searched, query, engines);
  const searchedClaimable = searched.claimableHits || [];

  return {
    schema: "neomorphic.c10.five_source_query.v1",
    mode: ingest.mode,
    recordKind: ingest.recordKind,
    queriedAt,
    captureDir: ingest.captureDir,
    queryOutputDir,
    cardsDir,
    claimAuthority: "none",
    paymentAuthority: "none",
    safeToStartWork: false,
    actual_completion: false,
    observerActionBoundary: {
      observer: "five_source_public_get_compile",
      action: "none",
      claimAuthority: "none",
      paymentAuthority: "none",
      safeToStartWork: false,
      publicListingIsNotClaimPermission: true,
      advertisedIsNotReserved: true,
      promisedIsNotReservedObserved: true,
    },
    enginePins: engines.enginePins,
    sources: ingest.sources,
    ingestErrors: ingested.errors,
    duplicates: ingest.duplicates.map((d) => ({ identity: d.identity, reason: d.reason })),
    tombstones: ingest.tombstones,
    c05: {
      ingested: ingested.count,
      searchQuery: searched.query,
      grammar: C05_QUERY_GRAMMAR,
      fields: C05_QUERY_FIELDS,
      hitCount: searched.count,
      claimableHitCount: searchedClaimable.length,
      hits: (searched.hits || []).map((hit) => ({
        observation: hit.observation || null,
        observationKey: hit.observation ? engines.c05.observationKey(hit.observation) : null,
        cardPath: hit.pointers?.cardPath || null,
      })),
    },
    c06: {
      counts: freshness.counts,
    },
    freshness: policy,
    rows,
    choices,
    choiceCount: choices.length,
    taskClassCounts: countBy(rows, "taskClass"),
    nextStepCounts: countBy(rows, "nextStep"),
    note:
      "Choices are compiled F03/C06/C07 views of public listings. A public listing is not permission to claim. Advertised display is not reserved_observed or settled_observed.",
  };
}

export { fail, taskClass, nextStep, usefulChoice, rankingReasons, observedListingState };
