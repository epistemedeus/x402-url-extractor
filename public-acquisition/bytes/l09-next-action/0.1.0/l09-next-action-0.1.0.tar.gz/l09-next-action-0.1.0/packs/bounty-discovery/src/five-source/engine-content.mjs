/**
 * Distributed-kit engine pin: exact shipped file hashes, no Git checkout.
 * Mutated named packages fail. Ordinary downloaded extracts remain usable
 * because packaging writes ENGINE-CONTENT-MANIFEST.json beside vendor/.
 */
import { createHash } from "node:crypto";
import { existsSync, lstatSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join, relative } from "node:path";

export const ENGINE_CONTENT_SCHEMA = "neomorphic.bounty-discovery.engine-content.v1";
export const ENGINE_CONTENT_MANIFEST = "ENGINE-CONTENT-MANIFEST.json";

const PINNED_PACKAGE_NAMES = Object.freeze({
  "vendor/c05/package.json": ["discovery-search-index", "@neomorphic/discovery-search-index"],
  "vendor/c06/package.json": ["source-freshness-consumer", "@neomorphic/source-freshness-consumer"],
  "vendor/c07/package.json": ["workability-gate-composer", "@neomorphic/workability-gate-composer"],
});

export class EngineContentError extends Error {
  constructor(code, message, hint) {
    super(message);
    this.name = "EngineContentError";
    this.code = code;
    this.hint = hint;
  }
}

function walkFiles(directory) {
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const path = join(directory, entry.name);
    if (entry.isSymbolicLink()) {
      throw new EngineContentError("engine_content_symlink", `symlink refused: ${path}`);
    }
    return entry.isDirectory() ? walkFiles(path) : [path];
  });
}

export function sha256Bytes(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

export function collectVendorRelFiles(packRoot) {
  const vendor = join(packRoot, "vendor");
  if (!existsSync(vendor)) return [];
  return walkFiles(vendor)
    .filter((file) => lstatSync(file).isFile())
    .map((file) => relative(packRoot, file).replaceAll("\\", "/"))
    .sort();
}

export function buildEngineContentManifest(packRoot, { packageName = "bounty-discovery", version } = {}) {
  const files = Object.fromEntries(
    collectVendorRelFiles(packRoot).map((rel) => [rel, sha256Bytes(readFileSync(join(packRoot, rel)))]),
  );
  return {
    schema: ENGINE_CONTENT_SCHEMA,
    packageName,
    version: version || null,
    packageNames: {
      "vendor/c05/package.json": "@neomorphic/discovery-search-index",
      "vendor/c06/package.json": "@neomorphic/source-freshness-consumer",
      "vendor/c07/package.json": "workability-gate-composer",
    },
    files,
  };
}

export function writeEngineContentManifest(packRoot, options = {}) {
  const manifest = buildEngineContentManifest(packRoot, options);
  writeFileSync(join(packRoot, ENGINE_CONTENT_MANIFEST), `${JSON.stringify(manifest, null, 2)}\n`);
  return manifest;
}

function readManifest(kitRoot) {
  const path = join(kitRoot, ENGINE_CONTENT_MANIFEST);
  if (!existsSync(path)) {
    throw new EngineContentError(
      "engine_content_manifest_missing",
      "ENGINE-CONTENT-MANIFEST.json is required to validate shipped engines without Git",
      "Repack the extract; do not substitute an arbitrary named package.json.",
    );
  }
  return JSON.parse(readFileSync(path, "utf8"));
}

export function assertShippedEngineContent(kitRoot) {
  const manifest = readManifest(kitRoot);
  if (manifest?.schema !== ENGINE_CONTENT_SCHEMA) {
    throw new EngineContentError("engine_content_manifest_missing", "engine content manifest schema mismatch");
  }
  const expected = manifest.files || {};
  const actualRels = collectVendorRelFiles(kitRoot);
  const expectedRels = Object.keys(expected).sort();
  if (actualRels.length !== expectedRels.length) {
    throw new EngineContentError(
      "engine_content_mismatch",
      "shipped vendor file set does not match the content manifest",
    );
  }
  for (const rel of actualRels) {
    const want = expected[rel];
    if (!want) {
      throw new EngineContentError("engine_content_mismatch", `unlisted vendor file ${rel}`);
    }
    const got = sha256Bytes(readFileSync(join(kitRoot, rel)));
    if (got !== want) {
      throw new EngineContentError("engine_content_mismatch", `mutated shipped input ${rel}`);
    }
  }
  for (const [rel, names] of Object.entries(PINNED_PACKAGE_NAMES)) {
    const pkgPath = join(kitRoot, rel);
    if (!existsSync(pkgPath)) {
      throw new EngineContentError("engine_content_mismatch", `missing ${rel}`);
    }
    let pkg;
    try {
      pkg = JSON.parse(readFileSync(pkgPath, "utf8"));
    } catch {
      throw new EngineContentError("engine_content_mismatch", `unreadable ${rel}`);
    }
    const allowed = manifest.packageNames?.[rel] ? [manifest.packageNames[rel], ...names] : names;
    if (!allowed.includes(pkg?.name)) {
      throw new EngineContentError("engine_pin_mutated", `mutated named package ${rel}: ${pkg?.name}`);
    }
  }
  return manifest;
}

export function packageNameAllowed(name, pin) {
  if (!name || !pin?.pack) return false;
  return name === pin.pack || name === `@neomorphic/${pin.pack}`;
}
