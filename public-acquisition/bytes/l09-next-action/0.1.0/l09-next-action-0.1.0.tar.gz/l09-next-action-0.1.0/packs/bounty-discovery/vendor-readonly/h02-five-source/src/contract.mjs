/**
 * H02 listing envelope. Planes and funding honesty reuse
 * tools/payment-rail/buyer/bounty-contract.schema.json (bqc/1.0).
 * This is not a second workability scoring kernel.
 */

export const SCHEMA_VERSION = "h02-listing/1.0";

export const EVIDENCE_PLANES = Object.freeze([
  "source_published",
  "poster_declared",
  "worker_declared",
  "independently_verified",
  "chain_settled",
  "policy_rule",
  "unknown",
]);

export const FORBIDDEN_ACTIONS = Object.freeze([
  "register",
  "login",
  "oauth",
  "submit",
  "claim",
  "payout",
  "wallet",
  "pay",
  "bid",
  "apply",
  "account_create",
]);

export const PROVENANCE_KINDS = Object.freeze(["test", "fixture", "live_public"]);

export const AGENT_ACCESS = Object.freeze([
  "AGENT_ONLY",
  "AGENT_ALLOWED",
  "HUMAN_ONLY",
  "UNKNOWN",
]);

export const FRESHNESS_STATES = Object.freeze(["current", "stale", "deleted", "unknown"]);

export const INGEST_STATUS = Object.freeze(["supported", "partial", "unsupported", "unknown"]);

export const RESERVED_STATES = Object.freeze(["reserved_observed", "promised", "unknown"]);

export const SETTLED_STATES = Object.freeze(["settled_observed", "unknown"]);

export const ADAPTER_OUTCOMES = Object.freeze(["observed", "empty", "tombstone", "error", "unknown"]);

const FUNDED_PLANES = new Set(["independently_verified", "chain_settled"]);

function fail(code, detail = code) {
  const error = new TypeError(detail);
  error.code = code;
  throw error;
}

function isIsoZ(value) {
  return typeof value === "string" && Number.isFinite(Date.parse(value)) && value.endsWith("Z");
}

function requirePlane(plane, field) {
  if (!EVIDENCE_PLANES.includes(plane)) fail("invalid_plane", `${field} plane ${plane}`);
}

export function fact(value, plane, provenance) {
  requirePlane(plane, "fact");
  return Object.freeze({
    value: value === undefined ? null : value,
    plane,
    provenance: provenance ?? null,
  });
}

export function unknownFact(reason = "not_published") {
  return fact(null, "unknown", reason);
}

/**
 * Advertised display never implies reserved funds or settlement.
 * reserved_observed / settled_observed require a high-integrity plane and a non-blank evidenceRef.
 */
export function classifyRewardPlanes({ advertised, reserved, settled }) {
  const out = {
    advertised: advertised
      ? {
          amount: advertised.amount ?? null,
          currency: advertised.currency ?? null,
          asset: advertised.asset ?? null,
          plane: advertised.plane ?? "unknown",
          evidenceRef: advertised.evidenceRef ?? null,
        }
      : { amount: null, currency: null, asset: null, plane: "unknown", evidenceRef: null },
    reserved: reserved
      ? {
          state: reserved.state ?? "unknown",
          amount: reserved.amount ?? null,
          currency: reserved.currency ?? null,
          asset: reserved.asset ?? null,
          plane: reserved.plane ?? "unknown",
          evidenceRef: reserved.evidenceRef ?? null,
        }
      : { state: "unknown", amount: null, currency: null, asset: null, plane: "unknown", evidenceRef: null },
    settled: settled
      ? {
          state: settled.state ?? "unknown",
          amount: settled.amount ?? null,
          currency: settled.currency ?? null,
          asset: settled.asset ?? null,
          plane: settled.plane ?? "unknown",
          evidenceRef: settled.evidenceRef ?? null,
        }
      : { state: "unknown", amount: null, currency: null, asset: null, plane: "unknown", evidenceRef: null },
  };

  requirePlane(out.advertised.plane, "advertised");
  requirePlane(out.reserved.plane, "reserved");
  requirePlane(out.settled.plane, "settled");

  if (!RESERVED_STATES.includes(out.reserved.state)) fail("invalid_reserved_state");
  if (!SETTLED_STATES.includes(out.settled.state)) fail("invalid_settled_state");

  if (out.reserved.state === "reserved_observed") {
    if (!FUNDED_PLANES.has(out.reserved.plane)) fail("reserved_overclaim");
    if (!String(out.reserved.evidenceRef || "").trim()) fail("reserved_evidence_missing");
  }
  if (out.settled.state === "settled_observed") {
    if (!FUNDED_PLANES.has(out.settled.plane)) fail("settled_overclaim");
    if (!String(out.settled.evidenceRef || "").trim()) fail("settled_evidence_missing");
  }

  if (out.advertised.amount != null && out.reserved.state === "unknown" && out.reserved.amount == null) {
    // advertised-only is legal
  }
  if (out.advertised.amount != null && out.settled.state === "settled_observed" && out.settled.evidenceRef == null) {
    fail("settled_overclaim");
  }

  return Object.freeze({
    advertised: Object.freeze(out.advertised),
    reserved: Object.freeze(out.reserved),
    settled: Object.freeze(out.settled),
  });
}

export function validateListing(listing) {
  if (!listing || typeof listing !== "object") fail("invalid_listing");
  if (listing.schemaVersion !== SCHEMA_VERSION) fail("schema_version");
  if (!listing.sourceId || !listing.listingId) fail("identity_missing");
  if (!isIsoZ(listing.observedAt)) fail("observed_at");
  if (!FRESHNESS_STATES.includes(listing.freshness?.state)) fail("freshness_state");
  if (!isIsoZ(listing.freshness?.observedAt)) fail("freshness_observed_at");
  if (!PROVENANCE_KINDS.includes(listing.provenance?.kind)) fail("provenance_kind");
  if (listing.provenance.kind !== "live_public" && listing.provenance.productionSettlement === true) {
    fail("fixture_production_settlement");
  }
  if (!AGENT_ACCESS.includes(listing.eligibility?.agentAccess)) fail("agent_access");
  if (!ADAPTER_OUTCOMES.includes(listing.outcome)) fail("adapter_outcome");
  classifyRewardPlanes(listing.reward || {});
  if (Array.isArray(listing.forbiddenAttempted) && listing.forbiddenAttempted.length > 0) {
    fail("forbidden_action_attempted");
  }
  return Object.freeze({ valid: true, listingId: listing.listingId, sourceId: listing.sourceId });
}

export function adapterError({ sourceId, reason, observedAt, provenanceKind = "test" }) {
  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    sourceId,
    listingId: "_adapter",
    locator: null,
    observedAt,
    outcome: reason === "empty" ? "empty" : reason === "tombstone" ? "tombstone" : reason === "error" ? "error" : "unknown",
    freshness: { state: "unknown", observedAt, sourceTimestamp: null },
    provenance: { kind: provenanceKind, capturedAt: observedAt, httpStatus: null, productionSettlement: false },
    eligibility: { agentAccess: "UNKNOWN", humanGates: [], plane: "unknown", evidenceRef: null },
    reward: classifyRewardPlanes({}),
    claim: { method: null, conditions: [], exclusive: null, slots: null, plane: "unknown" },
    acceptance: { criteria: [], adjudicator: null, deterministic: null, plane: "unknown" },
    status: { listing: null, sourceIssue: null },
    contributorSignals: { submissions: null, comments: null, claims: null, lastUpdate: null, plane: "unknown" },
    ingest: { method: "json_get", pagination: null },
    reason,
    listings: [],
  });
}
