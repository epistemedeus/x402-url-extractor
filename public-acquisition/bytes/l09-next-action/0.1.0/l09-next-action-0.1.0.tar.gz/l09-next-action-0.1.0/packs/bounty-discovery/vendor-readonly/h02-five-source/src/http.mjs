import { FORBIDDEN_ACTIONS } from "./contract.mjs";
import { MAX_REDIRECTS, MAX_RESPONSE_BYTES } from "../../../src/five-source/policy.mjs";

const DEFAULT_UA = "W5-H02-public-ingest/0.1 (+https://samedaydesk.com; read-only)";

export const PUBLIC_GET_HOSTS = Object.freeze([
  "superteam.fun",
  "api.taskmarket.dev",
  "api.gib.work",
  "gofrantic.com",
  "api.agentbounties.app",
  "api.bountyhub.dev",
]);

function fail(code, detail = code) {
  const error = new TypeError(detail);
  error.code = code;
  throw error;
}

function headerGet(headers, name) {
  if (!headers) return "";
  if (typeof headers.get === "function") return headers.get(name) || headers.get(name.toLowerCase()) || "";
  return headers[name] || headers[name.toLowerCase()] || "";
}

function isBlockedHost(hostname) {
  const host = String(hostname || "")
    .trim()
    .toLowerCase()
    .replace(/^\[|\]$/g, "");
  if (!host) return true;
  if (host === "localhost" || host.endsWith(".localhost") || host === "localhost.localdomain") return true;
  if (host === "0.0.0.0" || host === "::" || host === "::1" || host === "ip6-localhost" || host === "ip6-loopback") {
    return true;
  }
  if (/^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host) || /^169\.254\./.test(host)) return true;
  if (/^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(host)) return true;
  if (host.startsWith("fc") || host.startsWith("fd") || host.startsWith("fe80:")) return true;
  return false;
}

function hostnameAllowed(hostname, allowedHost) {
  const host = String(hostname || "")
    .trim()
    .toLowerCase();
  const allowed = String(allowedHost || "")
    .trim()
    .toLowerCase();
  if (!host || !allowed) return false;
  if (isBlockedHost(host)) return false;
  if (!PUBLIC_GET_HOSTS.includes(host)) return false;
  return host === allowed;
}

function assertSafeUrl(url, { allowedHost = null } = {}) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    fail("invalid_url");
  }
  if (parsed.protocol !== "https:") fail("https_only");
  if (isBlockedHost(parsed.hostname)) fail("private_or_loopback_target");
  const host = parsed.hostname.toLowerCase();
  if (!PUBLIC_GET_HOSTS.includes(host)) fail("host_not_allowed");
  if (allowedHost && !hostnameAllowed(host, allowedHost)) fail("redirect_host_mismatch");
  const hay = `${parsed.pathname} ${parsed.search}`.toLowerCase();
  for (const action of FORBIDDEN_ACTIONS) {
    if (hay.includes(`/${action}`) || hay.includes(`${action}=`)) fail("forbidden_url_action");
  }
  return parsed;
}

async function readBoundedText(response, maxBytes = MAX_RESPONSE_BYTES) {
  if (response?.body && typeof response.body.getReader === "function") {
    const reader = response.body.getReader();
    const chunks = [];
    let size = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = value instanceof Uint8Array ? value : new Uint8Array(value);
      size += chunk.byteLength;
      if (size > maxBytes) {
        try {
          await reader.cancel();
        } catch {
          /* ignore */
        }
        fail("response_too_large");
      }
      chunks.push(chunk);
    }
    return Buffer.concat(chunks.map((c) => Buffer.from(c))).toString("utf8");
  }
  if (typeof response?.text === "function") {
    const text = await response.text();
    if (Buffer.byteLength(text) > maxBytes) fail("response_too_large");
    return text;
  }
  fail("empty_response");
}

/**
 * GET-only public fetch. Inject `fetchImpl` in tests.
 * Never sends cookies, authorization, or bodies.
 * Follows a bounded number of same-allowed-host redirects; rejects private
 * and loopback targets. Does not offer a generic proxy.
 */
export { isBlockedHost as isPrivateOrLoopbackHostname, assertSafeUrl, readBoundedText };

export function createPublicGet({
  fetchImpl = fetch,
  timeoutMs = 15_000,
  userAgent = DEFAULT_UA,
  maxBytes = MAX_RESPONSE_BYTES,
  maxRedirects = MAX_REDIRECTS,
} = {}) {
  return async function publicGet(url, { headers = {} } = {}) {
    const first = assertSafeUrl(url);
    const allowedHost = first.hostname;
    let current = first.href;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      for (let hop = 0; hop <= maxRedirects; hop += 1) {
        const parsed = assertSafeUrl(current, { allowedHost });
        const response = await fetchImpl(parsed.href, {
          method: "GET",
          redirect: "manual",
          signal: controller.signal,
          headers: {
            accept: "application/json,text/plain;q=0.8,*/*;q=0.5",
            "user-agent": userAgent,
            ...headers,
          },
        });
        const status = response.status;
        if (status >= 300 && status < 400) {
          if (hop === maxRedirects) fail("too_many_redirects");
          const location = headerGet(response.headers, "location");
          if (!location) fail("invalid_redirect");
          let next;
          try {
            next = new URL(location, parsed.href);
          } catch {
            fail("invalid_redirect");
          }
          assertSafeUrl(next.href, { allowedHost });
          current = next.href;
          continue;
        }
        const text = await readBoundedText(response, maxBytes);
        let json = null;
        const ctype = headerGet(response.headers, "content-type");
        if (/json/i.test(String(ctype)) || text.startsWith("{") || text.startsWith("[")) {
          try {
            json = JSON.parse(text);
          } catch {
            json = null;
          }
        }
        return Object.freeze({
          ok: response.ok,
          status: response.status,
          url: parsed.href,
          contentType: String(ctype),
          text,
          json,
          challenge: response.status === 403 && /just a moment|cloudflare|cf-challenge/i.test(text) ? "cloudflare" : null,
        });
      }
      fail("too_many_redirects");
    } catch (error) {
      if (error?.code) throw error;
      return Object.freeze({
        ok: false,
        status: 0,
        url: first.href,
        contentType: "",
        text: "",
        json: null,
        challenge: null,
        error: error?.name || "fetch_error",
      });
    } finally {
      clearTimeout(timer);
    }
  };
}
