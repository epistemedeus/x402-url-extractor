export const QUERY_MODES = Object.freeze(["cached", "live"]);

export const RECORD_KINDS = Object.freeze(["observation", "replay"]);

export const FIELD_KINDS = Object.freeze(["source_statement", "derived_at_query"]);

export function assertMode(mode) {
  if (!QUERY_MODES.includes(mode)) {
    const error = new TypeError(`mode must be cached or live, got ${mode}`);
    error.code = "invalid_query_mode";
    throw error;
  }
  return mode;
}

export function recordKindForMode(mode) {
  assertMode(mode);
  return mode === "live" ? "observation" : "replay";
}
