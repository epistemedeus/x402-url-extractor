/**
 * Map an H02 listing onto the actual F03 job-card.v1 consumed by C05/C06.
 * Field names come from C05 vendor-readonly/bounty-intelligence job-card.mjs,
 * not H02's guessed caller JSON.
 *
 * Advertised display never becomes listing.funded or listing.escrowTxHash.
 * Bare escrow hashes stay promised/source_published.
 * Pack claimAuthority is not a card field that grants claim.
 */
import { STALE_AFTER_SECONDS } from "./policy.mjs";

const SCHEMA_CARD = "s277.bounty-intelligence.job-card.v1";

const OPEN_STATUS = new Set(["OPEN", "open", "claimable", "bidding", "BIDDING"]);
const CLOSED_STATUS = new Set([
  "completed",
  "CLOSED",
  "closed",
  "hidden",
  "deleted",
  "cancelled",
  "CANCELLED",
  "CANCELED",
  "COMPLETE",
  "PAID",
  "DELIVERED",
  "paid",
  "delivered",
]);
const WINDOW_EXPIRED = new Set(["expired", "EXPIRED"]);

function statusToken(value) {
  return value == null ? "" : String(value).trim();
}

function tokenMatches(set, value) {
  const raw = statusToken(value);
  if (!raw) return false;
  if (set.has(raw) || set.has(raw.toUpperCase()) || set.has(raw.toLowerCase())) return true;
  for (const item of set) {
    if (String(item).toLowerCase() === raw.toLowerCase()) return true;
  }
  return false;
}

function isClosedStatus(value) {
  return tokenMatches(CLOSED_STATUS, value);
}

function isOpenStatus(value) {
  return tokenMatches(OPEN_STATUS, value);
}

function isWindowExpired(value) {
  return tokenMatches(WINDOW_EXPIRED, value);
}

function isIsoZ(value) {
  return typeof value === "string" && value.endsWith("Z") && Number.isFinite(Date.parse(value));
}

function isoDay(value) {
  if (!isIsoZ(value)) return null;
  return value.slice(0, 10);
}

function f03AgentAccess(access) {
  if (access === "HUMAN_ONLY") return "HUMAN_ONLY";
  if (access === "AGENT_ALLOWED" || access === "AGENT_ONLY") return "AGENT_ALLOWED";
  return "unknown";
}

function listingStatus(listing) {
  const raw = listing?.status?.listing;
  if (raw == null || raw === "") return "unknown";
  return String(raw);
}

function fundingFromPlanes(listing) {
  const reserved = listing?.reward?.reserved || {};
  const advertised = listing?.reward?.advertised || {};
  if (reserved.state === "reserved_observed") {
    return {
      fundingClass: "reserved",
      funded: true,
      escrowTxHash: reserved.evidenceRef && reserved.plane !== "source_published" ? String(reserved.evidenceRef) : null,
      evidenceKind: "reserved_observed",
    };
  }
  if (reserved.state === "promised") {
    return {
      fundingClass: "promised",
      funded: false,
      escrowTxHash: null,
      promisedEvidenceRef: reserved.evidenceRef || null,
      advertisedAmount: advertised.amount ?? null,
    };
  }
  return {
    fundingClass: "unknown",
    funded: false,
    escrowTxHash: null,
    advertisedAmount: advertised.amount ?? null,
  };
}

function deadlineAt(listing) {
  const sourceId = listing?.sourceId;
  // GoFrantic posted_at and Agent Bounties feeds are not close times.
  if (sourceId === "gofrantic" || sourceId === "agentbounties" || sourceId === "bountyhub") {
    return null;
  }
  if (isIsoZ(listing?.deadline)) return listing.deadline;
  const ts = listing?.freshness?.sourceTimestamp;
  if (!isIsoZ(ts)) return null;
  if (sourceId === "superteam-earn" || sourceId === "gibwork") return ts;
  if (sourceId === "taskmarket") {
    const observedMs = Date.parse(listing.observedAt);
    const stampMs = Date.parse(ts);
    if (listing?.status?.listing === "expired") return ts;
    if (Number.isFinite(observedMs) && stampMs >= observedMs) return ts;
    return null;
  }
  return null;
}

function sourceKind(listing, sourceReport) {
  if (sourceReport?.supported === false) return "no_public_get";
  if (listing?.outcome === "tombstone") return "no_public_get";
  return "job_api";
}

export function jobCardFromListing(listing, { queriedAt, recordKind, sourceReport, acquisitionKind, staleAfterSeconds } = {}) {
  const access = f03AgentAccess(listing?.eligibility?.agentAccess);
  const status = listingStatus(listing);
  const fund = fundingFromPlanes(listing);
  // Observation evidence is listing.observedAt. Query `now` is not a substitute observation.
  const capturedAt = isIsoZ(listing.observedAt) ? listing.observedAt : null;
  const humanGates = Array.isArray(listing?.eligibility?.humanGates) ? listing.eligibility.humanGates : [];
  const closed = isClosedStatus(status);
  const windowExpired = isWindowExpired(status);
  const open = isOpenStatus(status) || windowExpired;
  const nativeId = listing.listingId != null ? String(listing.listingId) : null;
  const adapter = listing.sourceId || listing.adapter || "unknown";
  const deadline = deadlineAt(listing);
  const acquired = acquisitionKind || listing.acquisitionKind || (recordKind === "observation" ? "live_public" : "fixture");
  const ttl = Number.isFinite(Number(staleAfterSeconds)) && Number(staleAfterSeconds) > 0
    ? Number(staleAfterSeconds)
    : STALE_AFTER_SECONDS;

  const requires = [
    ...(Array.isArray(listing?.claim?.conditions) ? listing.claim.conditions.map(String) : []),
    ...humanGates.map((g) => `h02.human_gate:${g}`),
  ];

  return {
    schema: SCHEMA_CARD,
    dataLabel: acquired,
    fixtureKind: `c10-h02-${adapter}`,
    observationDate: isoDay(capturedAt) || isoDay(queriedAt),
    capturedAt,
    observedAt: capturedAt,
    queriedAt: queriedAt || null,
    freshness: {
      observedAt: capturedAt,
      staleAfterSeconds: ttl,
    },
    notes:
      "Public GET listing mapped to F03 job-card.v1. Advertised/promised/observed-reserved/settled stay distinct. Pack never POSTs claim.",
    source: {
      name: adapter,
      adapter,
      nativeId,
      url: listing.locator || null,
      publicGetUrl: listing.locator || null,
      publicGetStatus: listing?.provenance?.httpStatus ?? sourceReport?.httpStatus ?? null,
      sourceKind: sourceKind(listing, sourceReport),
      paused: false,
      observedAt: capturedAt,
      authBoundary: "HTTP 200 list is not claim authority. This pack never claims, bids, or pays.",
    },
    listing: {
      id: nativeId,
      title: listing.title || nativeId || "",
      status: closed
        ? "CLOSED"
        : windowExpired
          ? "OPEN"
          : open
            ? status === "open"
              ? "open"
              : "OPEN"
            : status || "unknown",
      funded: fund.funded === true,
      fundingClass: fund.fundingClass,
      agentAccess: access,
      deadlineAt: deadline,
      ...(fund.escrowTxHash ? { escrowTxHash: fund.escrowTxHash } : {}),
    },
    reward: {
      gross: listing?.reward?.advertised?.amount != null ? String(listing.reward.advertised.amount) : null,
      asset: listing?.reward?.advertised?.currency || listing?.reward?.advertised?.asset || null,
      provenance: "sponsor_stated",
      advertisedPlane: listing?.reward?.advertised?.plane || "unknown",
      reservedState: listing?.reward?.reserved?.state || "unknown",
      reservedPlane: listing?.reward?.reserved?.plane || "unknown",
      reservedEvidenceRef: listing?.reward?.reserved?.evidenceRef || null,
      settledState: listing?.reward?.settled?.state || "unknown",
      settledPlane: listing?.reward?.settled?.plane || "unknown",
      promisedEvidenceRef: fund.promisedEvidenceRef || null,
    },
    claim: {
      available: access === "AGENT_ALLOWED" && open && !closed && !windowExpired,
      state: access === "HUMAN_ONLY" ? "not_claimable" : access === "unknown" ? "unknown" : "claimable_with_prereqs",
      agentAccess: access,
      reason: "Public listing eligibility is a source statement. Pack claimAuthority is none.",
      requires,
      identityRequired: humanGates.length > 0,
    },
    assignment: {
      reserved: false,
      assigned: false,
      awardStatus: "unassigned",
    },
    planes: {
      advertised: listing?.reward?.advertised || null,
      reserved: listing?.reward?.reserved || null,
      settled: listing?.reward?.settled || null,
    },
    h02: {
      sourceId: listing.sourceId,
      listingId: listing.listingId,
      identity: listing.identity || null,
      recordKind,
      acquisitionKind: acquired,
      captureRef: listing.captureRef || null,
      queryFreshness: listing.queryFreshness || null,
    },
    walletlessIou: false,
  };
}

export { SCHEMA_CARD, OPEN_STATUS, CLOSED_STATUS, WINDOW_EXPIRED, f03AgentAccess, isClosedStatus, isOpenStatus, isWindowExpired };
