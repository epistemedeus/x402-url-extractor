import { PROVENANCE_KINDS } from "./contract.mjs";

function fail(code, detail = code) {
  const error = new TypeError(detail);
  error.code = code;
  throw error;
}

function toMs(value) {
  if (value == null || value === "") return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (value instanceof Date) {
    const ms = value.getTime();
    return Number.isFinite(ms) ? ms : null;
  }
  if (typeof value === "string") {
    const ms = Date.parse(value);
    return Number.isFinite(ms) ? ms : null;
  }
  return null;
}

function finiteNumber(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function donePage() {
  return Object.freeze({ done: true, next: null });
}

/**
 * Record freshness is observedAt vs now/maxAgeMs.
 * A future sourceTimestamp is a listing deadline, not current inventory.
 */
export function evaluateFreshness({ observedAt, sourceTimestamp, now, maxAgeMs } = {}) {
  const nowMs = toMs(now) ?? Date.now();
  const observedMs = toMs(observedAt);
  const sourceMs = toMs(sourceTimestamp);
  const ageMs = observedMs == null ? null : Math.max(0, nowMs - observedMs);
  const sourceMissing = sourceTimestamp == null || sourceTimestamp === "" || sourceMs == null;

  let state = "unknown";
  if (!sourceMissing && observedMs != null) {
    const maxAge = finiteNumber(maxAgeMs);
    const limit = maxAge != null && maxAge >= 0 ? maxAge : Number.POSITIVE_INFINITY;
    state = ageMs > limit ? "stale" : "current";
  }

  return Object.freeze({
    state,
    ageMs,
    observedAt: observedAt ?? null,
    sourceTimestamp: sourceTimestamp ?? null,
  });
}

export function evaluateWindow({ deadline, now } = {}) {
  const nowMs = toMs(now) ?? Date.now();
  const deadlineMs = toMs(deadline);
  let listingWindow = "unknown";
  if (deadlineMs != null) {
    listingWindow = nowMs < deadlineMs ? "open" : "closed";
  }
  return Object.freeze({ listingWindow });
}

/**
 * Never invents a next page when hasMore===false or page>=lastPage.
 * count===0 is a valid empty page, not an error.
 */
export function turnPage({ page, lastPage, hasMore, nextCursor, take, count } = {}) {
  void count;
  const pageNum = finiteNumber(page);
  const lastNum = finiteNumber(lastPage);
  if (hasMore === false) return donePage();
  if (pageNum != null && lastNum != null && pageNum >= lastNum) return donePage();

  const hasCursor = nextCursor != null && nextCursor !== "";
  const hasLaterPage = pageNum != null && lastNum != null && pageNum < lastNum;
  if (hasMore !== true && !hasLaterPage && !hasCursor) return donePage();

  const next = {};
  if (pageNum != null) {
    const candidate = pageNum + 1;
    if (lastNum == null || candidate <= lastNum) next.page = candidate;
  }
  if (hasCursor) next.nextCursor = nextCursor;
  if (take !== undefined) next.take = take;
  if (next.page == null && next.nextCursor == null) return donePage();
  return Object.freeze({ done: false, next: Object.freeze(next) });
}

export function provenanceStamp({ kind, capturedAt, httpStatus, productionSettlement = false } = {}) {
  if (!PROVENANCE_KINDS.includes(kind)) fail("provenance_kind", `kind ${kind}`);
  const settlement = productionSettlement === true;
  if (kind !== "live_public" && settlement) fail("fixture_production_settlement");
  return Object.freeze({
    kind,
    capturedAt: capturedAt ?? null,
    httpStatus: httpStatus ?? null,
    productionSettlement: kind === "live_public" ? settlement : false,
  });
}
