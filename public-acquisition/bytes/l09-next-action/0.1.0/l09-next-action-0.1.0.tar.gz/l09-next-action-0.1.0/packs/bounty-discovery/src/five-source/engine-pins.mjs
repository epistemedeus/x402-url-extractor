/**
 * Recorded C05–C07 identities. This extract vendors those packs under vendor/.
 * It does not resolve /tmp worktrees or sibling Pilot paths.
 */
export const ENGINE_PINS = Object.freeze({
  "discovery-search-index": {
    repo: "epistemedeus/neomorphic-io",
    sha: "54758a8f1ba1bc53859b3d3a2c5a7022eabd0f83",
    pack: "discovery-search-index",
    owner: "W5-C05",
    family: "c05",
  },
  "rank-explanation-consumer": {
    repo: "epistemedeus/neomorphic-io",
    sha: "54758a8f1ba1bc53859b3d3a2c5a7022eabd0f83",
    pack: "rank-explanation-consumer",
    owner: "W5-C05",
    family: "c05",
    note: "Recorded C05 pin. This extract compiles with discovery-search-index ingest/search.",
  },
  "source-freshness-consumer": {
    repo: "epistemedeus/neomorphic-io",
    sha: "fb5849bd75fef25e98ed4ae4afe294d05608d792",
    pack: "source-freshness-consumer",
    owner: "W5-C06",
    family: "c06",
  },
  "adapter-union-discovery": {
    repo: "epistemedeus/neomorphic-io",
    sha: "fb5849bd75fef25e98ed4ae4afe294d05608d792",
    pack: "adapter-union-discovery",
    owner: "W5-C06",
    family: "c06",
    note: "Recorded C06 pin. Five-source ingest is H02, not this union.",
  },
  "offer-comparison": {
    repo: "epistemedeus/neomorphic-io",
    sha: "0fe8f1f3defba1d06e514fe8dc3e1b49b73079e4",
    pack: "offer-comparison",
    owner: "W5-C07",
    family: "c07",
    note: "Recorded C07 pin. This extract uses workability-gate-composer reservationHonesty.",
  },
  "workability-gate-composer": {
    repo: "epistemedeus/neomorphic-io",
    sha: "0fe8f1f3defba1d06e514fe8dc3e1b49b73079e4",
    pack: "workability-gate-composer",
    owner: "W5-C07",
    family: "c07",
  },
});

export function describePins(resolved) {
  return Object.fromEntries(
    Object.entries(ENGINE_PINS).map(([name, pin]) => [
      name,
      {
        sha: pin.sha,
        owner: pin.owner,
        root: resolved[name] || null,
        note: pin.note || null,
      },
    ]),
  );
}
