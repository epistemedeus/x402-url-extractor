import {
  SCHEMA_VERSION,
  classifyRewardPlanes,
  adapterError,
  FORBIDDEN_ACTIONS,
} from "../contract.mjs";
import { createPublicGet } from "../http.mjs";

export const SOURCE_ID = "bountyhub";
export const LIST_URL = "https://api.bountyhub.dev/api/bounties?page=1&limit=1";

function resolveNow(now) {
  const value = typeof now === "function" ? now() : now;
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string" && value.endsWith("Z") && Number.isFinite(Date.parse(value))) {
    return value;
  }
  return new Date().toISOString();
}

function unsupportedResult({ observedAt, provenanceKind, httpStatus, challenge, reason, outcome }) {
  return Object.freeze({
    ...adapterError({ sourceId: SOURCE_ID, reason: outcome, observedAt, provenanceKind }),
    schemaVersion: SCHEMA_VERSION,
    locator: LIST_URL,
    ingestStatus: "unsupported",
    status: "unsupported",
    challenge,
    reason,
    listings: Object.freeze([]),
    reward: classifyRewardPlanes({}),
    provenance: Object.freeze({
      kind: provenanceKind,
      capturedAt: observedAt,
      httpStatus,
      productionSettlement: false,
    }),
  });
}

export function createAdapter({
  now = () => new Date().toISOString(),
  fetchImpl,
  provenanceKind = "test",
} = {}) {
  const publicGet = createPublicGet({ fetchImpl });

  function observeHtml(text, { httpStatus = 403, challenge = null } = {}) {
    const observedAt = resolveNow(now);
    const body = String(text || "");
    const detected =
      challenge ||
      (httpStatus === 403 && /just a moment|cloudflare|cf-challenge/i.test(body) ? "cloudflare" : null);
    return unsupportedResult({
      observedAt,
      provenanceKind,
      httpStatus,
      challenge: detected,
      reason: detected === "cloudflare" ? "cloudflare_challenge" : "unsupported_source",
      outcome: "error",
    });
  }

  async function ingest() {
    const observedAt = resolveNow(now);
    const response = await publicGet(LIST_URL);
    if (response.status === 404) {
      return unsupportedResult({
        observedAt,
        provenanceKind,
        httpStatus: 404,
        challenge: response.challenge,
        reason: "tombstone",
        outcome: "tombstone",
      });
    }
    return unsupportedResult({
      observedAt,
      provenanceKind,
      httpStatus: response.status,
      challenge: response.challenge,
      reason: response.challenge === "cloudflare" ? "cloudflare_challenge" : "unsupported_source",
      outcome: "error",
    });
  }

  return Object.freeze({
    provider: SOURCE_ID,
    sourceId: SOURCE_ID,
    forbidden: FORBIDDEN_ACTIONS,
    capabilities: Object.freeze({ read: true, forbidden: FORBIDDEN_ACTIONS }),
    ingest,
    observeHtml,
    observeListings: observeHtml,
  });
}

export const createBountyHubUnsupportedAdapter = createAdapter;
