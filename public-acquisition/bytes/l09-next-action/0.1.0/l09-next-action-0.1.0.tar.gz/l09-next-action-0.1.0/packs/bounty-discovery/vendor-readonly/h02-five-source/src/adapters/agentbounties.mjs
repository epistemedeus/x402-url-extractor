/**
 * Read-only Agent Bounties claimable feed adapter.
 * GET /v1/base/autonomous-bounties/feed?network=base-mainnet&claimable_only=true
 * HTTP 200 [] is a supported empty ingest. funded_amount is promised
 * source_published, never reserved_observed. This package does not claim
 * or chain-verify.
 */

import {
  SCHEMA_VERSION,
  classifyRewardPlanes,
  adapterError,
  FORBIDDEN_ACTIONS,
} from "../contract.mjs";
import { createPublicGet } from "../http.mjs";
import { rejectPromotion } from "../reward-planes.mjs";

export const SOURCE_ID = "agentbounties";
export const FEED_URL =
  "https://api.agentbounties.app/v1/base/autonomous-bounties/feed?network=base-mainnet&claimable_only=true";
export const BASE_MAINNET_USDC = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913";

const USDC_DECIMALS = 1e6;

function resolveNow(now) {
  const value = typeof now === "function" ? now() : now;
  if (typeof value === "string" && Number.isFinite(Date.parse(value)) && value.endsWith("Z")) {
    return value;
  }
  if (value instanceof Date && Number.isFinite(value.getTime())) return value.toISOString();
  return new Date().toISOString();
}

function finiteNumber(value) {
  if (value == null || value === "") return null;
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : null;
}

function scaleAtomic(value) {
  const n = finiteNumber(value);
  return n == null ? null : (n / USDC_DECIMALS).toString();
}

function publishedToken(item) {
  const token = item?.terms?.document?.contract_terms?.settlement_token;
  if (typeof token !== "string") return null;
  const trimmed = token.trim();
  return trimmed ? trimmed : null;
}

function currencyOf(token) {
  if (!token) return null;
  return token.toLowerCase() === BASE_MAINNET_USDC ? "USDC" : null;
}

function analysisLocator(contract) {
  return `https://api.agentbounties.app/v1/base/autonomous-bounties/${contract}/analysis?network=base-mainnet`;
}

function eligibilityOf(item) {
  const claimablePath = item?.status === "claimable" && item?.terms_valid === true;
  if (claimablePath) {
    return Object.freeze({
      agentAccess: "AGENT_ONLY",
      humanGates: Object.freeze([]),
      plane: "source_published",
      evidenceRef: "status+terms_valid",
    });
  }
  if (item?.status != null || item?.terms_valid != null) {
    return Object.freeze({
      agentAccess: "UNKNOWN",
      humanGates: Object.freeze([]),
      plane: "source_published",
      evidenceRef: "status+terms_valid",
    });
  }
  return Object.freeze({
    agentAccess: "UNKNOWN",
    humanGates: Object.freeze([]),
    plane: "unknown",
    evidenceRef: null,
  });
}

function rewardOf(item) {
  const token = publishedToken(item);
  const currency = currencyOf(token);
  const advertisedAmount = scaleAtomic(item?.solver_reward);
  const advertised =
    advertisedAmount == null
      ? { amount: null, currency: null, asset: null, plane: "unknown", evidenceRef: null }
      : {
          amount: advertisedAmount,
          currency,
          asset: token,
          plane: "source_published",
          evidenceRef: "solver_reward",
        };

  const fundedPresent = item != null && Object.hasOwn(item, "funded_amount") && item.funded_amount != null && item.funded_amount !== "";
  const reservedAmount = fundedPresent ? scaleAtomic(item.funded_amount) : null;
  const reserved =
    fundedPresent && reservedAmount != null
      ? {
          state: "promised",
          amount: reservedAmount,
          currency,
          asset: token,
          plane: "source_published",
          evidenceRef: "funded_amount",
        }
      : undefined;

  const settled = { state: "unknown", plane: "unknown", evidenceRef: null };
  rejectPromotion(advertised, reserved, settled);
  return classifyRewardPlanes({ advertised, reserved, settled });
}

function mapListing(item, { observedAt, provenanceKind, httpStatus }) {
  if (!item || typeof item !== "object" || Array.isArray(item)) return null;
  const listingId = item.bounty_contract != null ? String(item.bounty_contract).trim() : "";
  if (!listingId) return null;

  const terms = item.terms?.document;
  const contractTerms = terms?.contract_terms;
  const criteria = Array.isArray(terms?.acceptance_criteria)
    ? terms.acceptance_criteria.map(String)
    : [];
  const errors = Array.isArray(item.validation_errors) ? item.validation_errors.map(String) : [];
  const locator = analysisLocator(listingId);
  const funded = finiteNumber(item.funded_amount);
  const target = finiteNumber(item.target_amount);

  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    sourceId: SOURCE_ID,
    listingId,
    locator,
    title: typeof terms?.title === "string" ? terms.title : listingId,
    observedAt,
    outcome: "observed",
    freshness: Object.freeze({ state: "current", observedAt, sourceTimestamp: null }),
    provenance: Object.freeze({
      kind: provenanceKind,
      capturedAt: observedAt,
      httpStatus,
      productionSettlement: false,
    }),
    eligibility: eligibilityOf(item),
    reward: rewardOf(item),
    claim: Object.freeze({
      method: null,
      conditions: Object.freeze(
        [
          item.claim_bond != null ? `claim_bond:${item.claim_bond}` : null,
          item.required_external_spend != null ? `required_external_spend:${item.required_external_spend}` : null,
        ].filter(Boolean),
      ),
      exclusive: null,
      slots: null,
      plane: "source_published",
    }),
    acceptance: Object.freeze({
      criteria: Object.freeze(criteria),
      adjudicator: item.verification_mode ?? null,
      deterministic: item.verification_ready === true,
      plane: "source_published",
    }),
    status: Object.freeze({
      listing: item.status == null ? null : String(item.status),
      sourceIssue: errors.length ? errors.join("; ") : null,
    }),
    contributorSignals: Object.freeze({
      submissions: null,
      comments: null,
      claims: null,
      lastUpdate: null,
      plane: "unknown",
    }),
    ingest: Object.freeze({ method: "json_get", pagination: null }),
    forbiddenAttempted: Object.freeze([]),
    raw: Object.freeze({
      solverRewardAtomic: item.solver_reward ?? null,
      fundedAmountAtomic: item.funded_amount ?? null,
      targetAmountAtomic: item.target_amount ?? null,
      claimBondAtomic: item.claim_bond ?? null,
      requiredExternalSpendAtomic: item.required_external_spend ?? null,
      termsValid: item.terms_valid ?? null,
      verificationReady: item.verification_ready ?? null,
      verificationMode: item.verification_mode ?? null,
      validationErrors: Object.freeze(errors),
      settlementToken: publishedToken(item),
      network: contractTerms?.network ?? null,
      creatorWallet: contractTerms?.creator_wallet ?? item.creator ?? null,
      goal: typeof terms?.goal === "string" ? terms.goal : null,
      fundedBelowTarget: funded != null && target != null && funded < target,
    }),
  });
}

function failEnvelope({ reason, observedAt, provenanceKind, httpStatus = null, locator = FEED_URL }) {
  const base = adapterError({ sourceId: SOURCE_ID, reason, observedAt, provenanceKind });
  return Object.freeze({
    ...base,
    locator,
    ingest: Object.freeze({ method: "json_get", pagination: null }),
    forbiddenAttempted: Object.freeze([]),
    provenance: Object.freeze({
      kind: provenanceKind,
      capturedAt: observedAt,
      httpStatus,
      productionSettlement: false,
    }),
  });
}

function collectionEnvelope({
  observedAt,
  provenanceKind,
  httpStatus,
  listings,
  outcome,
  reason = null,
}) {
  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    sourceId: SOURCE_ID,
    listingId: "_adapter",
    locator: FEED_URL,
    observedAt,
    outcome,
    reason,
    freshness: Object.freeze({
      state: outcome === "observed" ? "current" : "unknown",
      observedAt,
      sourceTimestamp: null,
    }),
    provenance: Object.freeze({
      kind: provenanceKind,
      capturedAt: observedAt,
      httpStatus,
      productionSettlement: false,
    }),
    eligibility: Object.freeze({
      agentAccess: "UNKNOWN",
      humanGates: Object.freeze([]),
      plane: "unknown",
      evidenceRef: null,
    }),
    reward: classifyRewardPlanes({}),
    claim: Object.freeze({ method: null, conditions: Object.freeze([]), exclusive: null, slots: null, plane: "unknown" }),
    acceptance: Object.freeze({
      criteria: Object.freeze([]),
      adjudicator: null,
      deterministic: null,
      plane: "unknown",
    }),
    status: Object.freeze({ listing: null, sourceIssue: null }),
    contributorSignals: Object.freeze({
      submissions: null,
      comments: null,
      claims: null,
      lastUpdate: null,
      plane: "unknown",
    }),
    ingest: Object.freeze({ method: "json_get", pagination: null }),
    listings: Object.freeze(listings),
    forbiddenAttempted: Object.freeze([]),
  });
}

export function createAdapter({ fetchImpl, now, provenanceKind = "fixture" } = {}) {
  const kind =
    provenanceKind === "live_public" || provenanceKind === "test" || provenanceKind === "fixture"
      ? provenanceKind
      : "fixture";

  function observeListings(raw, extra = {}) {
    const observedAt = extra.observedAt ?? resolveNow(now);
    const httpStatus = extra.httpStatus ?? null;
    const provenanceKindUsed = extra.provenanceKind ?? kind;

    if (!Array.isArray(raw)) {
      return failEnvelope({
        reason: "malformed",
        observedAt,
        provenanceKind: provenanceKindUsed,
        httpStatus,
      });
    }

    if (raw.length === 0) {
      return failEnvelope({
        reason: "empty",
        observedAt,
        provenanceKind: provenanceKindUsed,
        httpStatus,
      });
    }

    const listings = raw
      .map((item) => mapListing(item, { observedAt, provenanceKind: provenanceKindUsed, httpStatus }))
      .filter(Boolean);

    if (listings.length === 0) {
      return failEnvelope({
        reason: "malformed",
        observedAt,
        provenanceKind: provenanceKindUsed,
        httpStatus,
      });
    }

    return collectionEnvelope({
      observedAt,
      provenanceKind: provenanceKindUsed,
      httpStatus,
      listings,
      outcome: "observed",
    });
  }

  async function ingest() {
    const observedAt = resolveNow(now);
    if (typeof fetchImpl !== "function") {
      return failEnvelope({ reason: "error", observedAt, provenanceKind: kind });
    }

    const publicGet = createPublicGet({ fetchImpl });
    let response;
    try {
      response = await publicGet(FEED_URL);
    } catch {
      return failEnvelope({ reason: "error", observedAt, provenanceKind: kind, httpStatus: 0 });
    }

    const httpStatus = response?.status ?? 0;
    if (response?.error || httpStatus === 0 || response?.ok === false) {
      return failEnvelope({
        reason: "error",
        observedAt,
        provenanceKind: kind,
        httpStatus,
      });
    }

    return observeListings(response.json, {
      observedAt,
      httpStatus,
      provenanceKind: kind,
    });
  }

  return Object.freeze({
    provider: SOURCE_ID,
    sourceId: SOURCE_ID,
    feedUrl: FEED_URL,
    capabilities: Object.freeze({
      read: true,
      write: false,
      login: false,
      claim: false,
      wallet: false,
      ingestMethod: "json_get",
      forbidden: FORBIDDEN_ACTIONS,
    }),
    observeListings,
    ingest,
  });
}
