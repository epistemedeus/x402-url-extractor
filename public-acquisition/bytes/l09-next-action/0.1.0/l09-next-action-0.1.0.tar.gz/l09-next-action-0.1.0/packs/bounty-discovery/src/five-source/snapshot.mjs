/**
 * Dated public snapshot of a five-source compile.
 * Separate from any live HTTP/MCP service. Not a ranking engine.
 */
import { ENGINE_PINS } from "./engine-pins.mjs";
import { STALE_AFTER_SECONDS } from "./policy.mjs";

export const SNAPSHOT_SCHEMA = "neomorphic.bounty-discovery.snapshot.v1";
export const CONTRACT_VERSION = "1.0.0";
export { STALE_AFTER_SECONDS };
export const CAPTURED_AT = "2026-09-11T23:24:00.000Z";

function sourceName(sourceId) {
  return (
    {
      "superteam-earn": "Superteam Earn",
      taskmarket: "Taskmarket",
      gibwork: "Gibwork",
      gofrantic: "GoFrantic",
      agentbounties: "Agent Bounties",
      bountyhub: "BountyHub",
    }[sourceId] || sourceId
  );
}

function displayTitle(title) {
  const first = String(title || "")
    .split("\n")[0]
    .replace(/\s+/g, " ")
    .trim();
  return first;
}

function projectOpportunity(row, capturedAt) {
  return {
    identity: row.identity,
    observation: row.observation || null,
    observationKey: row.observationKey || null,
    captureRef: row.captureRef || null,
    acquisitionKind: row.acquisitionKind || null,
    sourceId: row.sourceId,
    sourceName: sourceName(row.sourceId),
    listingId: row.listingId,
    sourceUrl: row.sourceUrl || row.locator || null,
    title: displayTitle(row.title),
    observedAt: row.observedAt || null,
    capturedAt,
    observedState: row.observedState || "unknown",
    agentEligibility: {
      agentAccess: row.eligibility?.agentAccess || row.agentAccess || "unknown",
      humanGates: row.eligibility?.humanGates || [],
      kind: "source_statement",
      documentedBy: "h02_source_fields_and_c05_packet",
    },
    rewardAdvertised: {
      amount: row.advertised?.amount ?? null,
      currency: row.advertised?.currency ?? null,
      plane: row.advertised?.plane || "unknown",
      kind: "source_statement",
      advertisedNotReserved: true,
    },
    reservedAsPublished: {
      state: row.reserved?.state || "unknown",
      plane: row.reserved?.plane || "unknown",
      kind: "source_statement",
    },
    claimAcceptance: {
      claimAuthority: "none",
      paymentAuthority: "none",
      nextStep: row.nextStep,
      assignment: "none",
      conditions: row.claimConditions || [],
      publicListingIsNotClaimPermission: true,
    },
    rankingReasons: row.rankingReasons || [],
    taskClass: row.taskClass,
    nextStep: row.nextStep,
    usefulChoice: row.usableChoice === true,
    fundingClass: row.fundingClass || null,
    freshnessBucket: row.c06?.bucket || null,
    reservationHonesty: {
      usableReservedOffer: row.reservationHonesty?.usableReservedOffer === true,
      reasons: row.reservationHonesty?.reasons || [],
    },
    staleAfterSeconds: row.staleAfterSeconds ?? STALE_AFTER_SECONDS,
    viewState: null,
  };
}

function projectSource(source) {
  return {
    adapter: source.adapter,
    sourceId: source.sourceId,
    sourceName: sourceName(source.sourceId),
    supported: source.supported !== false,
    outcome: source.outcome || "unknown",
    reason: source.reason || null,
    httpStatus: source.httpStatus ?? null,
    listingCount: source.listingCount ?? 0,
    pages: source.pages ?? 0,
    pagination: source.pagination || null,
  };
}

export function projectSnapshot(compileResult, options = {}) {
  const allRows = Array.isArray(compileResult.rows) ? compileResult.rows : [];
  const query = String(compileResult.c05?.searchQuery || "").trim();
  const rows = query
    ? (Array.isArray(compileResult.choices) ? compileResult.choices : [])
    : allRows;
  // A caller's evaluation clock cannot make old acquisition fresh.
  const observations = allRows.map(row => Date.parse(row.observedAt));
  const capturedAt = observations.length && observations.every(Number.isFinite)
    ? new Date(Math.min(...observations)).toISOString()
    : null;
  const opportunities = rows.map((row) => projectOpportunity(row, capturedAt));
  const useful = opportunities.filter((row) => row.usefulChoice);
  const taskClassCounts = {};
  for (const row of rows) {
    const key = row.taskClass || "unknown";
    taskClassCounts[key] = (taskClassCounts[key] || 0) + 1;
  }
  const sources = (compileResult.sources || []).map(projectSource);
  const paginationNotes = [];
  for (const source of sources) {
    if (source.pagination?.hasMore === true) {
      paginationNotes.push(`${source.sourceId} hasMore on page 1`);
    }
  }

  return {
    schema: SNAPSHOT_SCHEMA,
    contractVersion: CONTRACT_VERSION,
    kind: "dated_snapshot",
    notRealtime: true,
    capturedAt,
    compiledAt: compileResult.queriedAt,
    query,
    staleAfterSeconds: STALE_AFTER_SECONDS,
    maxPages: options.maxPages ?? 1,
    mode: compileResult.mode || null,
    recordKind: compileResult.recordKind || null,
    claimAuthority: "none",
    paymentAuthority: "none",
    safeToStartWork: false,
    ownerSchedule: "https://neomorphic.io/bounties/",
    ownerScheduleSchema: "neomorphic.bounty-schedule.v1",
    relatedParserKit: "https://neomorphic.io/labs/external-job-intake/",
    observerActionBoundary: compileResult.observerActionBoundary || {
      observer: "five_source_public_get_compile",
      action: "none",
      publicListingIsNotClaimPermission: true,
      advertisedIsNotReserved: true,
    },
    enginePins: {
      c05: ENGINE_PINS["discovery-search-index"].sha,
      c06: ENGINE_PINS["source-freshness-consumer"].sha,
      c07: ENGINE_PINS["workability-gate-composer"].sha,
    },
    sources,
    opportunities,
    usefulIdentities: useful.map((row) => row.identity),
    counts: {
      opportunities: opportunities.length,
      useful: useful.length,
      taskClass: taskClassCounts,
      c05: compileResult.c05 || null,
      c06: compileResult.c06?.counts || null,
    },
    limits: {
      pagination: "page 1 only; Superteam and Taskmarket may have more",
      paginationNotes,
      staleAfterSeconds: STALE_AFTER_SECONDS,
      viewState: "fresh|stale|unknown at viewer clock; never live",
      liveService: false,
      fixtureOnlyLiveMode: false,
    },
    note:
      "Dated compile of public listings. Next action is the source URL. Advertised amounts are source statements. Owner-funded Neomorphic work is /bounties/.",
  };
}
