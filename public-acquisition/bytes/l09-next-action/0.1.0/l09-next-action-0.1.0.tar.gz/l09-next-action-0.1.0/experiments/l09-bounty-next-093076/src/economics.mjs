import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { costPlanes } from "../../bounty-economics-20260912/src/costs.mjs";
import { assertNetNotProfit } from "../../bounty-economics-20260912/src/honesty.mjs";
import { isUnknown } from "../../bounty-economics-20260912/src/quantity.mjs";
import { walletNet } from "../../bounty-economics-20260912/src/wallet.mjs";
import { COST_NOTES, ECONOMICS_MODULES, ECONOMICS_PATH, EFFORT_WORKFLOW_PATH } from "./constants.mjs";
import { fail, REPO } from "./paths.mjs";

function project(q) {
  if (!q || !isUnknown(q) || q.value != null) {
    throw fail("cost_not_unknown", "effort-economics returned a known cost for unknown inputs");
  }
  return { kind: "unknown", value: null, unit: q.unit ?? null };
}

/**
 * Ask the retained economics modules what an unknown input costs.
 * The answer is an unknown quantity. This function does not pass a synthetic
 * card and does not read a profit figure back.
 */
export function unknownCosts() {
  for (const rel of ECONOMICS_MODULES) {
    if (!existsSync(resolve(REPO, ECONOMICS_PATH, rel))) {
      throw fail("cost_not_unknown", `missing effort-economics module ${rel}`);
    }
  }
  let planes;
  let net;
  try {
    planes = costPlanes({
      tokens: {},
      rates: {},
      cash: { kind: "unknown" },
      subscriptionAllocation: { kind: "unknown" },
      quotaShadow: { kind: "unknown" },
      settlementCurrency: "USDC",
    });
    net = walletNet({
      gross: { kind: "unknown" },
      feeRate: { kind: "unknown" },
      flatFee: { kind: "unknown" },
      settlementCurrency: "USDC",
    });
    assertNetNotProfit({
      wallet: { label: net.label, W: net.W },
    });
  } catch (err) {
    if (err.code === "cost_not_unknown") throw err;
    throw fail("cost_not_unknown", "effort-economics refused unknown inputs");
  }
  if (net.label !== "net_wallet_not_profit") {
    throw fail("cost_not_unknown", "effort-economics net label was not net_wallet_not_profit");
  }
  return {
    readOnly: true,
    module: `${ECONOMICS_PATH}/src/costs.mjs`,
    effortWorkflow: {
      path: EFFORT_WORKFLOW_PATH,
      executed: false,
    },
    cash: project(planes.cash),
    listEquivalent: project(planes.listEquivalent),
    economic: project(planes.economic),
    netAfterFees: { ...project(net.W), label: "net_wallet_not_profit" },
    profit: null,
    syntheticProfitClaim: false,
    notes: [...COST_NOTES],
  };
}
