import {
  closeSync,
  constants,
  existsSync,
  lstatSync,
  openSync,
  readFileSync,
  realpathSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { MAX_READ_BYTES, OPERATOR_FIXTURE } from "./constants.mjs";

export const PACK = fileURLToPath(new URL("..", import.meta.url));
export const REPO = resolve(PACK, "../..");
const VF15_FIXTURES = resolve(REPO, "experiments/vf15-actionable-work/fixtures");
const OPERATOR_ABS = resolve(REPO, OPERATOR_FIXTURE);
export const PUBLIC_SNAPSHOT = resolve(REPO, "public/labs/bounty-discovery/snapshot-v1.json");
export const PUBLIC_NEXT_ACTION = resolve(REPO, "public/labs/bounty-discovery/next-action.json");
const OUTSIDE = "path must be a file inside the experiment";
const UNREADABLE = "path is not a permitted readable file";

export function fail(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}

function rejectPath(userPath) {
  if (typeof userPath !== "string" || userPath.trim() === "" || userPath.includes("\0")) {
    throw fail("usage", "missing path");
  }
}

function candidates(cwd, userPath) {
  const list = [resolve(cwd, userPath)];
  const fromRepo = resolve(REPO, userPath);
  const fromPack = resolve(PACK, userPath);
  if (!list.includes(fromRepo)) list.push(fromRepo);
  if (!list.includes(fromPack)) list.push(fromPack);
  return list;
}

function isInside(root, target) {
  if (target === root) return true;
  const rel = relative(root, target);
  if (!rel || isAbsolute(rel)) return false;
  return !rel.split(sep).includes("..");
}

function realFile(abs) {
  if (!existsSync(abs)) return null;
  let real;
  try {
    real = realpathSync(abs);
  } catch {
    return null;
  }
  let st;
  try {
    st = lstatSync(real);
  } catch {
    return null;
  }
  if (st.isSymbolicLink() || !st.isFile()) return null;
  return real;
}

function permittedRead(real) {
  if (real === OPERATOR_ABS || realpathOrSelf(OPERATOR_ABS) === real) return true;
  if (real === realpathOrSelf(PUBLIC_SNAPSHOT)) return true;
  if (isInside(VF15_FIXTURES, real)) return true;
  if (isInside(PACK, real)) return true;
  return false;
}

function realpathOrSelf(abs) {
  try {
    return realpathSync(abs);
  } catch {
    return abs;
  }
}

export function repoRelative(abs) {
  return relative(REPO, abs).split(sep).join("/");
}

export function readPermitted(cwd, userPath) {
  rejectPath(userPath);
  for (const abs of candidates(cwd, userPath)) {
    const real = realFile(abs);
    if (!real || !permittedRead(real)) continue;
    const st = statSync(real);
    if (st.size > MAX_READ_BYTES) throw fail("usage", "file exceeds the read limit");
    return { abs: real, rel: repoRelative(real), text: readFileSync(real, "utf8") };
  }
  throw fail("usage", UNREADABLE);
}

function isStrictlyInside(root, target) {
  const rel = relative(root, target);
  if (!rel || isAbsolute(rel)) return false;
  if (rel.split(sep).includes("..")) return false;
  return target === join(root, rel);
}

function isInsideOrEqual(root, target) {
  return target === root || isStrictlyInside(root, target);
}

export function resolveOutputInside(cwd, userPath) {
  rejectPath(userPath);
  let packReal;
  try {
    packReal = realpathSync(PACK);
  } catch {
    throw fail("usage", OUTSIDE);
  }
  for (const abs of candidates(cwd, userPath)) {
    const resolved = confineOutput(packReal, abs);
    if (resolved) return resolved;
  }
  throw fail("usage", OUTSIDE);
}

function confineOutput(packReal, abs) {
  const name = basename(abs);
  if (!name || name === "." || name === ".." || name.includes("/") || name.includes("\0")) return null;
  const parent = dirname(abs);
  if (!parent || !existsSync(parent)) return null;
  let parentReal;
  try {
    parentReal = realpathSync(parent);
  } catch {
    return null;
  }
  if (!isInsideOrEqual(packReal, parentReal)) return null;
  let parentStat;
  try {
    parentStat = lstatSync(parentReal);
  } catch {
    return null;
  }
  if (parentStat.isSymbolicLink() || !parentStat.isDirectory()) return null;
  const dest = join(parentReal, name);
  if (!isStrictlyInside(packReal, dest)) return null;
  return finishOutput(packReal, dest);
}

function finishOutput(packReal, dest) {
  let st;
  try {
    st = lstatSync(dest);
  } catch (err) {
    if (err.code === "ENOENT") return outputPath(packReal, dest);
    return null;
  }
  if (st.isSymbolicLink()) {
    let real;
    try {
      real = realpathSync(dest);
    } catch {
      return null;
    }
    if (!isStrictlyInside(packReal, real)) return null;
    let realStat;
    try {
      realStat = lstatSync(real);
    } catch {
      return null;
    }
    if (realStat.isSymbolicLink() || !realStat.isFile()) return null;
    return outputPath(packReal, real);
  }
  if (!st.isFile()) return null;
  return outputPath(packReal, dest);
}

function outputPath(packReal, abs) {
  return { abs, rel: relative(packReal, abs).split(sep).join("/") };
}

export function writePublicNextAction(data) {
  const parent = dirname(PUBLIC_NEXT_ACTION);
  let parentReal;
  try {
    parentReal = realpathSync(parent);
  } catch {
    throw fail("usage", OUTSIDE);
  }
  if (parentReal !== parent) throw fail("usage", OUTSIDE);
  const dest = PUBLIC_NEXT_ACTION;
  if (dirname(dest) !== parentReal) throw fail("usage", OUTSIDE);
  let fd;
  try {
    fd = openSync(dest, constants.O_WRONLY | constants.O_CREAT | constants.O_TRUNC | constants.O_NOFOLLOW);
  } catch (err) {
    const refused = new Set(["ELOOP", "EMLINK", "EISDIR", "ENOTDIR", "ENOENT"]);
    if (refused.has(err.code)) throw fail("usage", OUTSIDE);
    throw err;
  }
  try {
    writeFileSync(fd, data);
  } finally {
    closeSync(fd);
  }
  return dest;
}

export function writeConfined(abs, data) {
  let packReal;
  try {
    packReal = realpathSync(PACK);
  } catch {
    throw fail("usage", OUTSIDE);
  }
  if (!isStrictlyInside(packReal, abs)) throw fail("usage", OUTSIDE);
  const parent = dirname(abs);
  let parentReal;
  try {
    parentReal = realpathSync(parent);
  } catch {
    throw fail("usage", OUTSIDE);
  }
  if (parentReal !== parent || !isInsideOrEqual(packReal, parentReal)) throw fail("usage", OUTSIDE);
  let existing = null;
  try {
    existing = lstatSync(abs);
  } catch (err) {
    if (err.code !== "ENOENT") throw fail("usage", OUTSIDE);
  }
  if (existing && (existing.isSymbolicLink() || !existing.isFile())) throw fail("usage", OUTSIDE);
  let fd;
  try {
    fd = openSync(abs, constants.O_WRONLY | constants.O_CREAT | constants.O_TRUNC | constants.O_NOFOLLOW);
  } catch (err) {
    const refused = new Set(["ELOOP", "EMLINK", "EISDIR", "ENOTDIR", "ENOENT"]);
    if (refused.has(err.code)) throw fail("usage", OUTSIDE);
    throw err;
  }
  try {
    writeFileSync(fd, data);
  } finally {
    closeSync(fd);
  }
}
