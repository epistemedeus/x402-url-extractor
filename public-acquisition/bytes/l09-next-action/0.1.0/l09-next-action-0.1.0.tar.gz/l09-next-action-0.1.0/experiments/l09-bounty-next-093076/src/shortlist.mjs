import {
  CONSUMER,
  ECONOMICS_MODULES,
  ECONOMICS_PATH,
  NEO209,
  PREREQUISITES,
  QUESTION,
  SHORTLIST_SCHEMA,
} from "./constants.mjs";
import { fail } from "./paths.mjs";
import { findLeak } from "./scrub.mjs";

export function documentJson(value) {
  return `${JSON.stringify(value, null, 2)}\n`;
}

export function consumerBlock() {
  return {
    id: CONSUMER.id,
    module: CONSUMER.module,
    acceptsLane: CONSUMER.acceptsLane,
    refusesLane: CONSUMER.refusesLane,
    externalIsNotAnOffer: true,
  };
}

export function limitsBlock() {
  return {
    claimAuthority: "none",
    paymentAuthority: "none",
    safeToStartWork: false,
    ledger: false,
    offer: false,
    publicListingIsNotClaimPermission: true,
    operatorSponsoredIsNotExternalDemand: true,
  };
}

export function pinsBlock() {
  return {
    neo209: {
      path: NEO209.path,
      merge: NEO209.merge,
      acceptedHead: NEO209.acceptedHead,
      readOnly: true,
    },
    effortEconomics: {
      path: ECONOMICS_PATH,
      modules: [...ECONOMICS_MODULES],
      readOnly: true,
    },
  };
}

export function refusalDocument(now, refusal) {
  return {
    schema: SHORTLIST_SCHEMA,
    question: QUESTION,
    generatedAt: now,
    freshUntil: null,
    ttlSeconds: null,
    observation: null,
    claimAuthority: "none",
    paymentAuthority: "none",
    syntheticProfitClaim: false,
    consumer: consumerBlock(),
    prerequisites: [...PREREQUISITES],
    costs: null,
    pins: pinsBlock(),
    lanes: { operatorSponsored: [], externalAvailable: [] },
    nextAction: null,
    refusal,
    sources: [],
    sourceFingerprints: {},
    rewardStatements: {},
    operatorFixtureSha256: null,
    limits: limitsBlock(),
    received: { neo209: false, effortEconomics: false },
  };
}

export function compareCandidates(a, b) {
  if (a.preferred !== b.preferred) return a.preferred ? -1 : 1;
  if (a.updatedAt !== b.updatedAt) {
    if (a.updatedAt == null) return 1;
    if (b.updatedAt == null) return -1;
    if (a.updatedAt < b.updatedAt) return 1;
    if (a.updatedAt > b.updatedAt) return -1;
  }
  if (a.nativeId < b.nativeId) return -1;
  if (a.nativeId > b.nativeId) return 1;
  return 0;
}

export function sourceView(source) {
  return {
    adapterId: source.adapterId,
    sourceId: source.sourceId,
    qualified: source.qualified,
    refusal: source.refusal,
    selectedNativeId: source.action?.nativeId ?? null,
    bodySha256: source.bodySha256,
    evidenceClass: source.evidenceClass,
    vf15EvidenceClass: source.vf15EvidenceClass,
    httpStatus: source.httpStatus,
    fixtureId: source.fixtureId,
    nextStep: source.nextStep,
    taskClass: source.taskClass,
    injectedTransport: source.injectedTransport,
    dropped: source.dropped,
  };
}

/**
 * Point-in-time evidence stored on a live shortlist.
 * Cost values stay null. Reward stays unknown. Fixture refreshes omit this block.
 */
export function liveShortlistEvidence({ now, nextAction, costs }) {
  const reward = nextAction?.reward;
  const costValues = [
    costs?.cash?.value,
    costs?.listEquivalent?.value,
    costs?.economic?.value,
    costs?.netAfterFees?.value,
  ];
  const rewardUnknown = Boolean(
    nextAction &&
    reward?.known === false &&
    reward?.profit == null &&
    reward?.statedAmount == null &&
    costs?.profit == null &&
    costValues.every((value) => value == null)
  );
  return {
    source: {
      adapterId: nextAction.adapterId,
      sourceId: nextAction.sourceId,
    },
    observedAt: now,
    status: nextAction.state,
    rewardUnknown,
    costs: {
      cash: null,
      listEquivalent: null,
      economic: null,
      netAfterFees: null,
      profit: null,
    },
  };
}

export function aggregateRefusal(sources) {
  if (sources.every((source) => source.refusal?.code === "source_unavailable")) {
    return { code: "source_unavailable", message: "both permitted sources were unavailable" };
  }
  if (sources.some((source) => source.refusal?.code === "source_unavailable")) {
    return {
      code: "source_unavailable",
      message: "a permitted source was unavailable and no other source qualified",
    };
  }
  const reasons = sources.flatMap((source) => source.dropped.map((drop) => drop.reason));
  if (reasons.length > 0 && reasons.every((reason) => reason === "closed")) {
    return { code: "closed", message: "every discovered record is closed" };
  }
  return { code: "unqualified", message: "no discovered record qualified as a next action" };
}

export function assembleShortlist(input) {
  const doc = {
    schema: SHORTLIST_SCHEMA,
    question: QUESTION,
    generatedAt: input.now,
    freshUntil: input.freshUntil,
    ttlSeconds: input.ttlSeconds,
    observation: input.observation,
    claimAuthority: "none",
    paymentAuthority: "none",
    syntheticProfitClaim: false,
    consumer: consumerBlock(),
    prerequisites: [...PREREQUISITES],
    costs: input.costs,
    pins: pinsBlock(),
    lanes: {
      operatorSponsored: input.operatorItems,
      externalAvailable: input.rows,
    },
    nextAction: input.nextAction,
    refusal: input.refusal,
    sources: input.sources.map(sourceView),
    sourceFingerprints: input.sourceFingerprints,
    rewardStatements: input.rewardStatements,
    operatorFixtureSha256: input.operatorFingerprint,
    limits: limitsBlock(),
    received: { neo209: true, effortEconomics: true },
  };
  if (input.shortlistEvidence) doc.shortlistEvidence = input.shortlistEvidence;
  if (findLeak(doc)) {
    throw fail("payment_leak", "shortlist carries a payment, claimant, or participant field");
  }
  return doc;
}
