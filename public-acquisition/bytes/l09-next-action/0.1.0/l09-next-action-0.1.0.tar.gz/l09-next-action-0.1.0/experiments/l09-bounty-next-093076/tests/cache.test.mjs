import assert from "node:assert/strict";
import { readFileSync, rmSync } from "node:fs";
import { join, relative } from "node:path";
import test from "node:test";
import { BUGZILLA, GITHUB, LATER, NOW, PACK, happyArgs, run, workDir } from "./helpers.mjs";

test("repeat refresh keeps the shortlist and counts the cache hit", () => {
  const dir = workDir();
  const out = relative(PACK, join(dir, "shortlist.json"));
  const cache = relative(PACK, join(dir, "cache.json"));
  try {
    const first = run(happyArgs(out, cache));
    assert.equal(first.status, 0, first.stderr);
    const second = run(happyArgs(out, cache));
    assert.equal(second.status, 0, second.stderr);
    assert.equal(second.stdout, first.stdout);
    const stored = JSON.parse(readFileSync(join(PACK, cache), "utf8"));
    assert.equal(stored.status, "repeat");
    assert.equal(stored.repeats, 1);
    assert.equal(stored.previousSourceFingerprints, null);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("a changed source replaces the cached next action", () => {
  const dir = workDir();
  const out = relative(PACK, join(dir, "shortlist.json"));
  const cache = relative(PACK, join(dir, "cache.json"));
  try {
    const first = run(happyArgs(out, cache));
    assert.equal(first.status, 0, first.stderr);
    const before = JSON.parse(first.stdout).sourceFingerprints["github-public-issues"];
    const second = run([
      "refresh",
      "--mode",
      "fixture",
      "--github",
      LATER,
      "--bugzilla",
      BUGZILLA,
      "--now",
      NOW,
      "--out",
      out,
      "--cache",
      cache,
    ]);
    assert.equal(second.status, 0, second.stderr);
    const doc = JSON.parse(second.stdout);
    assert.equal(doc.nextAction.url, "https://github.com/example/widget/issues/12");
    assert.equal(doc.nextAction.url.includes("/issues/7"), false);
    const stored = JSON.parse(readFileSync(join(PACK, cache), "utf8"));
    assert.equal(stored.status, "source_changed");
    assert.equal(stored.previousSourceFingerprints["github-public-issues"], before);
    assert.notEqual(stored.sourceFingerprints["github-public-issues"], before);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("a stale shortlist is not returned as the current action", () => {
  const dir = workDir();
  const out = relative(PACK, join(dir, "shortlist.json"));
  const cache = relative(PACK, join(dir, "cache.json"));
  try {
    const filled = run([
      "refresh",
      "--mode",
      "fixture",
      "--github",
      GITHUB,
      "--bugzilla",
      BUGZILLA,
      "--now",
      NOW,
      "--ttl",
      "60",
      "--out",
      out,
      "--cache",
      cache,
    ]);
    assert.equal(filled.status, 0, filled.stderr);
    const stale = run(["next", "--artifact", out, "--now", "2026-09-30T12:01:01.000Z"]);
    assert.equal(stale.status, 2, stale.stderr);
    const answer = JSON.parse(stale.stdout);
    assert.equal(answer.refusal.code, "stale_cache");
    assert.equal(answer.nextAction, null);
    assert.equal(answer.fresh, false);
    assert.equal(stale.stdout.includes("github.com"), false);

    const reread = run([
      "refresh",
      "--mode",
      "fixture",
      "--github",
      GITHUB,
      "--bugzilla",
      BUGZILLA,
      "--now",
      "2026-09-30T13:00:00.000Z",
      "--ttl",
      "60",
      "--out",
      out,
      "--cache",
      cache,
    ]);
    assert.equal(reread.status, 0, reread.stderr);
    const doc = JSON.parse(reread.stdout);
    assert.equal(doc.generatedAt, "2026-09-30T13:00:00.000Z");
    assert.equal(doc.nextAction.url, "https://github.com/example/widget/issues/7");
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("a changed reward does not replace the stored reward baseline", () => {
  const dir = workDir();
  const out = relative(PACK, join(dir, "shortlist.json"));
  const refused = relative(PACK, join(dir, "refused.json"));
  const cache = relative(PACK, join(dir, "cache.json"));
  try {
    const first = run(happyArgs(out, cache));
    assert.equal(first.status, 0, first.stderr);
    const before = readFileSync(join(PACK, cache), "utf8");
    const second = run([
      "refresh",
      "--mode",
      "fixture",
      "--github",
      GITHUB,
      "--bugzilla",
      BUGZILLA,
      "--now",
      NOW,
      "--reward",
      "experiments/l09-bounty-next-093076/fixtures/reward/changed.json",
      "--out",
      refused,
      "--cache",
      cache,
    ]);
    assert.equal(second.status, 2, second.stderr);
    assert.equal(JSON.parse(second.stdout).refusal.code, "changed_reward");
    assert.equal(readFileSync(join(PACK, cache), "utf8"), before);
    assert.equal(JSON.parse(before).rewardStatements["example/widget#7"].statedAmount, null);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
