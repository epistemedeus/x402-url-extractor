import assert from "node:assert/strict";
import { existsSync, readFileSync, rmSync } from "node:fs";
import { join, relative } from "node:path";
import test from "node:test";
import { BUGZILLA, GITHUB, NOW, PACK, REPO, happyArgs, run, workDir } from "./helpers.mjs";

test("two-source fixture refresh selects the newer preferred public GET", () => {
  const dir = workDir();
  const out = join(dir, "shortlist.json");
  const cache = join(dir, "cache.json");
  try {
    const ran = run(happyArgs(relative(PACK, out), relative(PACK, cache)));
    assert.equal(ran.status, 0, ran.stderr);
    const doc = JSON.parse(ran.stdout);
    assert.equal(doc.schema, "neomorphic.l09.cold_shortlist.v1");
    assert.equal(doc.nextAction.url, "https://github.com/example/widget/issues/7");
    assert.equal(doc.nextAction.method, "GET");
    assert.equal(doc.nextAction.lane, "externalAvailable");
    assert.equal(doc.nextAction.reward.known, false);
    assert.equal(doc.nextAction.reward.profit, null);
    assert.equal(doc.costs.cash.kind, "unknown");
    assert.equal(doc.costs.cash.value, null);
    assert.equal(doc.costs.economic.value, null);
    assert.equal(doc.costs.netAfterFees.label, "net_wallet_not_profit");
    assert.equal(doc.costs.profit, null);
    assert.equal(doc.syntheticProfitClaim, false);
    assert.equal(doc.received.neo209, true);
    assert.equal(doc.received.effortEconomics, true);
    assert.deepEqual(doc.sources.map((source) => source.adapterId), ["github-public-issues", "bugzilla-mozilla"]);
    assert.equal(doc.lanes.operatorSponsored.length, 1);
    assert.equal(doc.lanes.externalAvailable.length, 2);
    assert.equal(doc.lanes.operatorSponsored[0].availableAsExternalJob, false);
    assert.equal(doc.lanes.operatorSponsored[0].action.url, null);
    assert.equal(doc.lanes.operatorSponsored[0].reward.status, "disclosed_hypothesis");
    assert.equal(doc.lanes.externalAvailable.every((row) => row.sponsoredByOperator === false), true);
    assert.equal(readFileSync(out, "utf8"), ran.stdout);

    const verified = run(["verify", "--artifact", relative(PACK, out), "--now", NOW]);
    assert.equal(verified.status, 0, verified.stderr);
    assert.equal(JSON.parse(verified.stdout).nextAction.url, doc.nextAction.url);
    const next = run(["next", "--artifact", relative(PACK, out), "--now", NOW]);
    assert.equal(next.status, 0, next.stderr);
    assert.equal(JSON.parse(next.stdout).readFrom, "published_artifact_only");
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("committed cold shortlist matches a fresh two-source refresh", () => {
  const dir = workDir();
  const out = join(dir, "shortlist.json");
  const cache = join(dir, "cache.json");
  try {
    const ran = run(happyArgs(relative(PACK, out), relative(PACK, cache)));
    assert.equal(ran.status, 0, ran.stderr);
    const committed = readFileSync(join(PACK, "published/cold-shortlist.json"), "utf8");
    assert.equal(ran.stdout, committed);
    const committedCache = JSON.parse(readFileSync(join(PACK, "published/refresh-cache.json"), "utf8"));
    const freshCache = JSON.parse(readFileSync(cache, "utf8"));
    assert.equal(freshCache.status, "filled");
    assert.equal(freshCache.repeats, 0);
    assert.deepEqual(freshCache, committedCache);
    const vf15 = JSON.parse(readFileSync(join(REPO, "experiments/vf15-actionable-work/published/qualified-next-action.json"), "utf8"));
    const doc = JSON.parse(ran.stdout);
    assert.equal(doc.sourceFingerprints["github-public-issues"], vf15.provenance.bodySha256);
    assert.equal(doc.nextAction.url, vf15.action.url);
    assert.equal(doc.sources[0].fixtureId.endsWith(GITHUB.split("/").slice(-2).join("/")) || doc.sources[0].fixtureId === GITHUB, true);
    assert.equal(doc.sources[1].fixtureId.endsWith("bugzilla/bugs-happy.json"), true);
    assert.equal(BUGZILLA.endsWith("bugs-happy.json"), true);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("output outside the experiment is rejected before a write", () => {
  const outside = join(REPO, "packs/contributor-desk/l09-escape-not-written.json");
  try {
    const ran = run(happyArgs("../../packs/contributor-desk/l09-escape-not-written.json", "published/refresh-cache.json"));
    assert.equal(ran.status, 3, ran.stdout);
    assert.match(ran.stderr, /inside the experiment/);
    assert.equal(existsSync(outside), false);
  } finally {
    rmSync(outside, { force: true });
  }
});

test("a profit claim is refused and not written", () => {
  const dir = workDir();
  const out = join(dir, "shortlist.json");
  try {
    const ran = run([
      "refresh",
      "--mode",
      "fixture",
      "--github",
      GITHUB,
      "--bugzilla",
      BUGZILLA,
      "--now",
      NOW,
      "--reward",
      "experiments/l09-bounty-next-093076/fixtures/reward/synthetic-profit.json",
      "--out",
      relative(PACK, out),
    ]);
    assert.equal(ran.status, 2, ran.stderr);
    const doc = JSON.parse(ran.stdout);
    assert.equal(doc.refusal.code, "synthetic_profit");
    assert.equal(doc.nextAction, null);
    assert.equal(doc.syntheticProfitClaim, false);
    assert.equal(ran.stdout.includes("12.00"), false);
    assert.equal(existsSync(out), false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
