import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { QUESTION, EXIT, FIXTURE_OUTPUTS } from "./constants.mjs";
import { readNext, verifyArtifact } from "./answer.mjs";
import { decide, publicMachineEntry, verifyDecision } from "./decision.mjs";
import { loadDiscovery } from "./discovery.mjs";
import { checkNextGet } from "./next-get.mjs";
import { fail, readPermitted, resolveOutputInside, writeConfined, writePublicNextAction } from "./paths.mjs";
import { persistLiveObservation } from "./persist.mjs";
import { loadCache, refreshPair, replayCase } from "./refresh.mjs";
import { documentJson, refusalDocument } from "./shortlist.mjs";
import { contributorTaskSpec } from "./taskspec.mjs";

const STDOUT_REFUSALS = new Set([
  "synthetic_profit",
  "payment_leak",
  "malformed_reward",
  "unverified_reward_marked_known",
  "unsupported_reward_asset",
  "lane_collision",
  "cost_not_unknown",
  "allowance_booked_as_cash",
  "artifact_unreadable",
  "artifact_inconsistent",
]);

function usage(message) {
  throw fail("usage", message);
}

function parseArgs(argv) {
  const [cmd, ...rest] = argv;
  const opts = {};
  for (let i = 0; i < rest.length; i += 1) {
    const token = rest[i];
    if (!token.startsWith("--")) usage(`unexpected argument ${token}`);
    const key = token.slice(2);
    const value = rest[i + 1];
    if (value == null || value.startsWith("--")) usage(`missing value for --${key}`);
    if (Object.hasOwn(opts, key)) usage(`duplicate flag --${key}`);
    opts[key] = value;
    i += 1;
  }
  return { cmd, opts };
}

function helpText() {
  return [
    "l09 refresh --mode fixture|live --now ISO [--github PATH --bugzilla PATH] [--ttl SEC] [--reward PATH] [--operator PATH|none] [--out PATH] [--cache PATH]",
    "l09 replay --case closed|unavailable|changed-reward --now ISO [--ttl SEC] [--operator PATH|none] [--out PATH] [--cache PATH]",
    "l09 next --artifact PATH [--now ISO]",
    "l09 verify --artifact PATH [--now ISO]",
    "l09 persist-live --now ISO [--ttl SEC] [--fixture PATH] [--out PATH] [--cache PATH] [--next PATH]",
    "l09 check-next --artifact PATH",
    "l09 decide --now ISO --budget PATH --inventory PATH [--snapshot PATH] [--shortlist PATH] [--prior PATH] [--discovery cached|live] [--out PATH]",
    "l09 read-record --artifact PATH",
    "l09 verify-decision --artifact PATH",
    "l09 task-spec",
    "l09 machine-entry --record PATH [--publish yes]",
    `question: ${QUESTION}`,
    "fixture reads stay on the two Neo209 sources or inside this experiment",
    "writes stay inside this experiment",
    "",
  ].join("\n");
}

function requireFlags(opts, allowed) {
  for (const key of Object.keys(opts)) {
    if (!allowed.has(key)) usage(`unknown flag --${key}`);
  }
}

function ttlOf(value) {
  if (value == null) return undefined;
  if (!/^[1-9]\d*$/.test(value)) usage("ttl must be a positive integer");
  return Number(value);
}

function operatorMode(value) {
  if (value == null) return undefined;
  if (value === "none") return "none";
  return value;
}

function readArtifact(cwd, userPath) {
  const read = readPermitted(cwd, userPath);
  try {
    return JSON.parse(read.text);
  } catch {
    throw fail("artifact_unreadable", "artifact was not json");
  }
}

function prepareCache(cwd, userPath) {
  if (!userPath) return { abs: null, prior: null };
  const resolved = resolveOutputInside(cwd, userPath);
  if (!existsSync(resolved.abs)) return { abs: resolved.abs, prior: null };
  return { abs: resolved.abs, prior: loadCache(readFileSync(resolved.abs, "utf8")) };
}

function writeIfInside(cwd, userPath, abs, data) {
  const again = resolveOutputInside(cwd, userPath);
  if (again.abs !== abs) throw fail("usage", "path must be a file inside the experiment");
  writeConfined(again.abs, data);
}

export async function main(argv, io = {}) {
  const stdout = io.stdout || process.stdout;
  const stderr = io.stderr || process.stderr;
  const cwd = io.cwd || process.cwd();
  try {
    if (argv.length === 0 || argv[0] === "--help" || argv[0] === "help") {
      const text = helpText();
      if (argv[0] === "--help" || argv[0] === "help") {
        stdout.write(text);
        return EXIT.OK;
      }
      stderr.write(text);
      return EXIT.USAGE;
    }
    const { cmd, opts } = parseArgs(argv);
    if (cmd === "refresh") return await refreshCommand(opts, { stdout, cwd });
    if (cmd === "replay") return await replayCommand(opts, { stdout, cwd });
    if (cmd === "next") return answerCommand(opts, { stdout, cwd }, readNext);
    if (cmd === "verify") return answerCommand(opts, { stdout, cwd }, verifyArtifact);
    if (cmd === "persist-live") return await persistCommand(opts, { stdout, cwd });
    if (cmd === "check-next") return checkNextCommand(opts, { stdout, cwd });
    if (cmd === "decide") return await decideCommand(opts, { stdout, cwd });
    if (cmd === "read-record") return readRecordCommand(opts, { stdout, cwd });
    if (cmd === "verify-decision") return verifyDecisionCommand(opts, { stdout, cwd });
    if (cmd === "task-spec") return taskSpecCommand(opts, { stdout });
    if (cmd === "machine-entry") return machineEntryCommand(opts, { stdout, cwd });
    usage(`unknown command ${cmd}`);
  } catch (err) {
    if (STDOUT_REFUSALS.has(err.code)) {
      stdout.write(documentJson(refusalDocument(null, { code: err.code, message: err.message })));
      return EXIT.REFUSAL;
    }
    stderr.write(`${err.code || "error"}: ${err.message}\n`);
    if (err.code === "usage") return EXIT.USAGE;
    return 1;
  }
  return EXIT.USAGE;
}

async function refreshCommand(opts, { stdout, cwd }) {
  requireFlags(opts, new Set(["mode", "now", "github", "bugzilla", "ttl", "reward", "operator", "out", "cache"]));
  if (!opts.mode || !opts.now) usage("refresh requires --mode and --now");
  if (opts.mode === "fixture" && (!opts.github || !opts.bugzilla)) {
    usage("fixture mode requires --github and --bugzilla");
  }
  if (opts.mode === "live" && (opts.github || opts.bugzilla)) usage("live mode does not take a fixture path");
  const cache = prepareCache(cwd, opts.cache);
  const out = opts.out ? resolveOutputInside(cwd, opts.out) : null;
  if (opts.mode === "live") {
    if (out && FIXTURE_OUTPUTS.includes(out.rel)) {
      usage("live mode does not overwrite the deterministic fixture shortlist");
    }
    if (opts.cache && FIXTURE_OUTPUTS.includes(resolveOutputInside(cwd, opts.cache).rel)) {
      usage("live mode does not overwrite the deterministic fixture cache");
    }
  }
  const result = await refreshPair({
    cwd,
    mode: opts.mode,
    now: opts.now,
    ttlSeconds: ttlOf(opts.ttl),
    githubPath: opts.github ?? null,
    bugzillaPath: opts.bugzilla ?? null,
    rewardPath: opts.reward ?? null,
    operatorMode: operatorMode(opts.operator),
    priorCache: cache.prior,
    network: opts.mode === "live",
  });
  if (out && result.writeShortlist) writeIfInside(cwd, opts.out, out.abs, result.json);
  if (cache.abs && result.cache) writeIfInside(cwd, opts.cache, cache.abs, documentJson(result.cache));
  stdout.write(result.json);
  return result.exitCode;
}

async function replayCommand(opts, { stdout, cwd }) {
  requireFlags(opts, new Set(["case", "now", "ttl", "operator", "out", "cache"]));
  if (!opts.case || !opts.now) usage("replay requires --case and --now");
  const cache = prepareCache(cwd, opts.cache);
  const out = opts.out ? resolveOutputInside(cwd, opts.out) : null;
  const result = await replayCase(opts.case, {
    cwd,
    now: opts.now,
    ttlSeconds: ttlOf(opts.ttl),
    operatorMode: operatorMode(opts.operator),
    priorCache: cache.prior,
  });
  if (out && result.writeShortlist) writeIfInside(cwd, opts.out, out.abs, result.json);
  if (cache.abs && result.cache) writeIfInside(cwd, opts.cache, cache.abs, documentJson(result.cache));
  stdout.write(result.json);
  return result.exitCode;
}

async function persistCommand(opts, { stdout, cwd }) {
  requireFlags(opts, new Set(["now", "ttl", "fixture", "out", "cache", "next", "operator"]));
  if (!opts.now) usage("persist-live requires --now");
  const result = await persistLiveObservation({
    cwd,
    now: opts.now,
    ttlSeconds: ttlOf(opts.ttl),
    fixturePath: opts.fixture,
    outPath: opts.out,
    cachePath: opts.cache,
    nextPath: opts.next,
    operatorMode: operatorMode(opts.operator),
  });
  stdout.write(result.json);
  return result.exitCode;
}

function refuseNext(stdout, code, message) {
  stdout.write(documentJson(refusalDocument(null, { code, message })));
  return EXIT.REFUSAL;
}

function checkNextCommand(opts, { stdout, cwd }) {
  requireFlags(opts, new Set(["artifact"]));
  if (!opts.artifact) usage("an artifact path is required");
  const record = readArtifact(cwd, opts.artifact);
  if (!record?.fixture?.artifact || !record?.live?.artifact) {
    return refuseNext(stdout, "artifact_unreadable", "next get record has no shortlist paths");
  }
  let fixture;
  let live;
  try {
    fixture = readArtifact(cwd, record.fixture.artifact);
    live = readArtifact(cwd, record.live.artifact);
  } catch (err) {
    if (err.code === "usage" || err.code === "artifact_unreadable") {
      return refuseNext(stdout, "artifact_unreadable", "next get shortlist could not be read");
    }
    throw err;
  }
  try {
    stdout.write(documentJson(checkNextGet(record, { fixture, live })));
    return EXIT.OK;
  } catch (err) {
    if (err.code === "payment_leak" || err.code === "artifact_inconsistent" || err.code === "synthetic_profit" || err.code === "artifact_unreadable") {
      return refuseNext(stdout, err.code, err.message);
    }
    throw err;
  }
}

function shaOf(text) {
  return `sha256:${createHash("sha256").update(text).digest("hex")}`;
}

function readJson(cwd, userPath) {
  const read = readPermitted(cwd, userPath);
  try {
    return { ...read, json: JSON.parse(read.text) };
  } catch {
    throw fail("artifact_unreadable", "artifact was not json");
  }
}

async function decideCommand(opts, { stdout, cwd }) {
  requireFlags(opts, new Set(["now", "budget", "inventory", "snapshot", "shortlist", "prior", "discovery", "out"]));
  if (!opts.now || !opts.budget || !opts.inventory) usage("decide requires --now, --budget, and --inventory");
  const discoveryMode = opts.discovery ?? "cached";
  if (discoveryMode !== "cached" && discoveryMode !== "live") usage("discovery must be cached or live");
  if (discoveryMode === "live" && opts.snapshot) usage("live discovery does not take a snapshot path");
  if (discoveryMode === "cached" && !opts.snapshot) usage("cached discovery requires --snapshot");
  const budget = readJson(cwd, opts.budget);
  const inventory = readJson(cwd, opts.inventory);
  const shortlist = opts.shortlist ? readJson(cwd, opts.shortlist) : null;
  const prior = opts.prior ? readJson(cwd, opts.prior) : null;
  const started = performance.now();
  const loaded = await loadDiscovery({
    mode: discoveryMode,
    now: opts.now,
    snapshot: discoveryMode === "cached" ? readJson(cwd, opts.snapshot).json : null,
  });
  const snapshotSha = discoveryMode === "cached" ? shaOf(readJson(cwd, opts.snapshot).text) : null;
  const result = decide({
    now: opts.now,
    budget: budget.json,
    inventory: inventory.json,
    snapshot: loaded.snapshot,
    shortlist: shortlist?.json ?? null,
    prior: prior?.json ?? null,
    snapshotSha256: snapshotSha,
    shortlistSha256: shortlist ? shaOf(shortlist.text) : null,
    discoveryMode: loaded.mode,
    measurement: { requesterWallClockMs: Math.max(0, Math.round(performance.now() - started)) },
  });
  const json = documentJson(result.record);
  if (opts.out) {
    const out = resolveOutputInside(cwd, opts.out);
    writeIfInside(cwd, opts.out, out.abs, json);
  }
  stdout.write(json);
  return result.exitCode;
}

function readRecordCommand(opts, { stdout, cwd }) {
  requireFlags(opts, new Set(["artifact"]));
  if (!opts.artifact) usage("an artifact path is required");
  const record = readJson(cwd, opts.artifact).json;
  const checked = verifyDecision(record);
  if (checked.exitCode !== 0) {
    stdout.write(documentJson(checked.answer));
    return checked.exitCode;
  }
  stdout.write(documentJson(record));
  return EXIT.OK;
}

function verifyDecisionCommand(opts, { stdout, cwd }) {
  requireFlags(opts, new Set(["artifact"]));
  if (!opts.artifact) usage("an artifact path is required");
  let record;
  try {
    record = readJson(cwd, opts.artifact).json;
  } catch (err) {
    if (err.code === "artifact_unreadable" || err.code === "usage") {
      return refuseNext(stdout, "artifact_unreadable", "decision artifact could not be read");
    }
    throw err;
  }
  const checked = verifyDecision(record);
  stdout.write(documentJson(checked.answer));
  return checked.exitCode;
}

function taskSpecCommand(opts, { stdout }) {
  requireFlags(opts, new Set());
  stdout.write(documentJson(contributorTaskSpec()));
  return EXIT.OK;
}

function machineEntryCommand(opts, { stdout, cwd }) {
  requireFlags(opts, new Set(["record", "publish"]));
  if (!opts.record) usage("machine-entry requires --record");
  if (opts.publish != null && opts.publish !== "yes") usage("publish takes the value yes");
  const record = readJson(cwd, opts.record).json;
  const entry = publicMachineEntry(record);
  const json = documentJson(entry);
  if (opts.publish === "yes") writePublicNextAction(json);
  stdout.write(json);
  return EXIT.OK;
}

function answerCommand(opts, { stdout, cwd }, read) {
  requireFlags(opts, new Set(["artifact", "now"]));
  if (!opts.artifact) usage("an artifact path is required");
  const doc = readArtifact(cwd, opts.artifact);
  const result = read(doc, { now: opts.now });
  stdout.write(documentJson(result.answer));
  return result.exitCode;
}
