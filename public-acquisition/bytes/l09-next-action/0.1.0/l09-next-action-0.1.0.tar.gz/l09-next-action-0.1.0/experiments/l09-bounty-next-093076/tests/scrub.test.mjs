import assert from "node:assert/strict";
import { existsSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join, relative } from "node:path";
import test from "node:test";
import { findLeak } from "../src/scrub.mjs";
import { BUGZILLA, GITHUB, NOW, PACK, REPO, happyArgs, run, workDir } from "./helpers.mjs";

const TX = "0x593559ea7a19277645a76e41aa29e713ed219db1f97e4be29c9dac9cf6cd4b37";
const EMAIL = "hidden-person@example.com";

function published() {
  return JSON.parse(readFileSync(join(PACK, "published/cold-shortlist.json"), "utf8"));
}

test("the published shortlist keeps a public GET and unknown cost, without payment or claimant fields", () => {
  const doc = published();
  assert.equal(findLeak(doc), null);
  assert.equal(doc.consumer.id, "earned-work-requester");
  assert.equal(doc.prerequisites.length >= 4, true);
  assert.equal(doc.costs.cash.kind, "unknown");
  assert.equal(doc.costs.cash.value, null);
  assert.equal(doc.costs.profit, null);
  assert.equal(doc.syntheticProfitClaim, false);
  assert.equal(doc.nextAction.method, "GET");
  assert.equal(doc.nextAction.kind, "read_public_record");
  assert.equal(doc.nextAction.lane, "externalAvailable");
  assert.equal(doc.lanes.operatorSponsored[0].sponsoredByOperator, true);
  assert.equal(doc.lanes.operatorSponsored[0].availableAsExternalJob, false);
  assert.equal(doc.lanes.operatorSponsored[0].customerRevenue, false);
  assert.equal(Object.hasOwn(doc.lanes.operatorSponsored[0], "paid"), false);
  assert.equal(doc.lanes.externalAvailable.every((row) => row.sponsoredByOperator === false), true);
  assert.equal(JSON.stringify(doc).includes(TX), false);
  assert.equal(JSON.stringify(doc).includes(EMAIL), false);
  const verified = run(["verify", "--artifact", "published/cold-shortlist.json", "--now", NOW]);
  assert.equal(verified.status, 0, verified.stderr);
  const next = run(["next", "--artifact", "published/cold-shortlist.json", "--now", NOW]);
  assert.equal(next.status, 0, next.stderr);
  assert.equal(JSON.parse(next.stdout).nextAction.url, doc.nextAction.url);
});

test("verify refuses a shortlist that leaks a payment, claimant, or tx", () => {
  const dir = workDir();
  const artifact = join(dir, "tampered.json");
  try {
    const doc = published();
    doc.lanes.operatorSponsored[0].paid = true;
    doc.lanes.operatorSponsored[0].claimant = EMAIL;
    doc.nextAction.title = `receipt ${TX}`;
    writeFileSync(artifact, JSON.stringify(doc));
    const ran = run(["verify", "--artifact", relative(PACK, artifact), "--now", NOW]);
    assert.equal(ran.status, 2, ran.stderr);
    const answer = JSON.parse(ran.stdout);
    assert.equal(answer.refusal.code, "payment_leak");
    assert.equal(answer.nextAction, null);
    assert.equal(ran.stdout.includes(TX), false);
    assert.equal(ran.stdout.includes(EMAIL), false);
    assert.equal(ran.stdout.includes("hidden-person"), false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("a claimant or paid flag on a reward file is refused and not written", () => {
  const dir = workDir();
  const out = join(dir, "shortlist.json");
  try {
    const ran = run([
      "refresh",
      "--mode",
      "fixture",
      "--github",
      GITHUB,
      "--bugzilla",
      BUGZILLA,
      "--now",
      NOW,
      "--reward",
      "experiments/l09-bounty-next-093076/fixtures/reward/claimant.json",
      "--out",
      relative(PACK, out),
    ]);
    assert.equal(ran.status, 2, ran.stderr);
    assert.equal(JSON.parse(ran.stdout).refusal.code, "payment_leak");
    assert.equal(JSON.parse(ran.stdout).nextAction, null);
    assert.equal(ran.stdout.includes(EMAIL), false);
    assert.equal(ran.stdout.includes("hidden-person"), false);
    assert.equal(existsSync(out), false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("an email or transaction hash in a public title is redacted", () => {
  const dir = workDir();
  const github = join(dir, "github.json");
  const out = join(dir, "shortlist.json");
  try {
    const payload = JSON.parse(readFileSync(join(REPO, GITHUB), "utf8"));
    const item = payload.items.find((row) => row.number === 7 && row.html_url.endsWith("/issues/7") && row.title === "Read the public widget issue");
    item.title = `Write ${EMAIL} about ${TX}`;
    writeFileSync(github, JSON.stringify(payload));
    const ran = run([
      "refresh",
      "--mode",
      "fixture",
      "--github",
      relative(PACK, github),
      "--bugzilla",
      BUGZILLA,
      "--now",
      NOW,
      "--out",
      relative(PACK, out),
    ]);
    assert.equal(ran.status, 0, ran.stderr);
    const doc = JSON.parse(ran.stdout);
    assert.equal(doc.nextAction.title.includes(EMAIL), false);
    assert.equal(doc.nextAction.title.includes(TX), false);
    assert.match(doc.nextAction.title, /\[redacted\]/);
    assert.equal(findLeak(doc), null);
    assert.equal(ran.stdout.includes(EMAIL), false);
    assert.equal(ran.stdout.includes(TX), false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("repeat refresh, source change, and a stale cache keep the scrub", () => {
  const dir = workDir();
  const out = relative(PACK, join(dir, "shortlist.json"));
  const cache = relative(PACK, join(dir, "cache.json"));
  try {
    const first = run(happyArgs(out, cache));
    assert.equal(first.status, 0, first.stderr);
    assert.equal(findLeak(JSON.parse(first.stdout)), null);
    const second = run(happyArgs(out, cache));
    assert.equal(second.status, 0, second.stderr);
    assert.equal(second.stdout, first.stdout);
    assert.equal(JSON.parse(readFileSync(join(PACK, cache), "utf8")).status, "repeat");
    const changed = run([
      "refresh",
      "--mode",
      "fixture",
      "--github",
      "experiments/l09-bounty-next-093076/fixtures/github/search-later.json",
      "--bugzilla",
      BUGZILLA,
      "--now",
      NOW,
      "--out",
      out,
      "--cache",
      cache,
    ]);
    assert.equal(changed.status, 0, changed.stderr);
    const doc = JSON.parse(changed.stdout);
    assert.equal(doc.nextAction.url, "https://github.com/example/widget/issues/12");
    assert.equal(JSON.parse(readFileSync(join(PACK, cache), "utf8")).status, "source_changed");
    assert.equal(findLeak(doc), null);
    const stale = run(["next", "--artifact", out, "--now", "2026-10-02T12:00:00.000Z"]);
    assert.equal(stale.status, 2, stale.stderr);
    assert.equal(JSON.parse(stale.stdout).refusal.code, "stale_cache");
    assert.equal(JSON.parse(stale.stdout).nextAction, null);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
