import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, rmSync, writeFileSync } from "node:fs";
import { join, relative } from "node:path";
import test from "node:test";
import { authorOffer } from "../../codex-window/h36-earned-requester-integration/src/author.mjs";
import { KERNEL_SHA } from "../../codex-window/h36-earned-requester-integration/src/constants.mjs";
import { buildNextGet, checkNextGet } from "../src/next-get.mjs";
import { findLeak } from "../src/scrub.mjs";
import { NOW, PACK, run, workDir } from "./helpers.mjs";

const FIXTURE_URL = "https://github.com/example/widget/issues/7";
const LIVE_URL = "https://github.com/example/widget/issues/9";
const OBSERVED = "2026-10-01T00:14:09.719Z";
const EMAIL = "hidden-person@example.com";
const TX = "0x593559ea7a19277645a76e41aa29e713ed219db1f97e4be29c9dac9cf6cd4b37";

function published(name) {
  return JSON.parse(readFileSync(join(PACK, "published", name), "utf8"));
}

function asLive(doc) {
  const copy = structuredClone(doc);
  copy.generatedAt = OBSERVED;
  copy.observation = { mode: "live", case: null, network: true };
  copy.nextAction.url = LIVE_URL;
  copy.nextAction.nativeId = "example/widget#9";
  copy.sources[0].evidenceClass = "live_public_get";
  copy.shortlistEvidence = {
    source: { adapterId: copy.nextAction.adapterId, sourceId: copy.nextAction.sourceId },
    observedAt: OBSERVED,
    status: copy.nextAction.state,
    rewardUnknown: true,
    costs: { cash: null, listEquivalent: null, economic: null, netAfterFees: null, profit: null },
  };
  return copy;
}

function pair() {
  const fixture = published("cold-shortlist.json");
  const live = asLive(fixture);
  const record = buildNextGet({
    fixture,
    live,
    fixtureArtifact: "experiments/l09-bounty-next-093076/published/cold-shortlist.json",
    liveArtifact: "experiments/l09-bounty-next-093076/published/live-shortlist.json",
    actionGet: {
      method: "GET",
      url: LIVE_URL,
      httpStatus: 200,
      observedAt: OBSERVED,
      error: null,
      bodyChars: 32,
    },
  });
  return { fixture, live, record };
}

test("live refresh refuses to overwrite the deterministic fixture shortlist", () => {
  const file = join(PACK, "published/cold-shortlist.json");
  const before = readFileSync(file);
  const ran = run([
    "refresh",
    "--mode",
    "live",
    "--now",
    NOW,
    "--out",
    "experiments/l09-bounty-next-093076/published/cold-shortlist.json",
  ]);
  assert.equal(ran.status, 3, ran.stderr);
  assert.match(ran.stderr, /deterministic fixture shortlist/);
  assert.equal(ran.stdout, "");
  assert.equal(readFileSync(file).equals(before), true);
});

test("live refresh refuses to overwrite the deterministic fixture cache", () => {
  const file = join(PACK, "published/refresh-cache.json");
  const before = readFileSync(file);
  const ran = run([
    "refresh",
    "--mode",
    "live",
    "--now",
    NOW,
    "--cache",
    "experiments/l09-bounty-next-093076/published/refresh-cache.json",
  ]);
  assert.equal(ran.status, 3, ran.stderr);
  assert.match(ran.stderr, /deterministic fixture cache/);
  assert.equal(ran.stdout, "");
  assert.equal(readFileSync(file).equals(before), true);
});

test("a next-get record keeps the fixture GET and the live GET apart", () => {
  const { fixture, live, record } = pair();
  assert.equal(record.fixture.url, FIXTURE_URL);
  assert.equal(record.live.url, LIVE_URL);
  assert.equal(record.artifactsDiffer, true);
  assert.equal(record.fixture.qualification.evidenceClass, "fixture");
  assert.equal(record.live.qualification.evidenceClass, "live_public_get");
  assert.equal(record.live.qualification.network, true);
  assert.equal(record.fixture.rewardUnknown, true);
  assert.equal(record.live.rewardUnknown, true);
  assert.equal(record.live.costs.cash, null);
  assert.equal(record.live.costs.profit, null);
  assert.equal(record.consumer.id, "earned-work-requester");
  assert.equal(record.consumer.handed, true);
  assert.equal(record.consumer.offerAuthored, false);
  assert.equal(record.live.actionGet.bodyStored, false);
  const summary = checkNextGet(record, { fixture, live });
  assert.equal(summary.ok, true);
  assert.equal(summary.fixtureUrl, FIXTURE_URL);
  assert.equal(summary.liveUrl, LIVE_URL);
  assert.equal(findLeak(record), null);
});

test("check-next refuses a fixture label on the live GET and a payment leak", () => {
  const dir = workDir();
  const { fixture, live, record } = pair();
  const fixturePath = join(dir, "fixture.json");
  const livePath = join(dir, "live.json");
  const nextPath = join(dir, "next.json");
  const fixtureRel = relative(PACK, fixturePath);
  const liveRel = relative(PACK, livePath);
  record.fixture.artifact = fixtureRel;
  record.live.artifact = liveRel;
  writeFileSync(fixturePath, JSON.stringify(fixture));
  writeFileSync(livePath, JSON.stringify(live));
  try {
    const mislabeled = structuredClone(record);
    mislabeled.live.qualification.evidenceClass = "fixture";
    writeFileSync(nextPath, JSON.stringify(mislabeled));
    const labeled = run(["check-next", "--artifact", relative(PACK, nextPath)]);
    assert.equal(labeled.status, 2, labeled.stderr);
    assert.equal(JSON.parse(labeled.stdout).refusal.code, "artifact_inconsistent");
    assert.equal(JSON.parse(labeled.stdout).nextAction, null);

    const leaked = structuredClone(record);
    leaked.paid = true;
    leaked.note = EMAIL;
    leaked.live.title = TX;
    writeFileSync(nextPath, JSON.stringify(leaked));
    const ran = run(["check-next", "--artifact", relative(PACK, nextPath)]);
    assert.equal(ran.status, 2, ran.stderr);
    const answer = JSON.parse(ran.stdout);
    assert.equal(answer.refusal.code, "payment_leak");
    assert.equal(answer.nextAction, null);
    assert.equal(ran.stdout.includes(EMAIL), false);
    assert.equal(ran.stdout.includes(TX), false);
    assert.equal(ran.stdout.includes("hidden-person"), false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("published live observation stays beside the fixture and hands the GET to the requester", async () => {
  const fixtureText = readFileSync(join(PACK, "published/cold-shortlist.json"), "utf8");
  const liveText = readFileSync(join(PACK, "published/live-shortlist.json"), "utf8");
  const nextText = readFileSync(join(PACK, "published/next-get.json"), "utf8");
  const cacheText = readFileSync(join(PACK, "published/refresh-cache.json"), "utf8");
  const liveCacheText = readFileSync(join(PACK, "published/live-refresh-cache.json"), "utf8");
  assert.notEqual(fixtureText, liveText);
  assert.notEqual(cacheText, liveCacheText);
  for (const text of [fixtureText, liveText, nextText, liveCacheText]) {
    assert.equal(findLeak(JSON.parse(text)), null);
    assert.equal(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/.test(text), false);
    assert.equal(/0x[0-9a-fA-F]{64}/.test(text), false);
    assert.equal(text.includes("<!DOCTYPE"), false);
    assert.equal(text.includes(TX), false);
  }
  const fixture = JSON.parse(fixtureText);
  const live = JSON.parse(liveText);
  const record = JSON.parse(nextText);
  const liveCache = JSON.parse(liveCacheText);
  assert.equal(fixture.nextAction.url, FIXTURE_URL);
  assert.equal(fixture.observation.mode, "fixture");
  assert.equal(fixture.observation.network, false);
  assert.equal(Object.hasOwn(fixture, "shortlistEvidence"), false);
  assert.equal(live.observation.mode, "live");
  assert.equal(live.observation.network, true);
  assert.equal(live.shortlistEvidence.rewardUnknown, true);
  assert.equal(live.shortlistEvidence.observedAt, live.generatedAt);
  assert.equal(live.shortlistEvidence.status, live.nextAction.state);
  assert.equal(live.shortlistEvidence.source.adapterId, live.nextAction.adapterId);
  assert.equal(live.shortlistEvidence.source.sourceId, live.nextAction.sourceId);
  assert.equal(live.shortlistEvidence.costs.cash, null);
  assert.equal(live.shortlistEvidence.costs.profit, null);
  assert.equal(live.costs.cash.value, null);
  assert.equal(live.costs.profit, null);
  assert.equal(live.syntheticProfitClaim, false);
  assert.equal(live.nextAction.method, "GET");
  assert.notEqual(live.nextAction.url, fixture.nextAction.url);
  assert.equal(live.consumer.id, "earned-work-requester");
  assert.equal(record.fixture.url, fixture.nextAction.url);
  assert.equal(record.live.url, live.nextAction.url);
  assert.equal(record.live.qualification.evidenceClass, "live_public_get");
  assert.equal(record.live.actionGet.bodyStored, false);
  assert.equal(record.live.actionGet.authenticated, false);
  assert.equal(record.consumer.handed, true);
  assert.equal(record.consumer.offerAuthored, false);
  const hash = `sha256:${createHash("sha256").update(liveText, "utf8").digest("hex")}`;
  assert.equal(liveCache.shortlistSha256, hash);
  assert.equal(liveCache.status, "filled");
  assert.equal(JSON.parse(cacheText).status, "filled");
  assert.equal(JSON.parse(cacheText).repeats, 0);

  const verified = run(["verify", "--artifact", "published/live-shortlist.json", "--now", live.generatedAt]);
  assert.equal(verified.status, 0, verified.stderr);
  const next = run(["next", "--artifact", "published/live-shortlist.json", "--now", live.generatedAt]);
  assert.equal(next.status, 0, next.stderr);
  assert.equal(JSON.parse(next.stdout).nextAction.url, live.nextAction.url);
  assert.equal(JSON.parse(next.stdout).nextAction.method, "GET");
  const checked = run(["check-next", "--artifact", "published/next-get.json"]);
  assert.equal(checked.status, 0, checked.stderr);
  const summary = JSON.parse(checked.stdout);
  assert.equal(summary.ok, true);
  assert.equal(summary.fixtureUrl, FIXTURE_URL);
  assert.equal(summary.liveUrl, live.nextAction.url);
  assert.equal(summary.rewardUnknown, true);
  assert.equal(summary.consumer, "earned-work-requester");
  assert.equal(summary.offerAuthored, false);

  const tampered = structuredClone(live);
  tampered.shortlistEvidence.rewardUnknown = false;
  const tamperedPath = join(PACK, "tests/tampered-live.json");
  writeFileSync(tamperedPath, JSON.stringify(tampered));
  try {
    const refused = run(["verify", "--artifact", relative(PACK, tamperedPath), "--now", live.generatedAt]);
    assert.equal(refused.status, 2, refused.stderr);
    assert.equal(JSON.parse(refused.stdout).refusal.code, "artifact_inconsistent");
    assert.equal(JSON.parse(refused.stdout).nextAction, null);
  } finally {
    rmSync(tamperedPath, { force: true });
  }

  await assert.rejects(
    () => authorOffer({
      baseUrl: "http://127.0.0.1:9",
      ownerToken: "local-test-owner",
      kernelPin: KERNEL_SHA,
      job: {
        title: live.nextAction.title,
        url: live.nextAction.url,
        lane: "externalAvailable",
      },
    }),
    (err) => err.code === "invalid_terms",
  );
});
