import { createHash } from "node:crypto";
import {
  ADAPTERS,
  CACHE_SCHEMA,
  DEFAULT_TTL_SECONDS,
  MAX_TTL_SECONDS,
  PREREQUISITES,
} from "./constants.mjs";
import { unknownCosts } from "./economics.mjs";
import { loadOperator } from "./operator.mjs";
import { fail, readPermitted } from "./paths.mjs";
import { parseReward, rewardView } from "./reward.mjs";
import { unavailableFetch, readSource } from "./sources.mjs";
import { scrubTitle } from "./scrub.mjs";
import { aggregateRefusal, assembleShortlist, compareCandidates, documentJson, liveShortlistEvidence } from "./shortlist.mjs";
import { isIsoZ } from "../../vf15-actionable-work/src/text.mjs";

const HAPPY_GITHUB = "experiments/vf15-actionable-work/fixtures/github/search-happy.json";
const HAPPY_BUGZILLA = "experiments/vf15-actionable-work/fixtures/bugzilla/bugs-happy.json";
const CLOSED_GITHUB = "experiments/vf15-actionable-work/fixtures/github/closed-only.json";
const CLOSED_BUGZILLA = "experiments/l09-bounty-next-093076/fixtures/bugzilla/closed-only.json";
const CHANGED_REWARD = "experiments/l09-bounty-next-093076/fixtures/reward/changed.json";

const WRITTEN = new Set(["closed", "unqualified", "source_unavailable", "changed_reward"]);

function requireNow(now) {
  if (!isIsoZ(now)) throw fail("usage", "now must be an ISO-8601 UTC timestamp");
  return now;
}

function requireTtl(ttl) {
  const value = ttl == null ? DEFAULT_TTL_SECONDS : ttl;
  if (!Number.isInteger(value) || value < 1 || value > MAX_TTL_SECONDS) {
    throw fail("usage", "ttl must be a whole number of seconds from 1 through 2592000");
  }
  return value;
}

function freshUntil(now, ttlSeconds) {
  return new Date(Date.parse(now) + ttlSeconds * 1000).toISOString();
}

function sha256(text) {
  return `sha256:${createHash("sha256").update(text, "utf8").digest("hex")}`;
}

function fingerprintOf(source) {
  if (source.bodySha256) return source.bodySha256;
  if (source.refusal?.code === "source_unavailable") return `unavailable:${source.httpStatus ?? "none"}`;
  return `unqualified:${source.refusal?.code ?? "none"}`;
}

function sortedObject(entries) {
  const out = {};
  for (const key of Object.keys(entries).sort()) out[key] = entries[key];
  return out;
}

export function loadCache(text) {
  let value;
  try {
    value = JSON.parse(text);
  } catch {
    throw fail("usage", "cache was not json");
  }
  if (!value || value.schema !== CACHE_SCHEMA || !value.sourceFingerprints || !value.rewardStatements) {
    throw fail("usage", "cache schema mismatch");
  }
  if (typeof value.operatorFingerprint !== "string") throw fail("usage", "cache operator fingerprint missing");
  if (!Number.isInteger(value.repeats) || value.repeats < 0) throw fail("usage", "cache repeats is not a count");
  return value;
}

function rewardDocument(cwd, rewardPath) {
  if (!rewardPath) return new Map();
  let parsed;
  try {
    parsed = JSON.parse(readPermitted(cwd, rewardPath).text);
  } catch (err) {
    if (err.code === "usage") throw err;
    throw fail("malformed_reward", "reward observations were not json");
  }
  return parseReward(parsed);
}

function sourceSpecs(options, now) {
  if (options.mode !== "fixture" && options.mode !== "live") {
    throw fail("usage", "mode must be fixture or live");
  }
  const pairs = [
    ["github-public-issues", options.githubPath],
    ["bugzilla-mozilla", options.bugzillaPath],
  ];
  return pairs.map(([adapterId, fixturePath]) => {
    if (options.mode === "live") {
      if (fixturePath) throw fail("usage", "live mode does not take a fixture path");
      return {
        adapterId,
        now,
        mode: "live",
        fetchImpl: options.fetchImpl,
        injectedTransport: options.injectedTransport === true,
        timeoutMs: options.timeoutMs ?? 8000,
      };
    }
    if (!fixturePath) throw fail("usage", "fixture mode requires both source fixtures");
    const read = readPermitted(options.cwd, fixturePath);
    return {
      adapterId,
      now,
      mode: "fixture",
      fixtureText: read.text,
      fixtureId: read.rel,
      injectedTransport: false,
    };
  });
}

function externalRow(source, observations, prior, costs) {
  const action = source.action;
  return {
    lane: "externalAvailable",
    adapterId: source.adapterId,
    sourceId: source.sourceId,
    nativeId: action.nativeId,
    title: scrubTitle(action.title),
    state: action.state,
    url: action.url,
    updatedAt: source.updatedAt,
    preferred: source.preferred === true,
    selected: false,
    selectable: false,
    availableAsExternalJob: true,
    sponsoredByOperator: false,
    reward: rewardView(action.nativeId, observations, prior),
    costs: structuredClone(costs),
    prerequisites: [...PREREQUISITES],
  };
}

function nextActionFrom(row, source) {
  if (source.action.method !== "GET" || source.action.kind !== "read_public_record") {
    throw fail("internal", "Neo209 action was not a public GET");
  }
  if (!Array.isArray(source.action.agentMay) || source.action.agentMay.length !== 1 || source.action.agentMay[0] !== "GET") {
    throw fail("internal", "Neo209 agentMay was not GET");
  }
  return {
    lane: "externalAvailable",
    kind: "read_public_record",
    method: "GET",
    url: row.url,
    nativeId: row.nativeId,
    title: row.title,
    state: row.state,
    sourceId: row.sourceId,
    adapterId: row.adapterId,
    prerequisites: [...PREREQUISITES],
    costs: structuredClone(row.costs),
    reward: structuredClone(row.reward),
    agentMay: [...source.action.agentMay],
    agentMustNot: [...source.action.agentMustNot],
  };
}

function cacheBody({ now, until, ttlSeconds, fingerprints, statements, operatorFingerprint, shortlistSha256, repeats, status, previous }) {
  return {
    schema: CACHE_SCHEMA,
    observedAt: now,
    freshUntil: until,
    ttlSeconds,
    sourceFingerprints: fingerprints,
    rewardStatements: statements,
    operatorFingerprint,
    shortlistSha256,
    repeats,
    status,
    previousSourceFingerprints: previous,
  };
}

export async function refreshPair(options) {
  const now = requireNow(options.now);
  const ttlSeconds = requireTtl(options.ttlSeconds);
  const observations = options.rewardValue ?? rewardDocument(options.cwd, options.rewardPath);
  const operator = loadOperator(options.cwd, options.operatorMode);
  const prior = options.priorRewardStatements ?? options.priorCache?.rewardStatements ?? null;
  const network = options.network === true;
  const sources = [];
  for (const spec of sourceSpecs(options, now)) {
    if (!ADAPTERS.includes(spec.adapterId)) throw fail("internal", "unexpected adapter");
    sources.push(await readSource(spec));
  }
  if (sources.map((source) => source.adapterId).join() !== ADAPTERS.join()) {
    throw fail("internal", "refresh did not cover both permitted sources");
  }
  const costs = unknownCosts();
  const byAdapter = new Map(sources.map((source) => [source.adapterId, source]));
  const rows = sources.filter((source) => source.qualified).map((source) => externalRow(source, observations, prior, costs));
  rows.sort(compareCandidates);
  const top = rows[0] ?? null;
  let refusal = null;
  let nextAction = null;
  let exitCode = 0;
  if (top?.reward.changed) {
    refusal = {
      code: "changed_reward",
      message: "the leading public record changed its reward statement. It is not the next action",
    };
    exitCode = 2;
  } else if (top) {
    top.selected = true;
    top.selectable = true;
    nextAction = nextActionFrom(top, byAdapter.get(top.adapterId));
    exitCode = 0;
  } else {
    refusal = aggregateRefusal(sources);
    exitCode = refusal.code === "source_unavailable" ? 4 : 2;
  }
  const sourceFingerprints = sortedObject(Object.fromEntries(sources.map((source) => [source.adapterId, fingerprintOf(source)])));
  const rewardStatements = sortedObject(
    Object.fromEntries(rows.map((row) => [row.nativeId, { statedAmount: row.reward.statedAmount, asset: row.reward.asset }])),
  );
  const doc = assembleShortlist({
    now,
    freshUntil: freshUntil(now, ttlSeconds),
    ttlSeconds,
    observation: {
      mode: options.observationCase ? "replay" : options.mode,
      case: options.observationCase ?? null,
      network,
    },
    costs,
    operatorItems: operator.items,
    rows,
    nextAction,
    refusal,
    sources,
    sourceFingerprints,
    rewardStatements,
    operatorFingerprint: operator.fingerprint,
    shortlistEvidence: options.mode === "live" && network && !options.observationCase && nextAction
      ? liveShortlistEvidence({ now, nextAction, costs })
      : null,
  });
  const json = documentJson(doc);
  let cache = null;
  if (exitCode === 0) {
    const priorCache = options.priorCache;
    let status = "filled";
    let repeats = 0;
    let previous = null;
    if (priorCache) {
      const sameSources = JSON.stringify(sortedObject(priorCache.sourceFingerprints)) === JSON.stringify(sourceFingerprints);
      const sameReward = JSON.stringify(sortedObject(priorCache.rewardStatements)) === JSON.stringify(rewardStatements);
      const sameOperator = priorCache.operatorFingerprint === operator.fingerprint;
      if (sameSources && sameReward && sameOperator) {
        status = "repeat";
        repeats = priorCache.repeats + 1;
      } else if (!sameSources) {
        status = "source_changed";
        previous = sortedObject(priorCache.sourceFingerprints);
      }
    }
    cache = cacheBody({
      now,
      until: doc.freshUntil,
      ttlSeconds,
      fingerprints: sourceFingerprints,
      statements: rewardStatements,
      operatorFingerprint: operator.fingerprint,
      shortlistSha256: sha256(json),
      repeats,
      status,
      previous,
    });
  }
  return {
    doc,
    json,
    exitCode,
    writeShortlist: exitCode === 0 || WRITTEN.has(refusal?.code),
    cache,
  };
}

export async function replayCase(caseName, options) {
  if (caseName === "closed") {
    return refreshPair({
      ...options,
      mode: "fixture",
      githubPath: CLOSED_GITHUB,
      bugzillaPath: CLOSED_BUGZILLA,
      rewardPath: null,
      rewardValue: new Map(),
      priorRewardStatements: null,
      observationCase: "closed",
      network: false,
    });
  }
  if (caseName === "unavailable") {
    return refreshPair({
      ...options,
      mode: "live",
      githubPath: null,
      bugzillaPath: null,
      rewardPath: null,
      rewardValue: new Map(),
      priorRewardStatements: null,
      fetchImpl: unavailableFetch(),
      injectedTransport: true,
      observationCase: "unavailable",
      network: false,
    });
  }
  if (caseName === "changed-reward") {
    return refreshPair({
      ...options,
      mode: "fixture",
      githubPath: HAPPY_GITHUB,
      bugzillaPath: HAPPY_BUGZILLA,
      rewardPath: CHANGED_REWARD,
      priorRewardStatements: {
        "bugzilla.mozilla.org#30": { statedAmount: null, asset: null },
        "example/widget#7": { statedAmount: null, asset: null },
      },
      observationCase: "changed-reward",
      network: false,
    });
  }
  throw fail("usage", "replay case must be closed, unavailable, or changed-reward");
}
