import assert from "node:assert/strict";
import { existsSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { join, relative } from "node:path";
import test from "node:test";
import { authorOffer } from "../../codex-window/h36-earned-requester-integration/src/author.mjs";
import { KERNEL_SHA } from "../../codex-window/h36-earned-requester-integration/src/constants.mjs";
import { BUGZILLA, GITHUB, NOW, PACK, REPO, run, workDir } from "./helpers.mjs";

test("the earned-work requester rejects an external shortlist row as an offer", async () => {
  await assert.rejects(
    () => authorOffer({
      baseUrl: "http://127.0.0.1:9",
      ownerToken: "local-test-owner",
      kernelPin: KERNEL_SHA,
      job: {
        title: "Read the public widget issue",
        url: "https://github.com/example/widget/issues/7",
        lane: "externalAvailable",
      },
    }),
    (err) => err.code === "invalid_terms",
  );
  const fixture = JSON.parse(readFileSync(join(
    REPO,
    "experiments/codex-window/h36-earned-requester-integration/fixtures/operator-declared-e18.json",
  ), "utf8"));
  assert.equal(fixture.fundingProvenance, "operator_declared");
  assert.equal(typeof fixture.outcome.summary, "string");
  assert.equal(fixture.reward.amount, "0.10");
});

test("a public fixture cannot be passed as operator-sponsored work", () => {
  const dir = workDir();
  const out = join(dir, "shortlist.json");
  try {
    const ran = run([
      "refresh",
      "--mode",
      "fixture",
      "--github",
      GITHUB,
      "--bugzilla",
      BUGZILLA,
      "--now",
      NOW,
      "--operator",
      GITHUB,
      "--out",
      relative(PACK, out),
    ]);
    assert.equal(ran.status, 2, ran.stderr);
    assert.equal(JSON.parse(ran.stdout).refusal.code, "lane_collision");
    assert.equal(JSON.parse(ran.stdout).nextAction, null);
    assert.equal(existsSync(out), false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("verify rejects a shortlist that has been given a profit figure", () => {
  const dir = workDir();
  const artifact = join(dir, "tampered.json");
  try {
    const doc = JSON.parse(readFileSync(join(PACK, "published/cold-shortlist.json"), "utf8"));
    doc.nextAction.reward.profit = "12.00";
    doc.syntheticProfitClaim = true;
    writeFileSync(artifact, JSON.stringify(doc));
    const ran = run(["verify", "--artifact", relative(PACK, artifact), "--now", NOW]);
    assert.equal(ran.status, 2, ran.stderr);
    const answer = JSON.parse(ran.stdout);
    assert.equal(answer.refusal.code, "synthetic_profit");
    assert.equal(answer.nextAction, null);
    assert.equal(ran.stdout.includes("12.00"), false);
    assert.equal(ran.stdout.includes("issues/7"), false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("this receiver has no dashboard page", () => {
  const names = readdirSync(PACK, { recursive: true }).map(String);
  assert.equal(names.some((name) => name.endsWith(".astro") || name.endsWith(".html")), false);
});
