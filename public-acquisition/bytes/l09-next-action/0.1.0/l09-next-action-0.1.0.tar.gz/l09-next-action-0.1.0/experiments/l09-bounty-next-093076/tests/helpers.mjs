import { spawnSync } from "node:child_process";
import { mkdtempSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

export const PACK = fileURLToPath(new URL("..", import.meta.url));
export const REPO = fileURLToPath(new URL("../../..", import.meta.url));
export const BIN = join(PACK, "bin/l09.mjs");
export const NOW = "2026-09-30T12:00:00.000Z";
export const GITHUB = "experiments/vf15-actionable-work/fixtures/github/search-happy.json";
export const BUGZILLA = "experiments/vf15-actionable-work/fixtures/bugzilla/bugs-happy.json";
export const LATER = "experiments/l09-bounty-next-093076/fixtures/github/search-later.json";

export function run(args) {
  return spawnSync(process.execPath, [BIN, ...args], { cwd: REPO, encoding: "utf8" });
}

export function workDir() {
  return mkdtempSync(join(PACK, "tests/work-"));
}

export function happyArgs(out, cache, extra = []) {
  return [
    "refresh",
    "--mode",
    "fixture",
    "--github",
    GITHUB,
    "--bugzilla",
    BUGZILLA,
    "--now",
    NOW,
    "--ttl",
    "86400",
    "--out",
    out,
    "--cache",
    cache,
    ...extra,
  ];
}
