import { hashTermsVersion } from "../../../packs/funded-task-terms/src/hash.mjs";
import { TASK_SPEC_SCHEMA } from "./constants.mjs";

const SUMMARY = [
  "Refresh one bounty-discovery capture with the existing query CLI,",
  "or repair one demonstrated adapter failure with a fixture that fails before the repair and passes after.",
  "Return JSON. A source-down, closed, empty, or unknown-reward result is a useful negative and meets acceptance.",
  "Do not manufacture a profitable decision. Do not claim, bid, pay, submit, or contact a maintainer.",
  "Proposed reward 0.10 USDC is not launched and is not a payout.",
].join(" ");

export function contributorTaskSpec() {
  const kernelTerms = {
    schema: "neomorphic.earned-work.terms.v1",
    schemaVersion: 1,
    taskId: "l09-bounty-capture-refresh-100148",
    termsRevision: 0,
    summary: SUMMARY,
    reward: { amount: "0.10", asset: "USDC", network: "base" },
    claimTtlSeconds: 86400,
    maxArtifactBytes: 1000000,
    allowedMediaTypes: ["application/json"],
    slotLimit: 1,
  };
  return {
    schema: TASK_SPEC_SCHEMA,
    launch: {
      state: "unlaunched",
      reason: "Proposed reward 0.10 USDC remains unlaunched until Root binds actual budget and payout.",
      claimAuthority: "none",
      paymentAuthority: "none",
      submitted: false,
      kernelCreateCalled: false,
    },
    provenance: "fixture",
    kernelTerms,
    termsVersion: hashTermsVersion(kernelTerms),
    acceptance: {
      paysForUsefulNegative: true,
      requiresFavorableDecision: false,
      objective: "Refresh a capture with the existing bounty-discovery query, or repair a demonstrated adapter.",
      checks: [
        "Artifact is JSON from the existing query CLI or a failing-then-passing adapter fixture.",
        "claimAuthority is none and paymentAuthority is none.",
        "Unknown or unverified reward is not labelled as a verified EV or as profitable.",
        "A closed, empty, or unavailable source is valid acceptance evidence.",
      ],
    },
    reward: {
      amount: "0.10",
      asset: "USDC",
      network: "base",
      launched: false,
      boundByRoot: false,
    },
  };
}
