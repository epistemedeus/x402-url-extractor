# L09 bounty next

Anonymous acquisition is the public archive
`public/downloads/l09-next-action/0.1.0/l09-next-action-0.1.0.tar.gz`
(`COLD-INSTALL.txt` in that directory). That archive is the executable.
A Git checkout is not required. `hostedAcquisitionVerified` on this pack
stays false until an external readback. A loopback fetch is not that
readback. The 0.10 USDC contributor spec stays unlaunched.

Cold machine shortlist for two permitted public sources. Neo209 qualifies each source. The retained bounty-economics modules annotate cost, and unknown stays unknown. The consumer is the existing earned-work requester. This package does not author an offer, reserve funds, or publish a page.

Operator-sponsored work is the pinned requester fixture `experiments/codex-window/h36-earned-requester-integration/fixtures/operator-declared-e18.json`. External rows are public GitHub issues and Mozilla bugs. Those rows are not offers. A stated reward is not a verified price and is not a profit figure.

## Sources

| Adapter | Role |
| --- | --- |
| `github-public-issues` | Neo209 unauthenticated GitHub issue search |
| `bugzilla-mozilla` | Neo209 unauthenticated Bugzilla REST search |

Both adapters are called on every refresh. Fixture mode is the deterministic path. `published/cold-shortlist.json` and `published/refresh-cache.json` stay on that path. `scripts/live-probe.mjs` is the labelled live read: it prints a report and exits 0 when a source is down, and it does not write this tree.

`persist-live` writes a separate live shortlist, a separate cache, and `published/next-get.json`. That record keeps the fixture GET and the live-qualified GET, with source, observed time, status, unknown reward, and the qualification GET. It does not replace the fixture files. The consumer remains the earned-work requester. No offer is authored.

## Commands

From the repository root:

```sh
node --test --test-concurrency=1 experiments/l09-bounty-next-093076/tests/*.test.mjs

node experiments/l09-bounty-next-093076/bin/l09.mjs refresh \
  --mode fixture \
  --github experiments/vf15-actionable-work/fixtures/github/search-happy.json \
  --bugzilla experiments/vf15-actionable-work/fixtures/bugzilla/bugs-happy.json \
  --now 2026-09-30T12:00:00.000Z \
  --ttl 86400 \
  --out experiments/l09-bounty-next-093076/published/cold-shortlist.json \
  --cache experiments/l09-bounty-next-093076/published/refresh-cache.json

node experiments/l09-bounty-next-093076/bin/l09.mjs verify \
  --artifact experiments/l09-bounty-next-093076/published/cold-shortlist.json \
  --now 2026-09-30T12:00:00.000Z

node experiments/l09-bounty-next-093076/bin/l09.mjs replay --case closed --now 2026-09-30T12:00:00.000Z
node experiments/l09-bounty-next-093076/bin/l09.mjs replay --case unavailable --now 2026-09-30T12:00:00.000Z
node experiments/l09-bounty-next-093076/bin/l09.mjs replay --case changed-reward --now 2026-09-30T12:00:00.000Z

node experiments/l09-bounty-next-093076/bin/l09.mjs persist-live \
  --now 2026-10-01T00:22:52.609Z \
  --ttl 86400

node experiments/l09-bounty-next-093076/bin/l09.mjs check-next \
  --artifact experiments/l09-bounty-next-093076/published/next-get.json
```

Exit 0 is a shortlist with one external GET. Exit 2 is a refusal (`closed`, `changed_reward`, `stale_cache`, `synthetic_profit`, `action_get_unverified`, and the other honesty refusals). Exit 4 is `source_unavailable`. Exit 3 is usage. `--out` and `--cache` must stay inside this directory. The parent directory must already exist. Live `--out` and `--cache` cannot be `published/cold-shortlist.json` or `published/refresh-cache.json`.

`check-next` reads the committed files and does not search. `persist-live` reads both public sources again, so a later run can select a different issue. The command above is the invocation that wrote the committed live observation.

`decide` reads the existing bounty-discovery snapshot (or a bounded live query through that pack) and the L09 shortlist. It does not add a source adapter. An agent supplies an effort budget and a capability inventory. The same open row is a public GET when the inventory covers its adapter and the budget covers the reuse range, and `skip_over_budget` when the inventory is empty and only the cold-build range applies. Advertised rewards stay unverified. Unknown reward does not become a verified EV or a profitable label. A subscription token allowance stays on the quota-shadow plane and is not cash at list price.

```sh
node experiments/l09-bounty-next-093076/bin/l09.mjs decide \
  --now 2026-10-01T09:51:46.000Z \
  --budget experiments/l09-bounty-next-093076/fixtures/decision/budget.json \
  --inventory experiments/l09-bounty-next-093076/fixtures/decision/inventory-reuse.json \
  --snapshot experiments/l09-bounty-next-093076/published/live-discovery-snapshot.json \
  --shortlist experiments/l09-bounty-next-093076/published/current-shortlist.json \
  --prior experiments/l09-bounty-next-093076/published/stale-snapshot-decision.json \
  --discovery cached \
  --out experiments/l09-bounty-next-093076/published/opportunity-record.json
```

That command is the cached read of the capture taken at `2026-10-01T09:51:46.000Z` (`packs/bounty-discovery/captures/live-2026-10-01T09-51-46-000Z`, `maxPages` 1). It does not use the network. The same command with `fixtures/decision/inventory-empty.json` and `--out experiments/l09-bounty-next-093076/published/cold-budget-decision.json` is the cold-build case: the next action is null and the outcome is `negative_shortlist`. Reuse of `adapter:github-public-issues` keeps `public_get`. A row whose source id is absent from the inventory, such as `source:agentbounties`, stays `skip_over_budget` on this budget even when other sources are reused. Re-running `decide` measures requester wall-clock again, so the millisecond field changes. Contributor tokens stay unknown.

`read-record` is a second process read of the opportunity record. `verify-decision` refuses a profitable label. `task-spec` prints the unlaunched 0.10 USDC contributor terms. `machine-entry --record FILE --publish yes` writes only `public/labs/bounty-discovery/next-action.json`.

`next --artifact FILE --now ISO` reads the published shortlist and does not search. Past `freshUntil`, the answer's action is null and the old URL is not repeated. A later `refresh` reads the sources again. Repeat refreshes of the same fixtures, reward observations, and operator fixture keep the shortlist bytes and increment `cache.repeats`. A different source body sets `cache.status` to `source_changed` and does not keep the previous URL as the action.

A changed reward statement on the leading row refuses that next action and does not promote the other source. The stored cache keeps the previous reward baseline. Deleting the cache is how a later observation starts clean. There is no flag that accepts an unverified amount.

`--reward` files that carry a profit claim, mark an external amount known, or carry a payment, claimant, or participant field are refused before a shortlist file is written. `--operator` accepts only the pinned requester fixture, or `none`.

A public title is stored only after email addresses and 64-hex transaction hashes are replaced with `[redacted]`. The published shortlist does not carry settlement, owed, paid, claimant, or wallet fields. Operator-sponsored work stays on the earned-work requester and is not an external job.

## Pins

`PINS.json` names Neo209 (merge `b4b63985d1edcf2c9b39cce922034a8c8be48555`), the read-only economics modules, and the requester module. The effort-workflow example on this clone is synthetic, so this receiver does not run it.
