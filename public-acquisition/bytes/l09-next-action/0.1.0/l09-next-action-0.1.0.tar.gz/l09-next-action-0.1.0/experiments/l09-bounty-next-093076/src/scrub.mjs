/**
 * Published shortlist guard. Payment, claimant, and participant fields stay
 * out of the artifact. Titles may keep a public locator after redaction.
 */

const EMAIL = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/;
const TX = /0x[0-9a-fA-F]{64}/;

const PAYMENT_KEYS = new Set([
  "paid",
  "payout",
  "payoutissued",
  "payoutaddress",
  "payoutaddresspublished",
  "payoutaddressrequested",
  "owed",
  "owedusdc",
  "paidusdc",
  "transferperformed",
  "tx",
  "transaction",
  "transactionhash",
  "claimant",
  "claimantemail",
  "participant",
  "participantemail",
  "participantname",
  "wallet",
  "settlement",
  "bankedrevenue",
]);

export function scrubTitle(value) {
  return String(value)
    .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, "[redacted]")
    .replace(/0x[0-9a-fA-F]{64}/g, "[redacted]");
}

export function findLeak(value, seen = new Set()) {
  return walkLeak(value, seen, true);
}

/**
 * Opportunity records keep public source URLs. A 0x listing id is a source
 * native id, not a payment key. Emails and payment keys still refuse.
 */
export function findRecordLeak(value, seen = new Set()) {
  return walkLeak(value, seen, false);
}

function walkLeak(value, seen, flagTx) {
  if (typeof value === "string") {
    if (EMAIL.test(value)) return "email";
    if (flagTx && TX.test(value)) return "tx";
    return null;
  }
  if (!value || typeof value !== "object") return null;
  if (seen.has(value)) return null;
  seen.add(value);
  if (Array.isArray(value)) {
    for (const item of value) {
      const hit = walkLeak(item, seen, flagTx);
      if (hit) return hit;
    }
    return null;
  }
  for (const [key, item] of Object.entries(value)) {
    if (PAYMENT_KEYS.has(key.toLowerCase())) return key;
    const hit = walkLeak(item, seen, flagTx);
    if (hit) return hit;
  }
  return null;
}
