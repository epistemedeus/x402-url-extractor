/**
 * Writes the live shortlist, its cache, and the paired next-GET record.
 * Refuses to replace the deterministic fixture files.
 */
import { publicGet } from "../../vf15-actionable-work/src/http.mjs";
import { FIXTURE_OUTPUTS } from "./constants.mjs";
import { fail, readPermitted, repoRelative, resolveOutputInside, writeConfined } from "./paths.mjs";
import { buildNextGet, checkNextGet } from "./next-get.mjs";
import { refreshPair } from "./refresh.mjs";
import { findLeak } from "./scrub.mjs";
import { documentJson, refusalDocument } from "./shortlist.mjs";

const GITHUB_ISSUE = /^https:\/\/github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/issues\/\d+$/;
const BUGZILLA_BUG = /^https:\/\/bugzilla\.mozilla\.org\/show_bug\.cgi\?id=\d+$/;

function assertSeparate(rel, label) {
  if (FIXTURE_OUTPUTS.includes(rel)) {
    throw fail("usage", `live mode does not overwrite the deterministic fixture ${label}`);
  }
}

export async function qualifyActionGet(url, observedAt) {
  if (typeof url !== "string" || (!GITHUB_ISSUE.test(url) && !BUGZILLA_BUG.test(url))) {
    throw fail("artifact_inconsistent", "next action url is not a permitted public GET");
  }
  const response = await publicGet(url, {
    timeoutMs: 20000,
    headers: {
      Accept: "text/html,application/json",
      "User-Agent": "neomorphic-vf15-actionable-work",
    },
  });
  const bodyChars = response.ok ? response.text.length : null;
  return {
    method: "GET",
    url,
    httpStatus: response.status,
    observedAt,
    error: response.error,
    bodyStored: false,
    authenticated: false,
    bodyChars,
    ok: response.ok === true && response.error == null && response.status >= 200 && response.status < 300,
  };
}

export async function persistLiveObservation(options) {
  const cwd = options.cwd;
  const fixturePath = options.fixturePath ?? "published/cold-shortlist.json";
  const outPath = options.outPath ?? "published/live-shortlist.json";
  const cachePath = options.cachePath ?? "published/live-refresh-cache.json";
  const nextPath = options.nextPath ?? "published/next-get.json";
  const fixtureRead = readPermitted(cwd, fixturePath);
  let fixture;
  try {
    fixture = JSON.parse(fixtureRead.text);
  } catch {
    throw fail("artifact_unreadable", "fixture shortlist was not json");
  }
  const out = resolveOutputInside(cwd, outPath);
  const cache = resolveOutputInside(cwd, cachePath);
  const next = resolveOutputInside(cwd, nextPath);
  assertSeparate(out.rel, "shortlist");
  assertSeparate(cache.rel, "cache");
  assertSeparate(next.rel, "next get");
  const destinations = new Set([out.abs, cache.abs, next.abs]);
  if (destinations.size !== 3) throw fail("usage", "live outputs must be three different files");
  if (destinations.has(fixtureRead.abs)) throw fail("usage", "live mode does not overwrite the deterministic fixture shortlist");

  const result = await refreshPair({
    cwd,
    mode: "live",
    now: options.now,
    ttlSeconds: options.ttlSeconds,
    network: true,
    timeoutMs: options.timeoutMs ?? 20000,
    operatorMode: options.operatorMode,
  });
  if (result.exitCode !== 0 || !result.doc?.nextAction) {
    return { exitCode: result.exitCode, json: result.json, wrote: false };
  }
  if (findLeak(result.doc)) throw fail("payment_leak", "shortlist carries a payment, claimant, or participant field");
  const actionGet = await qualifyActionGet(result.doc.nextAction.url, result.doc.generatedAt);
  if (!actionGet.ok) {
    const refusal = refusalDocument(options.now, {
      code: "action_get_unverified",
      message: "the qualified next action URL did not return a public 2xx GET",
    });
    return { exitCode: 2, json: documentJson(refusal), wrote: false };
  }
  const nextDoc = buildNextGet({
    fixture,
    live: result.doc,
    fixtureArtifact: fixtureRead.rel,
    liveArtifact: repoRelative(out.abs),
    actionGet,
  });
  checkNextGet(nextDoc, { fixture, live: result.doc });
  writeConfined(out.abs, result.json);
  writeConfined(cache.abs, documentJson(result.cache));
  writeConfined(next.abs, documentJson(nextDoc));
  return { exitCode: 0, json: documentJson(nextDoc), wrote: true };
}
