import { createHash } from "node:crypto";
import { isIsoZ } from "../../vf15-actionable-work/src/text.mjs";
import { CONSUMER, PUBLIC_ENTRY_SCHEMA, QUESTION, RECORD_SCHEMA } from "./constants.mjs";
import { allowanceView, economicsAnnotation, parseBudget, parseInventory } from "./budget.mjs";
import { annotateOpportunity, chooseAction, representativesFromSnapshot, rowsFromShortlist } from "./opportunity.mjs";
import { fail } from "./paths.mjs";
import { findRecordLeak } from "./scrub.mjs";

function sha256(value) {
  return `sha256:${createHash("sha256").update(value).digest("hex")}`;
}

function retainNegatives(prior, current, recordedAt) {
  const seen = new Set(current.map((item) => item.id));
  const kept = [];
  for (const item of prior?.negativeEvidence ?? []) {
    if (!item?.id || seen.has(item.id)) continue;
    kept.push({ ...item, retainedFrom: prior.recordedAt ?? recordedAt, absentFromCurrentCapture: true });
  }
  return [...current, ...kept].slice(0, 40);
}

export function decide(input) {
  if (!input || !isIsoZ(input.now)) throw fail("usage", "now must be an ISO-8601 UTC timestamp");
  const budget = parseBudget(input.budget);
  const inventory = parseInventory(input.inventory);
  const economics = economicsAnnotation();
  const discovery = representativesFromSnapshot(input.snapshot, input.now);
  const shortlist = rowsFromShortlist(input.shortlist ?? null, input.now);
  const draft = [...shortlist.rows, ...discovery.rows];
  const opportunities = draft.map((row) => annotateOpportunity(row, budget, inventory, economics));
  const decision = chooseAction(opportunities, input.now);
  const chosen = decision.nextAction
    ? opportunities.find((row) => row.identity === decision.nextAction.identity) ?? null
    : null;
  const negatives = retainNegatives(
    input.prior ?? null,
    [...shortlist.negatives, ...discovery.negatives],
    input.now,
  );
  const history = [];
  if (input.prior?.schema === RECORD_SCHEMA) {
    history.push(...(Array.isArray(input.prior.history) ? input.prior.history : []));
    history.push({
      recordedAt: input.prior.recordedAt ?? null,
      outcome: input.prior.decision?.outcome ?? null,
      nextAction: input.prior.decision?.nextAction?.kind ?? null,
      identity: input.prior.decision?.nextAction?.identity ?? null,
      negativeEvidence: Array.isArray(input.prior.negativeEvidence) ? input.prior.negativeEvidence.length : 0,
    });
  }
  const maintained = [...discovery.sources, ...shortlist.sources].filter((source) => source.maintained && source.supported !== false && source.outcome !== "error");
  const record = {
    schema: RECORD_SCHEMA,
    question: QUESTION,
    recordedAt: input.now,
    claimAuthority: "none",
    paymentAuthority: "none",
    syntheticProfitClaim: false,
    consumer: {
      id: CONSUMER.id,
      module: CONSUMER.module,
      offerAuthored: false,
      externalIsNotAnOffer: true,
    },
    inputs: {
      now: input.now,
      snapshotCapturedAt: discovery.capturedAt,
      snapshotSha256: input.snapshotSha256 ?? null,
      shortlistGeneratedAt: input.shortlist?.generatedAt ?? null,
      shortlistSha256: input.shortlistSha256 ?? null,
      budgetSha256: sha256(JSON.stringify(budget)),
      inventorySha256: sha256(JSON.stringify(inventory)),
      discoveryMode: input.discoveryMode ?? "cached",
    },
    limits: {
      claimAuthority: "none",
      paymentAuthority: "none",
      safeToStartWork: false,
      offer: false,
      profitableLabel: false,
      verifiedEv: null,
      allowanceIsCash: false,
      listPriceApplied: false,
    },
    considered: discovery.considered,
    sources: [...shortlist.sources, ...discovery.sources],
    maintainedSourceContracts: [...new Set(maintained.map((source) => source.sourceContract))],
    opportunities,
    negativeEvidence: negatives,
    allowance: allowanceView(budget),
    economics: {
      verifiedEv: null,
      profitable: null,
      fees: economics.fees,
      breakEven: economics.breakEvenGross,
      sensitivityModule: economics.sensitivityModule,
      planes: economics.planes,
    },
    decision: {
      ...decision,
      sensitivity: chosen ? chosen.sensitivity : null,
    },
    effort: {
      requester: input.measurement?.requesterWallClockMs != null
        ? { measured: true, wallClockMs: input.measurement.requesterWallClockMs, tokens: { kind: "unknown", value: null } }
        : { measured: false, wallClockMs: null, tokens: { kind: "unknown", value: null } },
      contributor: { measured: false, wallClockMs: null, tokens: { kind: "unknown", value: null } },
    },
    history: history.slice(-20),
  };
  assertHonest(record);
  return { exitCode: decision.outcome === "supported_action" ? 0 : 0, record };
}

function assertHonest(record) {
  const problem = honestyProblem(record);
  if (problem) throw fail(problem.code, problem.message);
}

function honestyProblem(record) {
  if (!record || record.schema !== RECORD_SCHEMA) return { code: "artifact_unreadable", message: "not an opportunity record" };
  if (record.claimAuthority !== "none" || record.paymentAuthority !== "none") {
    return { code: "artifact_inconsistent", message: "authority is not none" };
  }
  if (record.limits?.safeToStartWork !== false || record.limits?.offer !== false) {
    return { code: "artifact_inconsistent", message: "limits allow starting work or an offer" };
  }
  if (JSON.stringify(record).includes("/tmp/") || JSON.stringify(record).includes("pilot-heavy-relay")) {
    return { code: "artifact_inconsistent", message: "record cites a private path" };
  }
  const leak = findRecordLeak(record);
  if (leak) return { code: "payment_leak", message: `record carries ${leak}` };
  if (record.economics?.verifiedEv != null || record.decision?.verifiedEv != null || record.decision?.profitable != null) {
    return { code: "synthetic_profit", message: "verified EV or profitable label is set" };
  }
  if (record.decision?.ranksAsProfitable === true) {
    return { code: "synthetic_profit", message: "the decision ranked an unknown reward as profitable" };
  }
  if (record.decision?.revenueProof === true && record.decision?.opportunityClass !== "paid_revenue") {
    return { code: "synthetic_profit", message: "the decision claimed revenue proof without a verified receipt" };
  }
  if (record.allowance?.cash?.value != null || record.allowance?.listEquivalent?.value != null) {
    return { code: "allowance_booked_as_cash", message: "allowance was written into cash or list price" };
  }
  if (record.allowance?.subscriptionAllowance?.listPriceApplied === true || record.allowance?.subscriptionAllowance?.cashSpent === true) {
    return { code: "allowance_booked_as_cash", message: "allowance is marked as cash or list price" };
  }
  const text = JSON.stringify(record);
  if (text.includes('"profitable":true') || text.includes('"verifiedEv":"') || /"verifiedEv":\d/.test(text)) {
    return { code: "synthetic_profit", message: "a profitable label or numeric verified EV is present" };
  }
  for (const row of record.opportunities ?? []) {
    if (row.verifiedEv != null || row.profitable != null) {
      return { code: "synthetic_profit", message: "opportunity carries verified EV or a profitable label" };
    }
    if (row.reward?.verified === true && row.reward.verification !== "verified_receipt") {
      return { code: "unverified_reward_marked_known", message: "verified reward lacks a receipt" };
    }
    if (row.reward?.verified !== true && row.label !== "unverified_reward_not_an_ev") {
      return { code: "synthetic_profit", message: "unverified reward produced an EV label" };
    }
    if (row.reward?.verified === true && row.label === "unverified_reward_not_an_ev") {
      return { code: "artifact_inconsistent", message: "verified receipt was labelled unverified" };
    }
    if (row.ranksAsProfitable === true) {
      return { code: "synthetic_profit", message: "an opportunity ranked itself as profitable" };
    }
    if (row.opportunityClass) {
      const blob = `${row.sourceUrl || ""} ${row.identity || ""} ${row.title || ""}`.toLowerCase();
      const unknownReward = row.reward?.amount == null || row.reward?.verification === "unknown";
      if (unknownReward && row.opportunityClass === "paid_revenue") {
        return { code: "synthetic_profit", message: "unknown reward was classed as paid revenue" };
      }
      if (row.revenueProof === true && row.opportunityClass !== "paid_revenue") {
        return { code: "synthetic_profit", message: "revenue proof was set without a verified receipt" };
      }
      if (blob.includes("volunteer") && (row.opportunityClass !== "information" || row.revenueProof === true)) {
        return { code: "synthetic_profit", message: "volunteer issue GET was treated as revenue" };
      }
    }
    const cold = row.sensitivity?.cases?.find((item) => item.name === "cold_build");
    const reuse = row.sensitivity?.cases?.find((item) => item.name === "reused_integration");
    if (!cold || !reuse || cold.inputTokens?.high === reuse.inputTokens?.high) {
      return { code: "artifact_inconsistent", message: "budget and reuse ranges do not differ" };
    }
  }
  if ((record.maintainedSourceContracts ?? []).length < 1 && (record.opportunities ?? []).length === 0) {
    return { code: "artifact_inconsistent", message: "record has no source contract" };
  }
  if (!Array.isArray(record.negativeEvidence)) return { code: "artifact_inconsistent", message: "negative evidence is missing" };
  return null;
}

export function verifyDecision(record) {
  const problem = honestyProblem(record);
  if (problem) {
    return {
      exitCode: 2,
      answer: {
        schema: "neomorphic.l09.decision_check.v1",
        ok: false,
        refusal: problem,
        nextAction: null,
        profitable: null,
        verifiedEv: null,
        claimAuthority: "none",
        paymentAuthority: "none",
      },
    };
  }
  return {
    exitCode: 0,
    answer: {
      schema: "neomorphic.l09.decision_check.v1",
      ok: true,
      question: QUESTION,
      outcome: record.decision.outcome,
      nextAction: record.decision.nextAction,
      maintainedSourceContracts: record.maintainedSourceContracts,
      negativeEvidence: record.negativeEvidence.length,
      profitable: null,
      verifiedEv: null,
      claimAuthority: "none",
      paymentAuthority: "none",
      requesterEffortMeasured: record.effort?.requester?.measured === true,
      contributorEffort: "unknown",
    },
  };
}

export function publicMachineEntry(record) {
  const checked = verifyDecision(record);
  if (checked.exitCode !== 0) throw fail(checked.answer.refusal.code, checked.answer.refusal.message);
  const action = record.decision.nextAction;
  return {
    schema: PUBLIC_ENTRY_SCHEMA,
    recordedAt: record.recordedAt,
    question: QUESTION,
    claimAuthority: "none",
    paymentAuthority: "none",
    profitable: null,
    verifiedEv: null,
    humanPage: false,
    nextAction: action
      ? {
        kind: action.kind,
        method: action.method,
        url: action.url,
        sourceContract: action.sourceContract,
        authenticated: false,
        reason: action.reason,
      }
      : null,
    outcome: record.decision.outcome,
    receipt: "experiments/l09-bounty-next-093076/published/opportunity-record.json",
    maintainedSourceContracts: record.maintainedSourceContracts,
  };
}
