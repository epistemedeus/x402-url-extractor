import { DISCOVERY_SNAPSHOT_SCHEMA } from "./constants.mjs";
import { fail } from "./paths.mjs";

export async function loadDiscovery({ mode, now, snapshot }) {
  if (mode === "live") {
    const { queryFiveSource } = await import("../../../packs/bounty-discovery/src/five-source/query.mjs");
    const { projectSnapshot } = await import("../../../packs/bounty-discovery/src/five-source/snapshot.mjs");
    const compiled = await queryFiveSource({
      mode: "live",
      now,
      maxPages: 1,
      allowFixtureSeed: false,
    });
    const projected = projectSnapshot(compiled, { maxPages: 1 });
    if (projected.schema !== DISCOVERY_SNAPSHOT_SCHEMA) {
      throw fail("artifact_unreadable", "live discovery snapshot schema mismatch");
    }
    return { snapshot: projected, mode: "live" };
  }
  if (!snapshot || snapshot.schema !== DISCOVERY_SNAPSHOT_SCHEMA) {
    throw fail("artifact_unreadable", "discovery snapshot schema mismatch");
  }
  return { snapshot, mode: "cached" };
}
