import { costPlanes } from "../../bounty-economics-20260912/src/costs.mjs";
import { breakEvenGross } from "../../bounty-economics-20260912/src/wallet.mjs";
import { evaluateSensitivity } from "../../bounty-economics-20260912/src/sensitivity.mjs";
import { SENSITIVITY_INPUT_SCHEMA } from "../../bounty-economics-20260912/src/constants.mjs";
import { BUDGET_SCHEMA, EFFORT_ASSUMPTIONS, INVENTORY_SCHEMA } from "./constants.mjs";
import { fail } from "./paths.mjs";

function plain(value, message) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw fail("usage", message);
  return value;
}

function maxOf(block, field) {
  plain(block, `${field} must be an object`);
  if (!Number.isInteger(block.max) || block.max < 0) throw fail("usage", `${field}.max must be a non-negative integer`);
  return block.max;
}

export function parseBudget(input) {
  plain(input, "budget must be an object");
  if (input.schema !== BUDGET_SCHEMA) throw fail("usage", "budget schema mismatch");
  if (input.cash && input.cash.kind !== "unknown") {
    throw fail("cost_not_unknown", "cash spend is unknown; a list price or allowance is not cash");
  }
  if (input.cash && input.cash.value != null) throw fail("cost_not_unknown", "unknown cash cannot carry a value");
  const allowance = input.subscriptionAllowance ?? null;
  if (allowance) {
    plain(allowance, "subscription allowance must be an object");
    if (allowance.bookedAsCash === true || allowance.notCash !== true || allowance.notListPrice !== true) {
      throw fail("allowance_booked_as_cash", "subscription allowance is opportunity cost, not cash at list price");
    }
    if (allowance.plane !== "quota_shadow") throw fail("allowance_booked_as_cash", "allowance plane must be quota_shadow");
    for (const key of ["inputTokens", "outputTokens"]) {
      if (!Number.isInteger(allowance[key]) || allowance[key] < 0) {
        throw fail("usage", `subscription allowance ${key} must be a non-negative integer`);
      }
    }
  }
  return {
    schema: BUDGET_SCHEMA,
    inputTokens: { max: maxOf(input.inputTokens, "inputTokens") },
    outputTokens: { max: maxOf(input.outputTokens, "outputTokens") },
    reviewMinutes: { max: maxOf(input.reviewMinutes, "reviewMinutes") },
    cash: { kind: "unknown", value: null, unit: "USDC" },
    subscriptionAllowance: allowance
      ? {
        inputTokens: allowance.inputTokens,
        outputTokens: allowance.outputTokens,
        plane: "quota_shadow",
        notCash: true,
        notListPrice: true,
      }
      : null,
  };
}

export function parseInventory(input) {
  plain(input, "inventory must be an object");
  if (input.schema !== INVENTORY_SCHEMA) throw fail("usage", "inventory schema mismatch");
  if (!Array.isArray(input.capabilities)) throw fail("usage", "inventory capabilities must be an array");
  const capabilities = [];
  const seen = new Set();
  for (const item of input.capabilities) {
    plain(item, "capability must be an object");
    if (typeof item.id !== "string" || item.id.length < 3 || item.id.length > 120) {
      throw fail("usage", "capability id is missing");
    }
    if (item.kind !== "reused_integration") throw fail("usage", "capability kind must be reused_integration");
    if (seen.has(item.id)) throw fail("usage", "duplicate capability");
    seen.add(item.id);
    capabilities.push({ id: item.id, kind: "reused_integration" });
  }
  capabilities.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  return { schema: INVENTORY_SCHEMA, capabilities };
}

function fitsRange(range, max) {
  if (range.high <= max) return "inside";
  if (range.low <= max) return "partial";
  return "over";
}

export function postureFor(requiredCapabilities, inventory) {
  const have = new Set(inventory.capabilities.map((item) => item.id));
  const reused = requiredCapabilities.length > 0 && requiredCapabilities.every((id) => have.has(id));
  return reused ? "reused_integration" : "cold_build";
}

export function effortFor(actionKind, posture) {
  const table = EFFORT_ASSUMPTIONS[actionKind] ?? EFFORT_ASSUMPTIONS.public_get;
  const band = posture === "reused_integration" ? table.reuse : table.cold;
  return {
    measured: false,
    assumption: EFFORT_ASSUMPTIONS.assumption,
    inputTokens: { ...band.inputTokens },
    outputTokens: { ...band.outputTokens },
    reviewMinutes: { ...band.reviewMinutes },
  };
}

export function budgetFit(effort, budget) {
  const parts = {
    inputTokens: fitsRange(effort.inputTokens, budget.inputTokens.max),
    outputTokens: fitsRange(effort.outputTokens, budget.outputTokens.max),
    reviewMinutes: fitsRange(effort.reviewMinutes, budget.reviewMinutes.max),
  };
  const fits = Object.values(parts).every((part) => part === "inside") ? "inside" : "over";
  return { fits, parts };
}

/**
 * Ask the economics modules what an unknown reward and an allowance cost.
 * The allowance stays on the quota-shadow plane. It is not written into cash
 * and it is not priced at a list rate this pack does not have.
 */
export function economicsAnnotation() {
  let planes;
  let breakEven;
  let sensitivity;
  try {
    planes = costPlanes({
      tokens: {},
      rates: {},
      cash: { kind: "unknown" },
      subscriptionAllocation: { kind: "unknown" },
      quotaShadow: { kind: "unknown" },
      settlementCurrency: "USDC",
    });
    breakEven = breakEvenGross({ settlementCurrency: "USDC" });
    sensitivity = evaluateSensitivity({
      schema: SENSITIVITY_INPUT_SCHEMA,
      label: "hypothetical",
      currency: "USDC",
      inputs: {
        payout: { kind: "unknown" },
        inputTokens: { kind: "unknown" },
        outputTokens: { kind: "unknown" },
        inputPricePerMillion: { kind: "unknown" },
        outputPricePerMillion: { kind: "unknown" },
        acceptanceProbability: { kind: "unknown" },
        reviewerMinutes: { kind: "unknown" },
      },
    });
  } catch (err) {
    if (err.code === "cost_not_unknown") throw err;
    throw fail("cost_not_unknown", "effort-economics refused unknown reward inputs");
  }
  if (planes.cash?.value != null || planes.listEquivalent?.value != null || planes.economic?.value != null) {
    throw fail("cost_not_unknown", "effort-economics returned a number for unknown inputs");
  }
  if (breakEven.breakEvenGross?.value != null) {
    throw fail("cost_not_unknown", "break-even was numeric for unknown inputs");
  }
  const expectedNet = sensitivity?.result?.expectedNet;
  if (expectedNet && expectedNet.value != null) {
    throw fail("synthetic_profit", "sensitivity produced a net from an unknown reward");
  }
  return {
    fees: {
      rate: { kind: "unknown", value: null },
      flat: { kind: "unknown", value: null },
      statedBySource: false,
      note: "No fee was stated. Unknown is not zero.",
    },
    breakEvenGross: {
      kind: "unknown",
      value: null,
      unit: "USDC",
      reason: "Break-even needs known stage probabilities and costs. An advertised or unknown reward is not that input.",
      module: "experiments/bounty-economics-20260912/src/wallet.mjs",
    },
    sensitivityModule: {
      module: "experiments/bounty-economics-20260912/src/sensitivity.mjs",
      invoked: true,
      usedAdvertisedReward: false,
      expectedNet: null,
      verifiedEv: null,
      profitable: null,
      actualEarnings: null,
      privateSourceCopied: false,
    },
    planes: {
      cash: { kind: "unknown", value: null, unit: "USDC" },
      listEquivalent: { kind: "unknown", value: null, unit: "USDC" },
      economic: { kind: "unknown", value: null, unit: "USDC" },
    },
  };
}

export function allowanceView(budget) {
  const allowance = budget.subscriptionAllowance;
  return {
    cash: {
      kind: "unknown",
      value: null,
      unit: "USDC",
      reason: "A subscription token allowance is not cash spent.",
    },
    listEquivalent: {
      kind: "unknown",
      value: null,
      unit: "USDC",
      reason: "List price is not applied to the allowance. This pack has no vendor price catalog.",
    },
    subscriptionAllowance: allowance
      ? {
        plane: "quota_shadow",
        opportunityCost: true,
        cashSpent: false,
        listPriceApplied: false,
        inputTokens: allowance.inputTokens,
        outputTokens: allowance.outputTokens,
      }
      : { kind: "unknown", value: null, opportunityCost: true, cashSpent: false, listPriceApplied: false },
    economic: {
      kind: "unknown",
      value: null,
      unit: "USDC",
      reason: "Economic cost needs cash and a quota shadow price. Neither is invented from the allowance.",
    },
  };
}
