import assert from "node:assert/strict";
import test from "node:test";
import { NOW, run } from "./helpers.mjs";

function replay(caseName) {
  return run(["replay", "--case", caseName, "--now", NOW]);
}

test("closed replay exits 2 and keeps operator work off the external lane", () => {
  const ran = replay("closed");
  assert.equal(ran.status, 2, ran.stderr);
  const doc = JSON.parse(ran.stdout);
  assert.equal(doc.refusal.code, "closed");
  assert.equal(doc.nextAction, null);
  assert.equal(doc.lanes.externalAvailable.length, 0);
  assert.equal(doc.lanes.operatorSponsored.length, 1);
  assert.equal(doc.lanes.operatorSponsored[0].availableAsExternalJob, false);
  assert.equal(doc.observation.case, "closed");
  assert.equal(doc.observation.network, false);
  assert.deepEqual(doc.sources.map((source) => source.evidenceClass), ["fixture", "fixture"]);
});

test("unavailable replay exits 4 without calling the network", () => {
  const ran = replay("unavailable");
  assert.equal(ran.status, 4, ran.stderr);
  const doc = JSON.parse(ran.stdout);
  assert.equal(doc.refusal.code, "source_unavailable");
  assert.equal(doc.nextAction, null);
  assert.equal(doc.observation.network, false);
  assert.deepEqual(doc.sources.map((source) => source.evidenceClass), ["replay_injected_fetch", "replay_injected_fetch"]);
  assert.deepEqual(doc.sources.map((source) => source.httpStatus), [503, 503]);
  assert.equal(doc.lanes.operatorSponsored.length, 1);
  assert.equal(doc.lanes.operatorSponsored[0].action.kind, "held_by_earned_work_requester");
});

test("changed-reward replay exits 2 and does not promote the runner-up", () => {
  const ran = replay("changed-reward");
  assert.equal(ran.status, 2, ran.stderr);
  const doc = JSON.parse(ran.stdout);
  assert.equal(doc.refusal.code, "changed_reward");
  assert.equal(doc.nextAction, null);
  const leading = doc.lanes.externalAvailable[0];
  assert.equal(leading.nativeId, "example/widget#7");
  assert.equal(leading.reward.changed, true);
  assert.equal(leading.reward.statedAmount, "25.00");
  assert.equal(leading.reward.known, false);
  assert.equal(leading.reward.status, "claimed_not_verified");
  assert.equal(leading.reward.profit, null);
  assert.equal(leading.selected, false);
  assert.equal(doc.lanes.externalAvailable[1].selected, false);
  assert.equal(doc.costs.profit, null);
  assert.equal(doc.syntheticProfitClaim, false);
  assert.equal(doc.lanes.operatorSponsored[0].fixture.includes("operator-declared-e18.json"), true);
});
