/** Pins and honesty vocabulary for the L09 cold shortlist. */

export const QUESTION = "what is the useful next action?";

export const SHORTLIST_SCHEMA = "neomorphic.l09.cold_shortlist.v1";
export const ANSWER_SCHEMA = "neomorphic.l09.next_action_answer.v1";
export const CACHE_SCHEMA = "neomorphic.l09.refresh_cache.v1";
export const NEXT_GET_SCHEMA = "neomorphic.l09.next_get.v1";
export const REWARD_SCHEMA = "neomorphic.l09.reward_observations.v1";
export const VF15_SCHEMA = "neomorphic.vf15.qualified_next_action.v1";
export const RECORD_SCHEMA = "neomorphic.l09.opportunity_record.v1";
export const BUDGET_SCHEMA = "neomorphic.l09.effort_budget.v1";
export const INVENTORY_SCHEMA = "neomorphic.l09.capability_inventory.v1";
export const TASK_SPEC_SCHEMA = "neomorphic.l09.contributor_task_spec.v1";
export const PUBLIC_ENTRY_SCHEMA = "neomorphic.l09.public_next_action.v1";
export const DECISION_CHECK_SCHEMA = "neomorphic.l09.decision_check.v1";
export const DISCOVERY_SNAPSHOT_SCHEMA = "neomorphic.bounty-discovery.snapshot.v1";

/**
 * Planning ranges, not measurements. Reuse is the lower band and applies only
 * when every required capability is in the supplied inventory.
 * A budget whose maxima sit between the reuse high and the cold low separates
 * the two postures.
 */
export const EFFORT_ASSUMPTIONS = Object.freeze({
  measured: false,
  assumption: "Token and review ranges are planning assumptions for a public read or a capture refresh. They are not measured usage and they are not a price.",
  public_get: Object.freeze({
    cold: Object.freeze({
      inputTokens: Object.freeze({ low: 12000, high: 40000 }),
      outputTokens: Object.freeze({ low: 4000, high: 12000 }),
      reviewMinutes: Object.freeze({ low: 20, high: 90 }),
    }),
    reuse: Object.freeze({
      inputTokens: Object.freeze({ low: 800, high: 3000 }),
      outputTokens: Object.freeze({ low: 400, high: 1500 }),
      reviewMinutes: Object.freeze({ low: 5, high: 20 }),
    }),
  }),
  refresh_capture: Object.freeze({
    cold: Object.freeze({
      inputTokens: Object.freeze({ low: 20000, high: 80000 }),
      outputTokens: Object.freeze({ low: 8000, high: 30000 }),
      reviewMinutes: Object.freeze({ low: 45, high: 180 }),
    }),
    reuse: Object.freeze({
      inputTokens: Object.freeze({ low: 1500, high: 6000 }),
      outputTokens: Object.freeze({ low: 800, high: 2500 }),
      reviewMinutes: Object.freeze({ low: 10, high: 40 }),
    }),
  }),
});

/** Deterministic fixture artifacts. Live observation must not overwrite these. */
export const FIXTURE_OUTPUTS = Object.freeze([
  "published/cold-shortlist.json",
  "published/refresh-cache.json",
]);

export const EXIT = Object.freeze({
  OK: 0,
  REFUSAL: 2,
  USAGE: 3,
  UNAVAILABLE: 4,
});

export const NEO209 = Object.freeze({
  path: "experiments/vf15-actionable-work",
  merge: "b4b63985d1edcf2c9b39cce922034a8c8be48555",
  acceptedHead: "5fa128078f233e8d899ff82c262c0fcbbf253c41",
});

export const ECONOMICS_MODULES = Object.freeze([
  "src/costs.mjs",
  "src/honesty.mjs",
  "src/quantity.mjs",
  "src/wallet.mjs",
]);

export const ECONOMICS_PATH = "experiments/bounty-economics-20260912";
export const EFFORT_WORKFLOW_PATH = "experiments/effort-integration-20260922";

export const CONSUMER = Object.freeze({
  id: "earned-work-requester",
  module: "experiments/codex-window/h36-earned-requester-integration/src/author.mjs",
  acceptsLane: "operatorSponsored",
  refusesLane: "externalAvailable",
});

export const OPERATOR_FIXTURE =
  "experiments/codex-window/h36-earned-requester-integration/fixtures/operator-declared-e18.json";

export const ADAPTERS = Object.freeze(["github-public-issues", "bugzilla-mozilla"]);

export const DEFAULT_TTL_SECONDS = 3600;
export const MAX_TTL_SECONDS = 30 * 86400;
export const MAX_READ_BYTES = 2_000_000;

export const PREREQUISITES = Object.freeze([
  "One unauthenticated HTTPS GET of the public record",
  "Do not authenticate, claim, bid, pay, submit, or comment",
  "Reward is unknown. A stated amount is not a verified price",
  "Delivery cost is unknown and is not zero",
  "An external public record is not an earned-work offer",
  "Operator-sponsored work stays on the earned-work requester and is not an external job",
]);

export const COST_NOTES = Object.freeze([
  "Unknown is not zero.",
  "A stated reward is not a verified price.",
  "Delivery cost stays unknown when effort inputs are unknown.",
  "No profit figure is produced.",
]);
