import { REWARD_SCHEMA } from "./constants.mjs";
import { fail } from "./paths.mjs";
import { findLeak } from "./scrub.mjs";

const BANNED_KEYS = new Set([
  "profit",
  "expectedprofit",
  "syntheticprofit",
  "expected_profit",
  "evwallet",
  "expectedprofitusdc",
]);

function walk(value, seen) {
  if (!value || typeof value !== "object") return;
  if (seen.has(value)) return;
  seen.add(value);
  if (Array.isArray(value)) {
    for (const item of value) walk(item, seen);
    return;
  }
  for (const [key, item] of Object.entries(value)) {
    if (BANNED_KEYS.has(key.toLowerCase())) {
      throw fail("synthetic_profit", "reward input carries a profit claim");
    }
    walk(item, seen);
  }
}

const AMOUNT = /^(0|[1-9]\d*)(\.\d{1,6})?$/;

export function parseReward(value) {
  if (findLeak(value)) throw fail("payment_leak", "reward input carries a payment, claimant, or participant field");
  walk(value, new Set());
  if (!value || value.schema !== REWARD_SCHEMA || !Array.isArray(value.observations)) {
    throw fail("malformed_reward", "reward observations are not the v1 document");
  }
  const out = new Map();
  for (const row of value.observations) {
    if (!row || typeof row !== "object" || Array.isArray(row) || typeof row.nativeId !== "string" || !row.nativeId) {
      throw fail("malformed_reward", "reward observation is missing nativeId");
    }
    if (row.known === true) {
      throw fail("unverified_reward_marked_known", "external reward cannot be marked known");
    }
    if (row.statedAmount != null && (typeof row.statedAmount !== "string" || !AMOUNT.test(row.statedAmount))) {
      throw fail("malformed_reward", "stated reward must be a decimal string or null");
    }
    const asset = row.asset ?? null;
    if (asset != null && asset !== "USDC" && asset !== "USD") {
      throw fail("unsupported_reward_asset", "stated reward asset is unsupported");
    }
    if (out.has(row.nativeId)) throw fail("malformed_reward", "duplicate reward observation");
    out.set(row.nativeId, { statedAmount: row.statedAmount ?? null, asset });
  }
  return out;
}

export function rewardView(nativeId, observations, prior) {
  const obs = observations.get(nativeId) ?? { statedAmount: null, asset: null };
  let changed = false;
  if (prior) {
    const prev = Object.hasOwn(prior, nativeId) ? prior[nativeId] : null;
    const prevAmount = prev && typeof prev === "object" ? (prev.statedAmount ?? null) : null;
    const prevAsset = prev && typeof prev === "object" ? (prev.asset ?? null) : null;
    changed = prevAmount !== obs.statedAmount || prevAsset !== (obs.asset ?? null);
  }
  return {
    known: false,
    statedAmount: obs.statedAmount,
    asset: obs.asset ?? null,
    status: obs.statedAmount == null ? "unknown" : "claimed_not_verified",
    changed,
    profit: null,
  };
}
