import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { ADAPTERS, ANSWER_SCHEMA, CONSUMER, QUESTION, SHORTLIST_SCHEMA } from "./constants.mjs";
import { unknownCosts } from "./economics.mjs";
import { fail, REPO } from "./paths.mjs";
import { findLeak } from "./scrub.mjs";
import { isIsoZ } from "../../vf15-actionable-work/src/text.mjs";

const BANNED = new Set(["profit", "expectedprofit", "syntheticprofit", "expected_profit", "evwallet"]);

function profitClaim(value, seen = new Set()) {
  if (!value || typeof value !== "object") return false;
  if (seen.has(value)) return false;
  seen.add(value);
  if (Array.isArray(value)) return value.some((item) => profitClaim(item, seen));
  for (const [key, item] of Object.entries(value)) {
    const lower = key.toLowerCase();
    if (lower === "profit" && item != null) return true;
    if (lower === "syntheticprofitclaim" && item !== false) return true;
    if ((lower === "syntheticprofit" || BANNED.has(lower)) && item != null && item !== false) return true;
    if (profitClaim(item, seen)) return true;
  }
  return false;
}

function unknownBlock(block) {
  if (!block || block.profit != null || block.syntheticProfitClaim !== false) return false;
  for (const key of ["cash", "listEquivalent", "economic", "netAfterFees"]) {
    if (block[key]?.kind !== "unknown" || block[key]?.value != null) return false;
  }
  return block.netAfterFees.label === "net_wallet_not_profit";
}

function answer(fields) {
  return {
    schema: ANSWER_SCHEMA,
    question: QUESTION,
    deterministic: true,
    readFrom: "published_artifact_only",
    freshnessChecked: fields.freshnessChecked,
    fresh: fields.fresh,
    nextAction: fields.nextAction,
    refusal: fields.refusal,
    lanes: fields.lanes,
    syntheticProfitClaim: false,
    costsUnknown: fields.costsUnknown === true,
    consumer: CONSUMER.id,
  };
}

function laneCounts(doc) {
  return {
    operatorSponsored: doc.lanes?.operatorSponsored?.length ?? 0,
    externalAvailable: doc.lanes?.externalAvailable?.length ?? 0,
  };
}

function stale(doc, now) {
  if (!now) return false;
  if (!isIsoZ(now)) throw fail("usage", "now must be an ISO-8601 UTC timestamp");
  if (typeof doc.freshUntil !== "string") return true;
  return Date.parse(now) > Date.parse(doc.freshUntil);
}

export function readNext(doc, { now } = {}) {
  if (!doc || doc.schema !== SHORTLIST_SCHEMA || doc.question !== QUESTION) {
    throw fail("artifact_unreadable", "artifact is not a cold shortlist");
  }
  const lanes = laneCounts(doc);
  if (findLeak(doc)) {
    return {
      exitCode: 2,
      answer: answer({
        freshnessChecked: Boolean(now),
        fresh: false,
        nextAction: null,
        refusal: { code: "payment_leak", message: "shortlist carries a payment, claimant, or participant field" },
        lanes,
        costsUnknown: false,
      }),
    };
  }
  if (profitClaim(doc)) {
    return {
      exitCode: 2,
      answer: answer({
        freshnessChecked: Boolean(now),
        fresh: false,
        nextAction: null,
        refusal: { code: "synthetic_profit", message: "shortlist carries a profit claim" },
        lanes,
        costsUnknown: false,
      }),
    };
  }
  const freshnessChecked = Boolean(now);
  if (stale(doc, now)) {
    return {
      exitCode: 2,
      answer: answer({
        freshnessChecked,
        fresh: false,
        nextAction: null,
        refusal: { code: "stale_cache", message: "the shortlist is past its fresh-until time" },
        lanes,
        costsUnknown: unknownBlock(doc.costs),
      }),
    };
  }
  if (doc.nextAction) {
    return {
      exitCode: 0,
      answer: answer({
        freshnessChecked,
        fresh: freshnessChecked ? true : null,
        nextAction: doc.nextAction,
        refusal: null,
        lanes,
        costsUnknown: unknownBlock(doc.costs) && unknownBlock(doc.nextAction.costs),
      }),
    };
  }
  return {
    exitCode: doc.refusal?.code === "source_unavailable" ? 4 : 2,
    answer: answer({
      freshnessChecked,
      fresh: freshnessChecked ? true : null,
      nextAction: null,
      refusal: doc.refusal ?? { code: "unqualified", message: "shortlist has no next action" },
      lanes,
      costsUnknown: doc.costs == null ? false : unknownBlock(doc.costs),
    }),
  };
}

function bad(message) {
  throw fail("artifact_inconsistent", message);
}

function assertCostsMatch(block, recomputed) {
  if (!unknownBlock(block)) bad("shortlist costs are not unknown");
  for (const key of ["cash", "listEquivalent", "economic"]) {
    if (block[key].kind !== recomputed[key].kind || block[key].value !== recomputed[key].value) {
      bad("shortlist costs do not match a fresh unknown-cost read");
    }
  }
}

export function verifyArtifact(doc, { now } = {}) {
  const cold = readNext(doc, { now });
  if (
    cold.answer.refusal?.code === "synthetic_profit" ||
    cold.answer.refusal?.code === "stale_cache" ||
    cold.answer.refusal?.code === "payment_leak"
  ) {
    return cold;
  }
  try {
    checkShortlist(doc);
  } catch (err) {
    if (err.code !== "artifact_inconsistent") throw err;
    return {
      exitCode: 2,
      answer: answer({
        freshnessChecked: Boolean(now),
        fresh: false,
        nextAction: null,
        refusal: { code: "artifact_inconsistent", message: err.message },
        lanes: laneCounts(doc),
        costsUnknown: false,
      }),
    };
  }
  return cold;
}

function checkShortlist(doc) {
  if (doc.claimAuthority !== "none" || doc.paymentAuthority !== "none") bad("authority is not none");
  if (doc.syntheticProfitClaim !== false) bad("synthetic profit flag is set");
  if (doc.limits?.safeToStartWork !== false || doc.limits?.offer !== false) bad("limits allow an offer");
  if (doc.consumer?.id !== CONSUMER.id || doc.consumer?.module !== CONSUMER.module) bad("consumer is not the earned-work requester");
  if (doc.consumer.acceptsLane !== "operatorSponsored" || doc.consumer.refusesLane !== "externalAvailable") {
    bad("consumer lanes are reversed");
  }
  if (!existsSync(resolve(REPO, CONSUMER.module))) bad("earned-work requester module is missing");
  if (doc.received?.neo209 === true) {
    const ids = (doc.sources ?? []).map((source) => source.adapterId);
    if (ids.join() !== ADAPTERS.join()) bad("shortlist did not record both permitted sources");
    const recomputed = unknownCosts();
    assertCostsMatch(doc.costs, recomputed);
    for (const row of doc.lanes.externalAvailable) {
      if (row.lane !== "externalAvailable" || row.sponsoredByOperator !== false || row.availableAsExternalJob !== true) {
        bad("external row is labelled as operator-sponsored");
      }
      if (row.reward?.known !== false || row.reward?.profit != null) bad("external reward is marked known");
      assertCostsMatch(row.costs, recomputed);
    }
    for (const row of doc.lanes.operatorSponsored) {
      if (row.lane !== "operatorSponsored" || row.sponsoredByOperator !== true || row.availableAsExternalJob !== false) {
        bad("operator row is labelled as an external job");
      }
      if (row.action?.url || row.action?.method) bad("operator row carries a public GET");
      if (row.reward?.status !== "disclosed_hypothesis" || row.reward?.profit != null) {
        bad("operator reward is not a disclosed hypothesis");
      }
      if (findLeak(row) || Object.hasOwn(row, "paid")) {
        bad("operator row carries a payment or claimant field");
      }
      if (row.customerRevenue !== false) bad("operator work is labelled as customer revenue");
    }
    const operatorFixtures = new Set(doc.lanes.operatorSponsored.map((row) => row.fixture));
    for (const row of doc.lanes.externalAvailable) {
      if (operatorFixtures.has(row.url)) bad("external url is an operator fixture");
    }
    if (doc.shortlistEvidence) {
      const evidence = doc.shortlistEvidence;
      if (evidence.rewardUnknown !== true) bad("shortlist evidence does not keep reward unknown");
      if (evidence.observedAt !== doc.generatedAt) bad("shortlist evidence timestamp drifted");
      if (!evidence.source || evidence.source.adapterId !== doc.nextAction?.adapterId || evidence.source.sourceId !== doc.nextAction?.sourceId) {
        bad("shortlist evidence source drifted");
      }
      if (evidence.status !== doc.nextAction?.state) bad("shortlist evidence status drifted");
      for (const key of ["cash", "listEquivalent", "economic", "netAfterFees"]) {
        if (evidence.costs?.[key] != null) bad("shortlist evidence cost is not null");
      }
      if (evidence.costs?.profit != null) bad("shortlist evidence carries profit");
    }
    if (doc.nextAction) {
      const selected = doc.lanes.externalAvailable.filter((row) => row.selected);
      if (selected.length !== 1 || selected[0].url !== doc.nextAction.url || selected[0].nativeId !== doc.nextAction.nativeId) {
        bad("next action does not match the selected external row");
      }
      if (doc.nextAction.lane !== "externalAvailable" || doc.nextAction.method !== "GET") {
        bad("next action is not an external GET");
      }
      if (doc.nextAction.reward?.known !== false || doc.nextAction.reward?.profit != null) bad("next action reward is marked known");
      assertCostsMatch(doc.nextAction.costs, recomputed);
    }
  }
}
