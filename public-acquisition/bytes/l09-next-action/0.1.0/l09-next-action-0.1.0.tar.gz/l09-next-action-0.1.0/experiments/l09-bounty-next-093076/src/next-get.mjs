/**
 * Records the deterministic fixture GET and the live-qualified GET together.
 * The two artifacts stay in separate files.
 */
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { CONSUMER, NEXT_GET_SCHEMA, QUESTION } from "./constants.mjs";
import { fail, REPO } from "./paths.mjs";
import { findLeak } from "./scrub.mjs";

const SHA = /^sha256:[a-f0-9]{64}$/;

function costValues(costs) {
  return {
    cash: costs?.cash?.value ?? null,
    listEquivalent: costs?.listEquivalent?.value ?? null,
    economic: costs?.economic?.value ?? null,
    netAfterFees: costs?.netAfterFees?.value ?? null,
    profit: null,
  };
}

function rewardUnknown(action, costs) {
  const reward = action?.reward;
  return Boolean(
    action &&
    reward?.known === false &&
    reward?.profit == null &&
    reward?.statedAmount == null &&
    costs?.profit == null &&
    costs?.cash?.value == null &&
    costs?.listEquivalent?.value == null &&
    costs?.economic?.value == null &&
    costs?.netAfterFees?.value == null
  );
}

function selectedSource(doc) {
  const action = doc?.nextAction;
  if (!action) throw fail("artifact_inconsistent", "shortlist has no next action");
  const source = (doc.sources ?? []).find((row) => row.adapterId === action.adapterId);
  if (!source) throw fail("artifact_inconsistent", "next action source is missing");
  return source;
}

function entry(doc, role, artifact) {
  const action = doc.nextAction;
  const source = selectedSource(doc);
  return {
    role,
    artifact,
    source: {
      adapterId: action.adapterId,
      sourceId: action.sourceId,
    },
    observedAt: doc.generatedAt,
    status: action.state,
    method: action.method,
    url: action.url,
    nativeId: action.nativeId,
    rewardUnknown: rewardUnknown(action, doc.costs),
    reward: {
      known: false,
      statedAmount: action.reward?.statedAmount ?? null,
      asset: action.reward?.asset ?? null,
      status: action.reward?.status ?? null,
      profit: null,
    },
    costs: costValues(doc.costs),
    qualification: {
      qualified: source.qualified === true,
      evidenceClass: source.evidenceClass,
      httpStatus: source.httpStatus,
      bodySha256: source.bodySha256,
      network: doc.observation?.network === true,
      observationMode: doc.observation?.mode ?? null,
    },
  };
}

export function buildNextGet({ fixture, live, fixtureArtifact, liveArtifact, actionGet }) {
  if (!fixture || fixture.observation?.mode !== "fixture" || fixture.observation?.network !== false) {
    throw fail("artifact_inconsistent", "fixture shortlist is not a deterministic fixture observation");
  }
  if (!live || live.observation?.mode !== "live" || live.observation?.network !== true) {
    throw fail("artifact_inconsistent", "live shortlist is not a live observation");
  }
  if (fixture.consumer?.id !== CONSUMER.id || live.consumer?.id !== CONSUMER.id) {
    throw fail("artifact_inconsistent", "shortlist consumer is not the earned-work requester");
  }
  const fixtureEntry = entry(fixture, "deterministic_fixture", fixtureArtifact);
  const liveEntry = entry(live, "live_qualified", liveArtifact);
  if (fixtureEntry.qualification.evidenceClass !== "fixture" || fixtureEntry.qualification.network !== false) {
    throw fail("artifact_inconsistent", "fixture qualification is not fixture evidence");
  }
  if (liveEntry.qualification.evidenceClass !== "live_public_get" || liveEntry.qualification.network !== true) {
    throw fail("artifact_inconsistent", "live qualification is not a live public GET");
  }
  if (!actionGet || actionGet.method !== "GET" || actionGet.url !== liveEntry.url) {
    throw fail("artifact_inconsistent", "live action GET does not match the qualified url");
  }
  liveEntry.actionGet = {
    method: "GET",
    url: actionGet.url,
    httpStatus: actionGet.httpStatus,
    observedAt: actionGet.observedAt,
    error: actionGet.error ?? null,
    bodyStored: false,
    authenticated: false,
    bodyChars: actionGet.bodyChars ?? null,
  };
  const doc = {
    schema: NEXT_GET_SCHEMA,
    question: QUESTION,
    recordedAt: live.generatedAt,
    consumer: {
      id: CONSUMER.id,
      module: CONSUMER.module,
      acceptsLane: CONSUMER.acceptsLane,
      refusesLane: CONSUMER.refusesLane,
      handed: true,
      offerAuthored: false,
      externalIsNotAnOffer: true,
    },
    fixture: fixtureEntry,
    live: liveEntry,
    artifactsDiffer: fixtureArtifact !== liveArtifact,
  };
  if (findLeak(doc)) throw fail("payment_leak", "next get carries a payment, claimant, or participant field");
  return doc;
}

function bad(code, message) {
  throw fail(code, message);
}

function assertNullCosts(block, label) {
  if (!block || block.profit != null) bad("artifact_inconsistent", `${label} cost is not unknown`);
  for (const key of ["cash", "listEquivalent", "economic", "netAfterFees"]) {
    if (block[key] != null) bad("artifact_inconsistent", `${label} cost is not null`);
  }
}

function assertEntry(recordEntry, doc, role, evidenceClass, network) {
  if (recordEntry?.role !== role) bad("artifact_inconsistent", `${role} record is missing`);
  if (recordEntry.method !== "GET") bad("artifact_inconsistent", `${role} method is not GET`);
  if (recordEntry.rewardUnknown !== true) bad("artifact_inconsistent", `${role} reward is not unknown`);
  if (recordEntry.reward?.known !== false || recordEntry.reward?.profit != null || recordEntry.reward?.statedAmount != null) {
    bad("artifact_inconsistent", `${role} reward is not unknown`);
  }
  assertNullCosts(recordEntry.costs, role);
  const source = selectedSource(doc);
  if (recordEntry.url !== doc.nextAction.url || recordEntry.nativeId !== doc.nextAction.nativeId) {
    bad("artifact_inconsistent", `${role} url does not match its shortlist`);
  }
  if (recordEntry.observedAt !== doc.generatedAt) bad("artifact_inconsistent", `${role} timestamp does not match its shortlist`);
  if (recordEntry.status !== doc.nextAction.state) bad("artifact_inconsistent", `${role} status does not match its shortlist`);
  if (recordEntry.source?.adapterId !== doc.nextAction.adapterId || recordEntry.source?.sourceId !== doc.nextAction.sourceId) {
    bad("artifact_inconsistent", `${role} source does not match its shortlist`);
  }
  const qualification = recordEntry.qualification;
  if (qualification?.qualified !== true || qualification.evidenceClass !== evidenceClass || qualification.network !== network) {
    bad("artifact_inconsistent", `${role} qualification evidence does not match`);
  }
  if (!Number.isInteger(qualification.httpStatus) || qualification.httpStatus < 200 || qualification.httpStatus >= 300) {
    bad("artifact_inconsistent", `${role} qualification status is not a public 2xx`);
  }
  if (qualification.httpStatus !== source.httpStatus || qualification.bodySha256 !== source.bodySha256) {
    bad("artifact_inconsistent", `${role} qualification does not match the shortlist source`);
  }
  if (!SHA.test(qualification.bodySha256)) bad("artifact_inconsistent", `${role} body hash is not a sha256`);
  if (qualification.observationMode !== doc.observation?.mode) {
    bad("artifact_inconsistent", `${role} observation mode drifted`);
  }
}

export function checkNextGet(record, { fixture, live }) {
  if (!record || record.schema !== NEXT_GET_SCHEMA || record.question !== QUESTION) {
    bad("artifact_unreadable", "artifact is not a next get record");
  }
  if (findLeak(record) || findLeak(fixture) || findLeak(live)) {
    bad("payment_leak", "next get carries a payment, claimant, or participant field");
  }
  if (record.consumer?.id !== CONSUMER.id || record.consumer?.module !== CONSUMER.module) {
    bad("artifact_inconsistent", "consumer is not the earned-work requester");
  }
  if (record.consumer.handed !== true || record.consumer.offerAuthored !== false) {
    bad("artifact_inconsistent", "next get was not handed to the earned-work requester");
  }
  if (record.consumer.acceptsLane !== CONSUMER.acceptsLane || record.consumer.refusesLane !== CONSUMER.refusesLane) {
    bad("artifact_inconsistent", "consumer lanes are reversed");
  }
  if (!existsSync(resolve(REPO, CONSUMER.module))) bad("artifact_inconsistent", "earned-work requester module is missing");
  if (record.artifactsDiffer !== true || record.fixture?.artifact === record.live?.artifact) {
    bad("artifact_inconsistent", "fixture and live artifacts are not separate");
  }
  if (fixture?.schema == null || live?.schema == null) bad("artifact_inconsistent", "next get shortlists are missing");
  assertEntry(record.fixture, fixture, "deterministic_fixture", "fixture", false);
  assertEntry(record.live, live, "live_qualified", "live_public_get", true);
  if (live.shortlistEvidence?.rewardUnknown !== true) bad("artifact_inconsistent", "live shortlist evidence does not keep reward unknown");
  if (live.shortlistEvidence?.observedAt !== live.generatedAt) bad("artifact_inconsistent", "live shortlist evidence timestamp drifted");
  if (live.shortlistEvidence?.status !== live.nextAction?.state) bad("artifact_inconsistent", "live shortlist evidence status drifted");
  if (live.shortlistEvidence?.source?.adapterId !== live.nextAction?.adapterId) {
    bad("artifact_inconsistent", "live shortlist evidence source drifted");
  }
  const actionGet = record.live.actionGet;
  if (!actionGet || actionGet.method !== "GET" || actionGet.url !== record.live.url) {
    bad("artifact_inconsistent", "live action GET does not match the qualified url");
  }
  if (actionGet.bodyStored !== false || actionGet.authenticated !== false || actionGet.error != null) {
    bad("artifact_inconsistent", "live action GET stored a body or did not complete");
  }
  if (!Number.isInteger(actionGet.httpStatus) || actionGet.httpStatus < 200 || actionGet.httpStatus >= 300) {
    bad("artifact_inconsistent", "live action GET status is not a public 2xx");
  }
  if (!Number.isInteger(actionGet.bodyChars) || actionGet.bodyChars < 1) {
    bad("artifact_inconsistent", "live action GET did not read a public body");
  }
  if (actionGet.observedAt !== record.recordedAt) bad("artifact_inconsistent", "live action GET timestamp drifted");
  if (live.shortlistEvidence?.source?.sourceId !== live.nextAction?.sourceId) {
    bad("artifact_inconsistent", "live shortlist evidence source drifted");
  }
  return {
    schema: "neomorphic.l09.next_get_check.v1",
    ok: true,
    fixtureUrl: record.fixture.url,
    liveUrl: record.live.url,
    liveSource: record.live.source,
    liveObservedAt: record.live.observedAt,
    liveStatus: record.live.status,
    qualificationStatus: record.live.qualification.httpStatus,
    actionGetStatus: actionGet.httpStatus,
    rewardUnknown: true,
    consumer: CONSUMER.id,
    offerAuthored: false,
  };
}
