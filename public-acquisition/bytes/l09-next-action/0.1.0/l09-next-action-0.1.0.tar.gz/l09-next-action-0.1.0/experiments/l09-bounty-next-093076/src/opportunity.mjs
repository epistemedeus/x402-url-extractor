import { DISCOVERY_SNAPSHOT_SCHEMA, EFFORT_ASSUMPTIONS, SHORTLIST_SCHEMA } from "./constants.mjs";
import { allowanceView, budgetFit, effortFor, postureFor } from "./budget.mjs";
import { fail } from "./paths.mjs";
import { scrubTitle } from "./scrub.mjs";

const ACTION_RANK = Object.freeze({
  public_get: 0,
  refresh_capture: 1,
  skip_over_budget: 2,
  do_not_start_work: 3,
  record_negative: 4,
  source_unavailable: 5,
});

function staleAt(observedAt, staleAfterSeconds, now) {
  const observed = Date.parse(observedAt);
  const clock = Date.parse(now);
  const windowMs = Number(staleAfterSeconds) * 1000;
  if (!Number.isFinite(observed) || !Number.isFinite(clock) || !Number.isFinite(windowMs)) return true;
  return clock - observed > windowMs;
}

function openness(row) {
  if (row.taskClass === "closed" || row.observedState === "closed") return "closed";
  if (row.observedState === "open") return "open";
  if (row.taskClass === "unknown") return "unknown";
  return "unknown";
}

function rewardFromAdvertised(ad) {
  if (ad && (ad.profitable === true || ad.verifiedEv != null)) {
    throw fail("synthetic_profit", "advertised reward carried a profit or verified EV");
  }
  if (ad && ad.verified === true && ad.kind !== "verified_receipt") {
    throw fail("unverified_reward_marked_known", "a source statement is not a verified reward");
  }
  if (ad && ad.kind === "verified_receipt" && ad.verified === true && ad.amount != null && ad.currency) {
    return {
      amount: String(ad.amount),
      asset: String(ad.currency),
      verified: true,
      verification: "verified_receipt",
    };
  }
  const stated = ad && ad.amount != null && ad.amount !== "" && ad.currency;
  return {
    amount: stated ? String(ad.amount) : null,
    asset: stated ? String(ad.currency) : null,
    verified: false,
    verification: stated ? "source_statement_unverified" : "unknown",
  };
}

/**
 * Paid revenue is a verified receipt only. An unknown reward, an unverified
 * statement, and a volunteer-issue GET are not revenue proof and do not rank
 * as a profitable opportunity.
 */
export function classifyOpportunity(row) {
  const blob = `${row.sourceUrl || ""} ${row.identity || ""} ${row.title || ""}`.toLowerCase();
  const reward = row.reward || {};
  const verifiedReceipt = reward.verified === true
    && reward.verification === "verified_receipt"
    && reward.amount != null;
  if (blob.includes("volunteer")) {
    return { opportunityClass: "information", revenueProof: false, ranksAsProfitable: false };
  }
  if (verifiedReceipt) {
    return { opportunityClass: "paid_revenue", revenueProof: true, ranksAsProfitable: false };
  }
  if (reward.amount == null || reward.verification === "unknown") {
    return { opportunityClass: "unrewarded_contribution", revenueProof: false, ranksAsProfitable: false };
  }
  return { opportunityClass: "unverified_statement", revenueProof: false, ranksAsProfitable: false };
}

function baseAction(status, stale, nextStep, taskClass) {
  if (status === "closed" || taskClass === "closed") return "record_negative";
  if (nextStep === "do_not_start_work" || taskClass === "human_only" || taskClass === "expired_open") {
    return "do_not_start_work";
  }
  if (stale && status !== "closed") return "refresh_capture";
  if (status === "open" && (nextStep === "observe_only" || taskClass === "observe_open" || taskClass === "promised_open" || taskClass === "public_issue")) {
    return "public_get";
  }
  return "do_not_start_work";
}

export function annotateOpportunity(row, budget, inventory, economics) {
  const posture = postureFor(row.requiredCapabilities, inventory);
  const kind = row.baseAction === "refresh_capture" ? "refresh_capture" : "public_get";
  const selectedEffort = effortFor(kind, posture);
  const fit = budgetFit(selectedEffort, budget);
  let nextSupportedAction = row.baseAction;
  if ((nextSupportedAction === "public_get" || nextSupportedAction === "refresh_capture") && fit.fits !== "inside") {
    nextSupportedAction = "skip_over_budget";
  }
  const coldEffort = effortFor(kind, "cold_build");
  const reuseEffort = effortFor(kind, "reused_integration");
  const coldFit = budgetFit(coldEffort, budget);
  const reuseFit = budgetFit(reuseEffort, budget);
  const coldAction = gated(row.baseAction, coldFit.fits);
  const reuseAction = gated(row.baseAction, reuseFit.fits);
  const label = row.reward.verified === true ? "verified_reward_costs_unknown" : "unverified_reward_not_an_ev";
  const classification = classifyOpportunity(row);
  return {
    identity: row.identity,
    sourceContract: row.sourceContract,
    sourceId: row.sourceId,
    sourceUrl: row.sourceUrl,
    observedAt: row.observedAt,
    status: row.status,
    stale: row.stale,
    title: row.title,
    reward: {
      amount: row.reward.amount,
      asset: row.reward.asset,
      verified: row.reward.verified === true,
      verification: row.reward.verification,
    },
    eligibility: row.eligibility,
    requiredAuthorization: row.requiredAuthorization,
    objectiveDeliverable: row.objectiveDeliverable,
    acceptancePath: row.acceptancePath,
    requiredCapabilities: row.requiredCapabilities,
    effort: {
      measured: false,
      assumption: EFFORT_ASSUMPTIONS.assumption,
      selectedPosture: posture,
      selected: { ...selectedEffort, fits: fit.fits, parts: fit.parts },
      cold: { ...coldEffort, fits: coldFit.fits },
      reuse: { ...reuseEffort, fits: reuseFit.fits },
    },
    fees: economics.fees,
    breakEven: economics.breakEvenGross,
    sensitivity: {
      kind: "budget_reuse",
      verifiedEv: null,
      profitable: null,
      measured: false,
      assumption: EFFORT_ASSUMPTIONS.assumption,
      cases: [
        { name: "cold_build", fits: coldFit.fits, nextSupportedAction: coldAction, inputTokens: coldEffort.inputTokens },
        { name: "reused_integration", fits: reuseFit.fits, nextSupportedAction: reuseAction, inputTokens: reuseEffort.inputTokens },
      ],
    },
    nextSupportedAction,
    verifiedEv: null,
    profitable: null,
    opportunityClass: classification.opportunityClass,
    revenueProof: classification.revenueProof,
    ranksAsProfitable: false,
    label,
    selectedByShortlist: row.selectedByShortlist === true,
  };
}

function gated(action, fits) {
  if ((action === "public_get" || action === "refresh_capture") && fits !== "inside") return "skip_over_budget";
  return action;
}

function discoveryRow(row, now, staleAfterSeconds) {
  const reward = rewardFromAdvertised(row.rewardAdvertised);
  const status = openness(row);
  const stale = staleAt(row.observedAt, row.staleAfterSeconds ?? staleAfterSeconds, now);
  let action = baseAction(status, stale, row.nextStep, row.taskClass);
  if (action === "public_get" && typeof row.sourceUrl !== "string") action = "do_not_start_work";
  const gates = Array.isArray(row.agentEligibility?.humanGates) ? row.agentEligibility.humanGates.map(String) : [];
  return {
    identity: String(row.identity),
    sourceContract: String(row.sourceId),
    sourceId: String(row.sourceId),
    sourceUrl: typeof row.sourceUrl === "string" ? row.sourceUrl : null,
    observedAt: row.observedAt ?? null,
    status,
    stale,
    title: scrubTitle(row.title || ""),
    reward,
    eligibility: {
      agentAccess: row.agentEligibility?.agentAccess || "unknown",
      humanGates: gates,
      kind: "source_statement",
    },
    requiredAuthorization: gates.length
      ? `Human gate on the source statement (${gates.join(", ")}). claim authorization remains none.`
      : "No claim authorization is granted. An unauthenticated public read is the only supported step.",
    objectiveDeliverable: `${row.taskClass || "unknown"}: ${scrubTitle(row.title || "untitled")}`,
    acceptancePath: `Source next step is ${row.nextStep || "unknown"}. Conditions: ${(row.claimAcceptance?.conditions || []).join(", ") || "none stated"}. A public listing is not acceptance and is not a claim.`,
    requiredCapabilities: [`tool:bounty-discovery-query`, `source:${row.sourceId}`],
    baseAction: action,
    selectedByShortlist: false,
  };
}

export function representativesFromSnapshot(snapshot, now) {
  if (!snapshot || snapshot.schema !== DISCOVERY_SNAPSHOT_SCHEMA) {
    throw fail("artifact_unreadable", "discovery snapshot schema mismatch");
  }
  const staleAfter = snapshot.staleAfterSeconds;
  const opportunities = Array.isArray(snapshot.opportunities) ? snapshot.opportunities : [];
  const bySource = new Map();
  let closed = null;
  const sorted = [...opportunities].sort((a, b) => String(a.identity).localeCompare(String(b.identity)));
  for (const row of sorted) {
    if (row?.profitable === true) throw fail("synthetic_profit", "snapshot row carried a profit label");
    if (!closed && (row.taskClass === "closed" || row.observedState === "closed")) closed = row;
    const current = bySource.get(row.sourceId);
    if (!current || (row.usefulChoice === true && current.usefulChoice !== true)) bySource.set(row.sourceId, row);
  }
  const chosen = [...bySource.values()].sort((a, b) => String(a.identity).localeCompare(String(b.identity)));
  if (closed && !chosen.some((row) => row.identity === closed.identity)) chosen.push(closed);
  const rows = chosen.map((row) => discoveryRow(row, now, staleAfter));
  const negatives = [];
  for (const source of snapshot.sources || []) {
    if (source.supported === false || source.outcome === "error") {
      negatives.push({
        id: `unavailable:${source.sourceId}`,
        kind: "source_unavailable",
        sourceContract: source.sourceId,
        sourceId: source.sourceId,
        observedAt: snapshot.capturedAt ?? null,
        status: "unknown",
        reason: source.reason || source.outcome || "unavailable",
        supported: false,
        nextSupportedAction: "source_unavailable",
      });
    } else if (source.outcome === "empty" || source.listingCount === 0) {
      negatives.push({
        id: `empty:${source.sourceId}`,
        kind: "empty_source",
        sourceContract: source.sourceId,
        sourceId: source.sourceId,
        observedAt: snapshot.capturedAt ?? null,
        status: "unknown",
        reason: source.reason || "empty",
        supported: source.supported !== false,
        nextSupportedAction: "source_unavailable",
      });
    } else if (staleAt(snapshot.capturedAt, staleAfter, now)) {
      negatives.push({
        id: `stale:${source.sourceId}`,
        kind: "stale_capture",
        sourceContract: source.sourceId,
        sourceId: source.sourceId,
        observedAt: snapshot.capturedAt ?? null,
        status: "unknown",
        reason: "capture is older than its stale window at the decision clock",
        supported: true,
        nextSupportedAction: "refresh_capture",
      });
    }
  }
  const closedCount = opportunities.filter((row) => row.taskClass === "closed" || row.observedState === "closed").length;
  if (closedCount) {
    negatives.push({
      id: "closed:count",
      kind: "closed_listings",
      sourceContract: "bounty-discovery",
      observedAt: snapshot.capturedAt ?? null,
      status: "closed",
      count: closedCount,
      reason: "closed listings are negative evidence and are not started",
      nextSupportedAction: "record_negative",
    });
  }
  const sources = (snapshot.sources || []).map((source) => ({
    sourceContract: source.sourceId,
    sourceId: source.sourceId,
    sourceName: source.sourceName,
    supported: source.supported !== false,
    outcome: source.outcome || "unknown",
    httpStatus: source.httpStatus ?? null,
    listingCount: source.listingCount ?? 0,
    maintained: true,
  }));
  return {
    rows,
    negatives,
    sources,
    considered: {
      opportunityCount: opportunities.length,
      representativeCount: rows.length,
      rule: "one representative per source that returned a listing, plus one closed row when the capture has one. This is not every listing.",
      maxPages: snapshot.maxPages ?? null,
      pagination: snapshot.limits?.pagination ?? null,
    },
    capturedAt: snapshot.capturedAt ?? null,
  };
}

export function rowsFromShortlist(shortlist, now) {
  if (!shortlist) return { rows: [], sources: [], negatives: [] };
  if (shortlist.schema !== SHORTLIST_SCHEMA) throw fail("artifact_unreadable", "shortlist schema mismatch");
  if (shortlist.syntheticProfitClaim === true) throw fail("synthetic_profit", "shortlist carries a profit claim");
  const clock = Date.parse(now);
  const until = Date.parse(shortlist.freshUntil);
  const stale = !Number.isFinite(until) || !Number.isFinite(clock) || clock > until;
  const rows = [];
  for (const row of shortlist.lanes?.externalAvailable ?? []) {
    if (row.reward?.known === true || row.reward?.profit != null) {
      throw fail("unverified_reward_marked_known", "shortlist reward is marked known or profitable");
    }
    const status = row.state === "open" || row.state === "closed" ? row.state : "unknown";
    rows.push({
      identity: `${row.adapterId}::${row.nativeId}`,
      sourceContract: row.adapterId,
      sourceId: row.sourceId,
      sourceUrl: row.url,
      observedAt: shortlist.generatedAt,
      status,
      stale,
      title: scrubTitle(row.title || ""),
      reward: {
        amount: row.reward?.statedAmount ?? null,
        asset: row.reward?.asset ?? null,
        verified: false,
        verification: "unknown",
      },
      eligibility: { agentAccess: "unknown", humanGates: [], kind: "not_stated_by_adapter" },
      requiredAuthorization: "Unauthenticated public GET. Claim authorization is none. This issue is not an earned-work offer.",
      objectiveDeliverable: `Read the public ${row.adapterId} record.`,
      acceptancePath: "No acceptance path is published on this row. A public issue is not acceptance and is not a payout.",
      requiredCapabilities: [`adapter:${row.adapterId}`],
      baseAction: baseAction(status, stale, status === "closed" ? "do_not_start_work" : "observe_only", "public_issue"),
      selectedByShortlist: row.selected === true,
    });
  }
  const sources = (shortlist.sources ?? []).map((source) => ({
    sourceContract: source.adapterId,
    sourceId: source.sourceId,
    supported: true,
    outcome: source.qualified ? "qualified" : "refused",
    httpStatus: source.httpStatus ?? null,
    qualified: source.qualified === true,
    refusal: source.refusal?.code ?? null,
    maintained: true,
  }));
  const negatives = [];
  for (const source of shortlist.sources ?? []) {
    if (source.qualified === false) {
      negatives.push({
        id: `shortlist:${source.adapterId}`,
        kind: "source_unavailable",
        sourceContract: source.adapterId,
        sourceId: source.sourceId,
        observedAt: shortlist.generatedAt,
        status: "unknown",
        reason: source.refusal?.code || "unqualified",
        supported: true,
        nextSupportedAction: "source_unavailable",
      });
    }
  }
  return { rows, sources, negatives };
}

export function chooseAction(opportunities, now) {
  const ranked = [...opportunities].sort((a, b) => {
    const rank = (ACTION_RANK[a.nextSupportedAction] ?? 9) - (ACTION_RANK[b.nextSupportedAction] ?? 9);
    if (rank !== 0) return rank;
    if (a.selectedByShortlist !== b.selectedByShortlist) return a.selectedByShortlist ? -1 : 1;
    return a.identity < b.identity ? -1 : a.identity > b.identity ? 1 : 0;
  });
  const best = ranked.find((row) => row.nextSupportedAction === "public_get" || row.nextSupportedAction === "refresh_capture");
  if (!best) {
    return {
      outcome: "negative_shortlist",
      nextAction: null,
      profitable: null,
      verifiedEv: null,
      opportunityClass: null,
      revenueProof: false,
      ranksAsProfitable: false,
      reason: "No supported public read fits the supplied budget. Closed, unavailable, and over-budget rows stay negative evidence.",
    };
  }
  const classFields = {
    opportunityClass: best.opportunityClass,
    revenueProof: best.revenueProof === true && best.opportunityClass === "paid_revenue",
    ranksAsProfitable: false,
  };
  if (best.nextSupportedAction === "refresh_capture") {
    return {
      outcome: "supported_action",
      profitable: null,
      verifiedEv: null,
      ...classFields,
      nextAction: {
        kind: "refresh_capture",
        method: "GET",
        url: null,
        identity: best.identity,
        sourceContract: best.sourceContract,
        authenticated: false,
        command: `node packs/bounty-discovery/bin/query.mjs query --mode live --now ${now} --max-pages 1`,
        reason: "The maintained capture is stale at the decision clock, or the qualified row is past its fresh-until time. Refresh with the existing query. Do not claim.",
        observedAt: best.observedAt,
        decisionClock: now,
        ...classFields,
      },
    };
  }
  return {
    outcome: "supported_action",
    profitable: null,
    verifiedEv: null,
    ...classFields,
    nextAction: {
      kind: "public_get",
      method: "GET",
      url: best.sourceUrl,
      identity: best.identity,
      sourceContract: best.sourceContract,
      authenticated: false,
      command: null,
      reason: classFields.opportunityClass === "information"
        ? "This public GET is information. It is not revenue proof and it is not a profitable opportunity."
        : classFields.opportunityClass === "unrewarded_contribution"
          ? "Useful contribution with no verified reward. Unknown reward is not a profitable opportunity."
          : "Open public record inside the selected posture budget. Reward is not a verified EV.",
      observedAt: best.observedAt,
      decisionClock: now,
      ...classFields,
    },
  };
}

export function actionRank(action) {
  return ACTION_RANK[action] ?? 9;
}
