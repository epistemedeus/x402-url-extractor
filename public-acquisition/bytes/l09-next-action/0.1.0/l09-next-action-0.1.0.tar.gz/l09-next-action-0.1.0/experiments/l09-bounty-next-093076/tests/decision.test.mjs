import assert from "node:assert/strict";
import { readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import test from "node:test";
import { hashTermsVersion } from "../../../packs/funded-task-terms/src/hash.mjs";
import { decide, publicMachineEntry, verifyDecision } from "../src/decision.mjs";
import { contributorTaskSpec } from "../src/taskspec.mjs";
import { PACK, REPO, run, workDir } from "./helpers.mjs";

const NOW = "2026-10-01T12:00:00.000Z";
const budget = JSON.parse(readFileSync(join(PACK, "fixtures/decision/budget.json"), "utf8"));
const reuse = JSON.parse(readFileSync(join(PACK, "fixtures/decision/inventory-reuse.json"), "utf8"));
const empty = JSON.parse(readFileSync(join(PACK, "fixtures/decision/inventory-empty.json"), "utf8"));
const snapshot = JSON.parse(readFileSync(join(PACK, "fixtures/decision/snapshot.json"), "utf8"));

function runDecide(inventory, extra = {}) {
  return decide({ now: NOW, budget, inventory, snapshot, ...extra });
}

test("the same open listing fits a reused integration and misses a cold build", () => {
  const reused = runDecide(reuse).record;
  const cold = runDecide(empty).record;
  const openReuse = reused.opportunities.find((row) => row.identity === "superteam-earn::open-1");
  const openCold = cold.opportunities.find((row) => row.identity === "superteam-earn::open-1");
  assert.equal(openReuse.nextSupportedAction, "public_get");
  assert.equal(openReuse.effort.selectedPosture, "reused_integration");
  assert.equal(openCold.nextSupportedAction, "skip_over_budget");
  assert.equal(openCold.effort.selectedPosture, "cold_build");
  assert.equal(openReuse.reward.amount, "500");
  assert.equal(openReuse.reward.asset, "USDC");
  assert.equal(openReuse.reward.verified, false);
  assert.equal(openReuse.verifiedEv, null);
  assert.equal(openReuse.profitable, null);
  assert.equal(openReuse.label, "unverified_reward_not_an_ev");
  assert.equal(openReuse.opportunityClass, "unverified_statement");
  assert.equal(openReuse.revenueProof, false);
  assert.equal(openReuse.ranksAsProfitable, false);
  assert.equal(reused.decision.ranksAsProfitable, false);
  const closedReward = reused.opportunities.find((row) => row.identity === "taskmarket::closed-1");
  assert.equal(closedReward.reward.amount, null);
  assert.equal(closedReward.opportunityClass, "unrewarded_contribution");
  assert.notEqual(closedReward.opportunityClass, "paid_revenue");
  assert.equal(openReuse.sensitivity.cases[0].nextSupportedAction, "skip_over_budget");
  assert.equal(openReuse.sensitivity.cases[1].nextSupportedAction, "public_get");
  assert.equal(reused.allowance.cash.value, null);
  assert.equal(reused.allowance.listEquivalent.value, null);
  assert.equal(reused.allowance.subscriptionAllowance.cashSpent, false);
  assert.equal(reused.allowance.subscriptionAllowance.listPriceApplied, false);
  assert.equal(reused.allowance.subscriptionAllowance.inputTokens, 100000);
  assert.equal(reused.economics.breakEven.value, null);
  assert.equal(reused.economics.sensitivityModule.expectedNet, null);
  assert.equal(reused.economics.verifiedEv, null);
  assert.equal(reused.effort.contributor.measured, false);
  assert.equal(reused.maintainedSourceContracts.includes("superteam-earn"), true);
  assert.equal(reused.maintainedSourceContracts.includes("taskmarket"), true);
});

test("closed and unavailable rows stay negative and are not a profit", () => {
  const record = runDecide(reuse).record;
  const closed = record.opportunities.find((row) => row.identity === "taskmarket::closed-1");
  assert.equal(closed.status, "closed");
  assert.equal(closed.nextSupportedAction, "record_negative");
  assert.equal(closed.profitable, null);
  const unavailable = record.negativeEvidence.find((row) => row.id === "unavailable:bountyhub");
  assert.equal(unavailable.nextSupportedAction, "source_unavailable");
  assert.equal(record.decision.profitable, null);
  assert.equal(JSON.stringify(record).includes('"profitable":true'), false);
  assert.equal(JSON.stringify(record).includes("/tmp/"), false);
});

test("a source statement marked verified is refused before a record is trusted", () => {
  const forged = structuredClone(snapshot);
  forged.opportunities[0].rewardAdvertised.verified = true;
  assert.throws(
    () => decide({ now: NOW, budget, inventory: reuse, snapshot: forged }),
    (err) => err.code === "unverified_reward_marked_known",
  );
});

test("booking the token allowance as cash is refused", () => {
  const forged = structuredClone(budget);
  forged.subscriptionAllowance.bookedAsCash = true;
  assert.throws(
    () => decide({ now: NOW, budget: forged, inventory: reuse, snapshot }),
    (err) => err.code === "allowance_booked_as_cash",
  );
});

test("verify rejects a record that was given a profitable label", () => {
  const record = runDecide(reuse).record;
  record.decision.profitable = true;
  const checked = verifyDecision(record);
  assert.equal(checked.exitCode, 2);
  assert.equal(checked.answer.refusal.code, "synthetic_profit");
  assert.equal(checked.answer.nextAction, null);
});

test("a later capture keeps prior negative evidence and a second process can read it", () => {
  const first = runDecide(reuse).record;
  const later = structuredClone(snapshot);
  later.capturedAt = "2026-10-01T12:00:00.000Z";
  later.sources = later.sources.filter((source) => source.sourceId !== "bountyhub");
  const second = decide({
    now: "2026-10-01T13:00:00.000Z",
    budget,
    inventory: reuse,
    snapshot: later,
    prior: first,
  }).record;
  assert.equal(second.history.length, 1);
  assert.equal(second.history[0].recordedAt, NOW);
  assert.equal(second.negativeEvidence.some((row) => row.id === "unavailable:bountyhub" && row.absentFromCurrentCapture === true), true);
  const dir = workDir();
  const artifact = join(dir, "record.json");
  try {
    writeFileSync(artifact, JSON.stringify(second));
    const ran = run(["read-record", "--artifact", artifact]);
    assert.equal(ran.status, 0, ran.stderr);
    const read = JSON.parse(ran.stdout);
    assert.equal(read.schema, second.schema);
    assert.equal(read.decision.verifiedEv, null);
    assert.equal(read.effort.contributor.measured, false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("contributor task spec is unlaunched 0.10 USDC and accepts a useful negative", () => {
  const spec = contributorTaskSpec();
  assert.equal(spec.launch.state, "unlaunched");
  assert.equal(spec.launch.kernelCreateCalled, false);
  assert.equal(spec.reward.amount, "0.10");
  assert.equal(spec.reward.launched, false);
  assert.equal(spec.acceptance.paysForUsefulNegative, true);
  assert.equal(spec.acceptance.requiresFavorableDecision, false);
  assert.equal(spec.termsVersion, hashTermsVersion(spec.kernelTerms));
  assert.equal(spec.kernelTerms.reward.amount, "0.10");
  assert.equal(spec.kernelTerms.slotLimit, 1);
});

test("cold decide reads two fixture sources without auth and writes only inside the experiment", () => {
  const dir = workDir();
  const out = join(dir, "record.json");
  try {
    const ran = run([
      "decide",
      "--now",
      NOW,
      "--budget",
      "experiments/l09-bounty-next-093076/fixtures/decision/budget.json",
      "--inventory",
      "experiments/l09-bounty-next-093076/fixtures/decision/inventory-reuse.json",
      "--snapshot",
      "experiments/l09-bounty-next-093076/fixtures/decision/snapshot.json",
      "--discovery",
      "cached",
      "--out",
      out,
    ]);
    assert.equal(ran.status, 0, ran.stderr);
    const doc = JSON.parse(ran.stdout);
    assert.equal(doc.claimAuthority, "none");
    assert.equal(doc.paymentAuthority, "none");
    assert.equal(doc.decision.profitable, null);
    assert.equal(doc.effort.requester.measured, true);
    assert.equal(typeof doc.effort.requester.wallClockMs, "number");
    assert.equal(doc.effort.contributor.measured, false);
    assert.equal(doc.maintainedSourceContracts.includes("superteam-earn"), true);
    assert.equal(doc.maintainedSourceContracts.includes("taskmarket"), true);
    const written = JSON.parse(readFileSync(out, "utf8"));
    assert.equal(written.decision.verifiedEv, null);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("the published machine entry points at the receipt and does not claim a payout", () => {
  const record = runDecide(reuse).record;
  const entry = publicMachineEntry(record);
  assert.equal(entry.schema, "neomorphic.l09.public_next_action.v1");
  assert.equal(entry.claimAuthority, "none");
  assert.equal(entry.paymentAuthority, "none");
  assert.equal(entry.profitable, null);
  assert.equal(entry.verifiedEv, null);
  assert.equal(entry.humanPage, false);
  assert.match(entry.receipt, /^experiments\/l09-bounty-next-093076\/published\//);
});

test("cached decide on the real snapshot and the live shortlist stays honest", () => {
  const real = JSON.parse(readFileSync(join(REPO, "public/labs/bounty-discovery/snapshot-v1.json"), "utf8"));
  const shortlist = JSON.parse(readFileSync(join(PACK, "published/live-shortlist.json"), "utf8"));
  const record = decide({
    now: NOW,
    budget,
    inventory: reuse,
    snapshot: real,
    shortlist,
  }).record;
  assert.equal(record.maintainedSourceContracts.includes("github-public-issues"), true);
  assert.equal(record.maintainedSourceContracts.includes("bugzilla-mozilla"), true);
  assert.ok(record.maintainedSourceContracts.length >= 2);
  assert.equal(record.negativeEvidence.some((row) => row.kind === "source_unavailable"), true);
  assert.equal(record.negativeEvidence.some((row) => row.status === "closed" || row.kind === "closed_listings"), true);
  assert.equal(record.opportunities.some((row) => row.status === "closed"), true);
  assert.equal(record.opportunities.every((row) => row.reward.verified === false), true);
  assert.equal(record.decision.profitable, null);
  assert.equal(record.decision.verifiedEv, null);
  assert.equal(JSON.stringify(record).includes("/tmp/"), false);
  assert.equal(JSON.stringify(record).includes("pilot-heavy-relay"), false);
  const github = record.opportunities.find((row) => row.sourceContract === "github-public-issues");
  assert.equal(github.status, "open");
  assert.equal(github.nextSupportedAction, "public_get");
  assert.equal(github.sensitivity.cases[0].nextSupportedAction, "skip_over_budget");
  assert.equal(record.decision.nextAction.kind, "public_get");
  assert.equal(record.decision.nextAction.url, github.sourceUrl);
  assert.equal(github.reward.verification, "unknown");
  assert.equal(github.opportunityClass, "unrewarded_contribution");
  assert.notEqual(github.opportunityClass, "paid_revenue");
  assert.equal(github.revenueProof, false);
  assert.equal(github.ranksAsProfitable, false);
  assert.equal(record.decision.revenueProof, false);
  assert.equal(record.decision.ranksAsProfitable, false);
  assert.equal(verifyDecision(record).exitCode, 0);
});

test("the current volunteer issue GET is information and not revenue proof", () => {
  const shortlist = JSON.parse(readFileSync(join(PACK, "published/current-shortlist.json"), "utf8"));
  const real = JSON.parse(readFileSync(join(REPO, "public/labs/bounty-discovery/snapshot-v1.json"), "utf8"));
  const record = decide({
    now: NOW,
    budget,
    inventory: reuse,
    snapshot: real,
    shortlist,
  }).record;
  const volunteer = record.opportunities.find((row) => String(row.sourceUrl || "").includes("volunteer"));
  assert.ok(volunteer);
  assert.equal(volunteer.opportunityClass, "information");
  assert.equal(volunteer.revenueProof, false);
  assert.equal(volunteer.ranksAsProfitable, false);
  assert.equal(volunteer.profitable, null);
  assert.equal(record.decision.opportunityClass, "information");
  assert.equal(record.decision.revenueProof, false);
  assert.equal(record.decision.nextAction.url, volunteer.sourceUrl);
  assert.equal(record.opportunities.every((row) => row.ranksAsProfitable === false), true);
  assert.equal(record.opportunities.some((row) => row.reward.verification === "unknown" && row.opportunityClass === "paid_revenue"), false);
  assert.equal(verifyDecision(record).exitCode, 0);
});
