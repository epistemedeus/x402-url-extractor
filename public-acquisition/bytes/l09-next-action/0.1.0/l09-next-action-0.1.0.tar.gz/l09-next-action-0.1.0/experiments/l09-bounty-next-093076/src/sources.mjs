import { parseBugzillaPayload } from "../../vf15-actionable-work/src/adapters/bugzilla-mozilla.mjs";
import { parseGithubPayload } from "../../vf15-actionable-work/src/adapters/github-public-issues.mjs";
import { sha256Prefixed } from "../../vf15-actionable-work/src/hash.mjs";
import { qualifyRun, selectItem } from "../../vf15-actionable-work/src/qualify.mjs";
import { VF15_SCHEMA } from "./constants.mjs";
import { fail } from "./paths.mjs";

const PARSERS = {
  "github-public-issues": parseGithubPayload,
  "bugzilla-mozilla": parseBugzillaPayload,
};

function internal(message) {
  throw fail("internal", message);
}

export function unavailableFetch() {
  return async () => ({ ok: false, status: 503, text: async () => "" });
}

export async function readSource(spec) {
  let captured = null;
  let fetchImpl = spec.fetchImpl;
  if (spec.mode === "live") {
    const inner = spec.fetchImpl ?? globalThis.fetch;
    fetchImpl = async (url, opts) => {
      const response = await inner(url, opts);
      const body = typeof response.text === "function" ? await response.text() : "";
      captured = body;
      return { ok: response.ok, status: response.status, text: async () => body };
    };
  }
  const doc = await qualifyRun({
    adapterId: spec.adapterId,
    mode: spec.mode,
    now: spec.now,
    fixtureText: spec.fixtureText,
    fixtureId: spec.fixtureId,
    fetchImpl,
    timeoutMs: spec.timeoutMs,
  });
  if (doc.schema !== VF15_SCHEMA) internal("Neo209 document schema mismatch");
  if (doc.limits?.claimAuthority !== "none" || doc.limits?.paymentAuthority !== "none") {
    internal("Neo209 limits are not claim none and payment none");
  }
  if (doc.limits?.safeToStartWork !== false || doc.limits?.offer !== false) {
    internal("Neo209 said this record was an offer or safe to start");
  }
  const text = spec.mode === "fixture" ? spec.fixtureText : captured;
  let updatedAt = null;
  let preferred = false;
  if (doc.qualified) {
    if (typeof text !== "string" || !text) internal("qualified source had no body");
    if (sha256Prefixed(text) !== doc.provenance.bodySha256) {
      internal("source body hash does not match Neo209 provenance");
    }
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      internal("qualified source was not json");
    }
    const shaped = PARSERS[spec.adapterId](parsed);
    if (!shaped.ok) internal("qualified source did not parse");
    const { selected } = selectItem(shaped.items);
    if (!selected || selected.nativeId !== doc.action?.nativeId) {
      internal("Neo209 selection did not match the adapter parse");
    }
    updatedAt = selected.updatedAt;
    preferred = selected.preferred === true;
    if (doc.catalogBridge?.discovery?.nextStep !== "observe_only") {
      internal("qualified Neo209 next step was not observe_only");
    }
  }
  const injected = spec.injectedTransport === true;
  return {
    adapterId: spec.adapterId,
    sourceId: doc.provenance.sourceId,
    qualified: doc.qualified === true,
    refusal: doc.refusal,
    action: doc.action,
    dropped: doc.selection?.dropped ?? [],
    bodySha256: doc.provenance.bodySha256,
    evidenceClass: injected ? "replay_injected_fetch" : doc.provenance.evidenceClass,
    vf15EvidenceClass: doc.provenance.evidenceClass,
    httpStatus: doc.provenance.httpStatus,
    fixtureId: spec.fixtureId ?? null,
    nextStep: doc.catalogBridge?.discovery?.nextStep ?? null,
    taskClass: doc.catalogBridge?.discovery?.taskClass ?? null,
    updatedAt,
    preferred,
    injectedTransport: injected,
  };
}
