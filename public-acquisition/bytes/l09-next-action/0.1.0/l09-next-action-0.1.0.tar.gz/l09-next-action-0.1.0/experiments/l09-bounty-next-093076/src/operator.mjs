import { createHash } from "node:crypto";
import { CONSUMER, OPERATOR_FIXTURE } from "./constants.mjs";
import { fail, readPermitted, REPO } from "./paths.mjs";
import { relative, resolve, sep } from "node:path";

function lane(message) {
  throw fail("lane_collision", message);
}

export function operatorFingerprint(text) {
  return `sha256:${createHash("sha256").update(text, "utf8").digest("hex")}`;
}

/**
 * Operator-sponsored work is the pinned earned-work requester fixture.
 * A public issue path cannot enter this lane.
 */
export function loadOperator(cwd, mode) {
  if (mode === "none") {
    return { items: [], fingerprint: "sha256:none", text: "" };
  }
  const userPath = mode || OPERATOR_FIXTURE;
  const read = readPermitted(cwd, userPath);
  const rel = relative(REPO, read.abs).split(sep).join("/");
  if (rel !== OPERATOR_FIXTURE) {
    lane("operator lane only accepts the pinned earned-work requester fixture");
  }
  let job;
  try {
    job = JSON.parse(read.text);
  } catch {
    lane("operator fixture was not json");
  }
  if (job.fundingProvenance !== "operator_declared") {
    lane("operator fixture is not operator_declared");
  }
  if (typeof job.outcome?.summary !== "string" || !job.outcome.summary.trim()) {
    lane("operator fixture has no requester outcome");
  }
  const reward = job.reward;
  if (!reward || typeof reward.amount !== "string" || reward.asset !== "USDC" || typeof reward.network !== "string") {
    lane("operator fixture reward is not the disclosed hypothesis shape");
  }
  if (typeof job.operatorDeclaration?.note !== "string") {
    lane("operator fixture has no operator declaration");
  }
  const absFixture = resolve(REPO, OPERATOR_FIXTURE);
  if (read.abs !== absFixture && read.abs !== resolve(absFixture)) {
    lane("operator fixture path drifted");
  }
  return {
    fingerprint: operatorFingerprint(read.text),
    text: read.text,
    items: [
      {
        lane: "operatorSponsored",
        id: "h36-operator-declared-e18",
        fundingProvenance: "operator_declared",
        fixture: OPERATOR_FIXTURE,
        sponsoredByOperator: true,
        availableAsExternalJob: false,
        customerRevenue: false,
        reward: {
          amount: reward.amount,
          asset: reward.asset,
          network: reward.network,
          status: "disclosed_hypothesis",
          known: false,
          profit: null,
        },
        action: {
          kind: "held_by_earned_work_requester",
          method: null,
          url: null,
          consumerModule: CONSUMER.module,
        },
      },
    ],
  };
}
