/**
 * Optional labelled live probe of the two Neo209 sources.
 * Prints a short report and exits 0 when a source is down.
 * Does not write the repository. persist-live is the writer for the live artifacts.
 */
import { fileURLToPath } from "node:url";
import { refreshPair } from "../src/refresh.mjs";

const repo = fileURLToPath(new URL("../../..", import.meta.url));
const now = new Date().toISOString();
try {
  const result = await refreshPair({
    cwd: repo,
    mode: "live",
    now,
    network: true,
    operatorMode: "none",
    timeoutMs: 20000,
  });
  const report = {
    evidenceClass: "live_public_get",
    probedAt: now,
    exitCode: result.exitCode,
    refusal: result.doc.refusal,
    nextNativeId: result.doc.nextAction?.nativeId ?? null,
    nextUrl: result.doc.nextAction?.url ?? null,
    sources: result.doc.sources.map((source) => ({
      adapterId: source.adapterId,
      qualified: source.qualified,
      httpStatus: source.httpStatus,
      refusal: source.refusal?.code ?? null,
      evidenceClass: source.vf15EvidenceClass,
    })),
    syntheticProfitClaim: false,
  };
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
} catch (err) {
  process.stdout.write(`${JSON.stringify({
    evidenceClass: "live_public_get",
    probedAt: now,
    exitCode: 0,
    refusal: { code: err.code || "probe_error", message: "live probe did not complete" },
    nextNativeId: null,
    nextUrl: null,
    sources: [],
    syntheticProfitClaim: false,
  }, null, 2)}\n`);
}
process.exit(0);
