import { REASONING_METERS, TOKEN_SLOTS } from "./constants.mjs";
import { fail } from "./errors.mjs";
import { isUnknown, quantity } from "./quantity.mjs";

export function resolveReasoningMeter(input = {}, field = "tokens") {
  const explicit = input.reasoningMeter;
  if (explicit) {
    if (!REASONING_METERS.includes(explicit)) {
      fail("tokens.meter", `${field}.reasoningMeter must be included_in_output or separate_meter`);
    }
    if (input.reasoningIncludedInOutput === true && explicit === "separate_meter") {
      fail("tokens.meter_conflict", `${field}: reasoningMeter=separate_meter contradicts reasoningIncludedInOutput=true`);
    }
    if (input.reasoningIncludedInOutput === false && explicit === "included_in_output") {
      fail("tokens.meter_conflict", `${field}: reasoningMeter=included_in_output contradicts reasoningIncludedInOutput=false`);
    }
    if (input.reasoningNotInOutput === true && explicit === "included_in_output") {
      fail("tokens.meter_conflict", `${field}: reasoningMeter=included_in_output contradicts reasoningNotInOutput=true`);
    }
    if (input.reasoningNotInOutput === false && explicit === "separate_meter") {
      fail("tokens.meter_conflict", `${field}: reasoningMeter=separate_meter contradicts reasoningNotInOutput=false`);
    }
    return explicit;
  }
  const includedFlag = input.reasoningIncludedInOutput;
  const separateFlag = input.reasoningNotInOutput;
  if (includedFlag === true && separateFlag === true) {
    fail("tokens.meter_conflict", `${field}: reasoning cannot be both included in output and a separate billed meter`);
  }
  if (includedFlag === false && separateFlag === false) {
    fail("tokens.meter_conflict", `${field}: reasoning would be omitted from both output and a separate meter`);
  }
  if (separateFlag === true || includedFlag === false) return "separate_meter";
  return "included_in_output";
}

function slot(input, field) {
  return quantity(input ?? { kind: "unknown" }, field, { integer: true, unit: "tokens" });
}

/**
 * Reasoning is a subcount of output by default and is never added to output
 * for billing. Cached tokens are a separate billed bucket, never also billed
 * as uncached.
 */
export function normalizeTokenUse(input = {}, field = "tokens") {
  if (input === null || typeof input !== "object" || Array.isArray(input)) {
    fail("tokens.object", `${field} must be a plain object`);
  }
  const inputUncached = slot(input.inputUncached, `${field}.inputUncached`);
  const inputCached = slot(input.inputCached, `${field}.inputCached`);
  const output = slot(input.output, `${field}.output`);
  const reasoning = slot(input.reasoning, `${field}.reasoning`);
  const reasoningMeter = resolveReasoningMeter(input, field);
  const reasoningIncludedInOutput = reasoningMeter === "included_in_output";
  const issues = [];

  if (input.billOutputPlusReasoning === true) {
    fail(
      "tokens.double_count",
      `${field}: billing output+reasoning double-counts reasoning when it is a subcount of output`,
    );
  }
  if (input.includeCachedInUncached === true) {
    fail("tokens.double_count", `${field}: cached tokens must not also be billed as uncached`);
  }

  if (!isUnknown(reasoning) && !isUnknown(output) && reasoningIncludedInOutput) {
    if (reasoning.value > output.value) {
      fail(
        "tokens.reasoning_gt_output",
        `${field}.reasoning (${reasoning.value}) exceeds output (${output.value}) while marked as a subcount`,
      );
    }
  }

  let inputTotal = null;
  if (!isUnknown(inputUncached) && !isUnknown(inputCached)) {
    inputTotal = inputUncached.value + inputCached.value;
  }
  if (input.inputTotal !== undefined && input.inputTotal !== null) {
    const supplied = slot(input.inputTotal, `${field}.inputTotal`);
    if (!isUnknown(supplied) && inputTotal !== null && supplied.value !== inputTotal) {
      fail(
        "tokens.total_mismatch",
        `${field}.inputTotal ${supplied.value} != uncached+cached ${inputTotal}`,
      );
    }
    if (!isUnknown(supplied) && inputTotal === null) inputTotal = supplied.value;
  }

  const billedOutput = reasoningIncludedInOutput ? output : null;
  if (!reasoningIncludedInOutput && isUnknown(output) && !isUnknown(reasoning)) {
    issues.push("output_unknown_reasoning_not_included");
  }

  const unknownSlots = TOKEN_SLOTS.filter((name) => {
    const q = { inputUncached, inputCached, output, reasoning }[name];
    return isUnknown(q);
  });

  return {
    inputUncached,
    inputCached,
    output,
    reasoning,
    reasoningMeter,
    reasoningIncludedInOutput,
    inputTotal: inputTotal === null
      ? { kind: "unknown", value: null, unit: "tokens", verified: false }
      : { kind: "derived", value: inputTotal, unit: "tokens", verified: false },
    billedOutput,
    unknownSlots,
    issues,
    doubleCount: false,
  };
}

export function tokenUseUnknown() {
  return normalizeTokenUse({});
}
