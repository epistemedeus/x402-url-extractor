import { SETTLEMENT_UNITS } from "./constants.mjs";
import { fail } from "./errors.mjs";

export function assertSettlementUnit(unit, field) {
  if (!unit) fail("units.missing", `${field} needs a settlement unit`);
  if (!SETTLEMENT_UNITS.includes(unit)) {
    fail(
      "units.unsupported",
      `${field} unit ${unit} is unsupported; v1 admits USD or USDC only and does not guess FX`,
    );
  }
  return unit;
}

export function assertSameUnit(a, b, field) {
  if (a && b && a !== b) {
    fail("units.mixed", `${field} mixes ${a} and ${b}; identical units required (no implicit FX)`);
  }
}

export function resolveSettlementCurrency(input = {}) {
  const unit = input.settlementCurrency ?? input.gross?.unit ?? "USDC";
  return assertSettlementUnit(unit, "settlementCurrency");
}

export function rateUnitFor(currency) {
  return `${assertSettlementUnit(currency, "rate")}/MTok`;
}
