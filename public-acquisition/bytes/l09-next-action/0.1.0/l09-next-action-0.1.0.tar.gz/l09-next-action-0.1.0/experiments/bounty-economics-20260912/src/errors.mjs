export class EconomicsError extends Error {
  constructor(code, message, extra = {}) {
    super(message);
    this.name = "EconomicsError";
    this.code = code;
    Object.assign(this, extra);
  }
}

export function fail(code, message, extra) {
  throw new EconomicsError(code, message, extra);
}
