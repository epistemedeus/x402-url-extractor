import { QUANTITY_KINDS } from "./constants.mjs";
import { fail } from "./errors.mjs";
import { admitDecimal } from "./money.mjs";

export function statusFromKind(kind) {
  if (kind === "measured") return "observed";
  if (kind === "not_applicable") return "not_applicable";
  if (kind === "unknown") return "missing";
  return "estimated";
}

const HOSTILE_KEYS = new Set(["__proto__", "constructor", "prototype"]);

const RANK = Object.freeze({
  unknown: 0,
  not_applicable: 0,
  hypothetical: 1,
  operator_supplied: 2,
  claimed_platform: 2,
  scenario: 2,
  estimate: 3,
  derived: 4,
  measured: 5,
});

export function provenanceRank(kind) {
  if (!Object.hasOwn(RANK, kind)) fail("quantity.kind", `unknown quantity kind ${kind}`);
  return RANK[kind];
}

export function weakestKind(kinds) {
  let best = "measured";
  let rank = RANK.measured;
  for (const kind of kinds) {
    const r = provenanceRank(kind);
    if (r < rank) {
      rank = r;
      best = kind;
    }
  }
  return best;
}

function rejectHostile(input, field) {
  if (input === null || typeof input !== "object" || Array.isArray(input)) {
    fail("quantity.object", `${field} must be a plain object`);
  }
  for (const key of Object.keys(input)) {
    if (HOSTILE_KEYS.has(key)) fail("quantity.hostile", `${field} contains hostile key ${key}`);
  }
}

export function unknownQuantity(unit = null, extra = {}) {
  const meta = metaFrom(extra, "unknown");
  return {
    ...meta,
    kind: "unknown",
    value: null,
    unit,
    status: "missing",
    asOf: extra.asOf ?? meta.asOf ?? null,
    source: extra.source ?? meta.source ?? null,
    verified: false,
  };
}

export function notApplicableQuantity(unit = null, extra = {}) {
  const meta = metaFrom(extra, "not_applicable");
  return {
    ...meta,
    kind: "not_applicable",
    value: null,
    unit,
    status: "not_applicable",
    asOf: extra.asOf ?? meta.asOf ?? null,
    source: extra.source ?? meta.source ?? null,
    verified: false,
  };
}

function asOfOf(input) {
  return input.asOf ?? input.observed_at ?? input.date ?? null;
}

const META_KEYS = new Set([
  "reason",
  "notes",
  "label",
  "formula",
  "plane",
  "basis",
  "asOf",
  "source",
  "suppressed",
  "suppressedBecause",
  "method",
  "derivedFrom",
  "weakestProvenance",
  "code",
  "unbounded",
  "noFiniteBreakEven",
  "sample",
  "date",
  "route",
]);

function metaFrom(extra = {}, field = "quantity") {
  if (extra.kind !== undefined || extra.value !== undefined || extra.verified === true || extra.unit !== undefined) {
    fail("quantity.canonical", `${field} cannot override kind, value, unit, or verified`);
  }
  const out = {};
  for (const [key, value] of Object.entries(extra)) {
    if (META_KEYS.has(key)) out[key] = value;
  }
  return out;
}

export function quantity(input, field, { allowNegative = false, integer = false, unit = null } = {}) {
  if (input === undefined || input === null) return unknownQuantity(unit);
  if (typeof input !== "object" || Array.isArray(input)) {
    fail("quantity.object", `${field} must be { kind, value? } (unknown is not a bare number)`);
  }
  rejectHostile(input, field);
  const kind = input.kind;
  if (!QUANTITY_KINDS.includes(kind)) fail("quantity.kind", `${field}.kind is not a known quantity kind`);
  if (input.verified === true) {
    fail("quantity.verified", `${field} must not be labelled verified; this pack never upgrades caller assertions`);
  }
  if (kind === "unknown" || kind === "not_applicable") {
    if (input.value !== undefined && input.value !== null) {
      fail("quantity.unknown_value", `${field} kind=${kind} cannot carry a value (unknown/n-a is not that value)`);
    }
    return {
      kind,
      value: null,
      unit: input.unit ?? unit,
      status: statusFromKind(kind),
      asOf: asOfOf(input),
      basis: input.basis ?? null,
      source: input.source ?? null,
      notes: input.notes ?? null,
      verified: false,
    };
  }
  if (input.value === undefined || input.value === null) {
    fail("quantity.missing_value", `${field} kind=${kind} requires a value; omit or use kind=unknown`);
  }
  if (unit != null && input.unit != null && input.unit !== unit) {
    fail("quantity.unit_mismatch", `${field} unit ${input.unit} does not match expected ${unit}`);
  }
  const resolvedUnit = unit ?? input.unit ?? null;
  if (integer) {
    if (typeof input.value === "number") {
      if (!Number.isSafeInteger(input.value) || (!allowNegative && input.value < 0)) {
        fail("quantity.integer", `${field} must be a finite non-negative safe integer`);
      }
    } else if (typeof input.value === "string") {
      const raw = input.value.trim();
      if (!/^(0|[1-9]\d*)$/.test(raw)) {
        fail("quantity.integer", `${field} must be a non-negative integer string`);
      }
      if (raw.length > 15 || !Number.isSafeInteger(Number(raw))) {
        fail("quantity.unsafe_integer", `${field} integer is not a safe integer; refuse rather than round`);
      }
    } else {
      fail("quantity.integer", `${field} must be an integer`);
    }
    const n = typeof input.value === "number" ? input.value : Number(input.value);
    return {
      kind,
      value: n,
      unit: resolvedUnit ?? "count",
      status: statusFromKind(kind),
      asOf: asOfOf(input),
      basis: input.basis ?? null,
      plane: input.plane ?? null,
      sample: input.sample ?? null,
      date: input.date ?? null,
      route: input.route ?? null,
      source: input.source ?? null,
      notes: input.notes ?? null,
      verified: false,
    };
  }
  const value = admitDecimal(input.value, `${field}.value`, { allowNegative });
  return {
    kind,
    value,
    unit: resolvedUnit,
    status: statusFromKind(kind),
    asOf: asOfOf(input),
    basis: input.basis ?? null,
    plane: input.plane ?? null,
    sample: input.sample ?? null,
    date: input.date ?? null,
    route: input.route ?? null,
    source: input.source ?? null,
    notes: input.notes ?? null,
    verified: false,
  };
}

export function isUnknown(q) {
  return !q || q.kind === "unknown" || q.kind === "not_applicable" || q.value === null || q.value === undefined;
}

export function isMissing(q) {
  return !q || q.kind === "unknown" || q.status === "missing";
}

export function withAsOf(q, asOf, source = null) {
  if (!q || typeof q !== "object") return q;
  return {
    ...q,
    status: q.status ?? statusFromKind(q.kind),
    asOf: q.asOf ?? asOf ?? null,
    source: q.source ?? source ?? null,
  };
}

export function eachQuantity(node, visit, seen = new Set()) {
  if (!node || typeof node !== "object") return;
  if (seen.has(node)) return;
  seen.add(node);
  if (typeof node.kind === "string" && QUANTITY_KINDS.includes(node.kind) && Object.hasOwn(node, "value")) {
    visit(node);
  }
  if (Array.isArray(node)) {
    for (const item of node) eachQuantity(item, visit, seen);
    return;
  }
  for (const value of Object.values(node)) eachQuantity(value, visit, seen);
}

export function knownValue(q) {
  if (isUnknown(q)) return null;
  return q.value;
}

export function displayQuantity(q) {
  if (!q) return "unknown";
  if (q.kind === "not_applicable") return "not_applicable";
  if (q.kind === "unknown" || q.value === null || q.value === undefined) return "unknown";
  const unit = q.unit ? ` ${q.unit}` : "";
  return `${q.value}${unit}`;
}

export function derivedQuantity(value, sources, unit, extra = {}) {
  const kinds = sources.map((s) => s.kind);
  if (kinds.includes("unknown") || kinds.includes("not_applicable") || value === null) {
    return unknownQuantity(unit, extra);
  }
  const meta = metaFrom(extra, "derived");
  return {
    ...meta,
    kind: "derived",
    value,
    unit,
    status: "estimated",
    asOf: extra.asOf ?? meta.asOf ?? sources.map((s) => s.asOf).find(Boolean) ?? null,
    derivedFrom: sources.map((s) => s.kind),
    weakestProvenance: weakestKind(kinds),
    verified: false,
  };
}
