import { fail } from "./errors.mjs";
import { add, mul } from "./money.mjs";
import { derivedQuantity, isUnknown, quantity, unknownQuantity } from "./quantity.mjs";
import { normalizeTokenUse } from "./tokens.mjs";
import { rateUnitFor, resolveSettlementCurrency } from "./units.mjs";

function rate(input, field, currency) {
  const expected = rateUnitFor(currency);
  const q = quantity(input ?? { kind: "unknown" }, field, { unit: expected });
  if (!isUnknown(q) && (q.sample == null && q.date == null && q.route == null && q.basis == null)) {
    fail("costs.rate_basis", `${field} needs sample, date, route, or basis; a bare number is not a rate`);
  }
  return q;
}

function perTokenFromMillion(rateQty, field) {
  if (isUnknown(rateQty)) return null;
  return mul(rateQty.value, "0.000001", field);
}

function planeFromTokens(tokens, rates, field, currency) {
  if (rates.reasoningNotInOutput === true && tokens.reasoningMeter === "included_in_output") {
    fail("costs.meter_conflict", `${field}: rates.reasoningNotInOutput contradicts included_in_output meter`);
  }
  if (rates.reasoningNotInOutput === false && tokens.reasoningMeter === "separate_meter") {
    fail("costs.meter_conflict", `${field}: rates.reasoningNotInOutput=false contradicts separate_meter`);
  }
  const sources = [];
  const uncachedRate = perTokenFromMillion(rates.uncachedPerMillion, `${field}.uncached`);
  const cachedRate = perTokenFromMillion(rates.cachedPerMillion, `${field}.cached`);
  const outputRate = perTokenFromMillion(rates.outputPerMillion, `${field}.output`);
  const reasoningRate = tokens.reasoningMeter === "separate_meter"
    ? perTokenFromMillion(rates.reasoningPerMillion, `${field}.reasoning`)
    : null;

  function addPart(countQty, unitRate, rateQty) {
    if (isUnknown(countQty)) return { unknown: true };
    if (countQty.value === 0) return { value: "0" };
    if (unitRate === null) return { unknown: true };
    sources.push(countQty, rateQty);
    return { value: mul(String(countQty.value), unitRate, field) };
  }

  const billedOutput = tokens.reasoningMeter === "included_in_output" ? tokens.output : tokens.output;
  const parts = [
    addPart(tokens.inputUncached, uncachedRate, rates.uncachedPerMillion),
    addPart(tokens.inputCached, cachedRate, rates.cachedPerMillion),
    addPart(billedOutput, outputRate, rates.outputPerMillion),
  ];
  if (tokens.reasoningMeter === "separate_meter") {
    parts.push(addPart(tokens.reasoning, reasoningRate, rates.reasoningPerMillion));
  }
  if (parts.some((p) => p.unknown)) return unknownQuantity(currency);
  const total = parts.reduce((sum, p) => add(sum, p.value, field), "0");
  return derivedQuantity(total, sources.length ? sources : [{ kind: "derived" }], currency, { plane: "list" });
}

export function normalizeRates(input = {}, field = "rates", currency = "USDC") {
  if (input === null || typeof input !== "object" || Array.isArray(input)) {
    fail("costs.rates", `${field} must be a plain object`);
  }
  return {
    uncachedPerMillion: rate(input.uncachedPerMillion, `${field}.uncachedPerMillion`, currency),
    cachedPerMillion: rate(input.cachedPerMillion, `${field}.cachedPerMillion`, currency),
    outputPerMillion: rate(input.outputPerMillion, `${field}.outputPerMillion`, currency),
    reasoningPerMillion: rate(input.reasoningPerMillion, `${field}.reasoningPerMillion`, currency),
    reasoningNotInOutput: input.reasoningNotInOutput,
    sample: input.sample ?? null,
    date: input.date ?? null,
    route: input.route ?? null,
  };
}

export function costPlanes({ tokens, rates, cash, subscriptionAllocation, quotaShadow, settlementCurrency }, field = "costs") {
  const currency = resolveSettlementCurrency({ settlementCurrency, gross: { unit: settlementCurrency } });
  const use = normalizeTokenUse(tokens ?? {}, `${field}.tokens`);
  const r = normalizeRates(rates ?? {}, `${field}.rates`, currency);
  const apiPriceEquivalent = planeFromTokens(use, r, `${field}.api`, currency);
  const cashQty = quantity(cash ?? { kind: "unknown" }, `${field}.cash`, { unit: currency });
  const subQty = quantity(subscriptionAllocation ?? { kind: "unknown" }, `${field}.subscriptionAllocation`, {
    unit: currency,
  });
  const quotaQty = quantity(quotaShadow ?? { kind: "unknown" }, `${field}.quotaShadow`, { unit: currency });
  if (isUnknown(cashQty) && cashQty.value === 0) {
    fail("costs.unknown_zero", "cash kind=unknown cannot be 0");
  }
  const economic = (!isUnknown(cashQty) && !isUnknown(quotaQty))
    ? derivedQuantity(add(cashQty.value, quotaQty.value, `${field}.economic`), [cashQty, quotaQty], currency, {
      plane: "custom-economic",
    })
    : unknownQuantity(currency, { reason: "economic cost needs cash and quota shadow; unknown lambda is not 0" });
  return {
    tokens: use,
    rates: r,
    cash: cashQty,
    listEquivalent: apiPriceEquivalent,
    apiPriceEquivalent,
    subscriptionAllocation: subQty,
    sharedAllocation: subQty,
    quotaShadow: quotaQty,
    economic,
    notes: [
      "Cash, list/API-price equivalent, quota shadow, economic (cash+shadow), and shared allocation are separate planes.",
      "Unknown cash is not treated as $0. Unknown quota shadow is not treated as $0.",
      "API-price equivalent uses caller-supplied sample/date/route rates; this pack has no vendor price catalog.",
      "An all-Grok session range is not an observed Pilot cost.",
    ],
  };
}

export function originalVersusMarginal(input = {}) {
  const settlementCurrency = input.settlementCurrency ?? "USDC";
  const originalBuild = costPlanes({
    tokens: input.originalBuild?.tokens,
    rates: input.rates ?? input.originalBuild?.rates,
    cash: input.originalBuild?.cash,
    subscriptionAllocation: input.originalBuild?.subscriptionAllocation,
    quotaShadow: input.originalBuild?.quotaShadow,
    settlementCurrency,
  }, "originalBuild");
  const marginalDelivery = costPlanes({
    tokens: input.marginalDelivery?.tokens,
    rates: input.rates ?? input.marginalDelivery?.rates,
    cash: input.marginalDelivery?.cash,
    subscriptionAllocation: input.marginalDelivery?.subscriptionAllocation,
    quotaShadow: input.marginalDelivery?.quotaShadow,
    settlementCurrency,
  }, "marginalDelivery");
  return {
    originalBuild,
    marginalDelivery,
    notes: [
      "Original build is first-time creation cost. Marginal delivery is reuse of an existing asset.",
      "Unknown original tokens stay unknown; they are not copied from a hypothetical marginal scenario.",
    ],
  };
}
