import { CRITICAL_EV_FIELDS } from "./constants.mjs";
import { fail } from "./errors.mjs";
import { add, assertUnitInterval, cmp, div, mul, sub } from "./money.mjs";
import { derivedQuantity, isUnknown, notApplicableQuantity, quantity, unknownQuantity } from "./quantity.mjs";
import { resolveSettlementCurrency } from "./units.mjs";

function qMoney(input, field, opts = {}) {
  return quantity(input ?? { kind: "unknown" }, field, {
    unit: opts.unit,
    allowNegative: opts.allowNegative === true,
  });
}

function qProb(input, field) {
  const unit = input?.unit === "rate" ? "rate" : "probability";
  const q = quantity(input ?? { kind: "unknown" }, field, { unit });
  if (!isUnknown(q)) assertUnitInterval(q.value, field);
  return q;
}

/**
 * W = G * (1 - f) - F
 * Wallet net after proportional fee and flat fee, before stage costs.
 * This is net, not profit.
 */
export function walletNet({ gross, feeRate, flatFee, settlementCurrency }, field = "wallet") {
  const currency = resolveSettlementCurrency({ settlementCurrency, gross });
  const G = qMoney(gross, `${field}.G`, { unit: currency });
  const f = qProb(feeRate, `${field}.f`);
  const F = qMoney(flatFee, `${field}.F`, { unit: currency });
  if (isUnknown(G) || isUnknown(f) || isUnknown(F)) {
    return {
      G,
      f,
      F,
      currency,
      W: unknownQuantity(currency, { reason: "missing G, f, or F" }),
      formula: "W = G * (1 - f) - F",
      label: "net_wallet_not_profit",
    };
  }
  const keep = sub("1", f.value, `${field}.keep`);
  const afterRate = mul(G.value, keep, `${field}.afterRate`);
  const Wvalue = sub(afterRate, F.value, `${field}.W`);
  return {
    G,
    f,
    F,
    currency,
    W: derivedQuantity(Wvalue, [G, f, F], currency, { label: "net_wallet_not_profit" }),
    formula: "W = G * (1 - f) - F",
    label: "net_wallet_not_profit",
  };
}

function stageCost(input, field, currency) {
  return qMoney(input, field, { unit: currency });
}

/**
 * Staged conditional expected wallet:
 * EV = pA*pD*pQ*pS*W - C0 - pA*C1 - pA*pD*C2 - pA*pD*pQ*pS*C3
 * C0 prebid always; C1 delivery if awarded; C2 correction if delivered; C3 collection if settled.
 * pL is recorded separately and is not multiplied in unless a labelled liquidity scenario says so.
 */
export function expectedWallet(input = {}, field = "ev") {
  if (input.includeLiquidityInEv === true) {
    fail("wallet.liquid_fold", "pL is not multiplied into point EV; use expectedLiquid with staged cost incidence");
  }
  if (input.W && input.gross) {
    fail("wallet.w_and_g", "do not supply W independently of G; W is computed from G, f, F");
  }
  const currency = resolveSettlementCurrency(input);
  const net = input.W && !input.gross
    ? { W: qMoney(input.W, `${field}.W`, { allowNegative: true, unit: currency }), G: null, f: null, F: null, currency }
    : walletNet({ ...input, settlementCurrency: currency }, field);
  const pA = qProb(input.pA, `${field}.pA`);
  const pD = qProb(input.pD, `${field}.pD`);
  const pQ = qProb(input.pQ, `${field}.pQ`);
  const pS = qProb(input.pS, `${field}.pS`);
  const pL = qProb(input.pL, `${field}.pL`);
  const C0 = stageCost(input.C0, `${field}.C0`, currency);
  const C1 = stageCost(input.C1, `${field}.C1`, currency);
  const C2 = stageCost(input.C2, `${field}.C2`, currency);
  const C3 = stageCost(input.C3, `${field}.C3`, currency);
  const W = net.W;

  const fields = { pA, pD, pQ, pS, W, C0, C1, C2, C3 };
  const unknownCritical = CRITICAL_EV_FIELDS.filter((name) => isUnknown(fields[name]));
  const scenario = {
    formula: "EV_wallet = pA*pD*pQ*pS*W - C0 - pA*C1 - pA*pD*C2 - pA*pD*pQ*pS*C3",
    pA,
    pD,
    pQ,
    pS,
    pL,
    W,
    C0,
    C1,
    C2,
    C3,
    G: net.G,
    f: net.f,
    F: net.F,
    liquidityIncludedInPoint: false,
  };

  if (input.pAFromSample === true) {
    fail("wallet.sample_is_not_pa", "a selected 2/5 same-buyer sample is not calibrated pA");
  }

  if (unknownCritical.length > 0) {
    return {
      ...net,
      point: unknownQuantity(currency, { suppressed: true, suppressedBecause: unknownCritical }),
      suppressed: true,
      suppressedBecause: unknownCritical,
      scenario,
      pL,
      evIfLiquid: unknownQuantity(currency, { reason: "point EV suppressed" }),
      currency,
      label: "expected_profit_not_net",
    };
  }

  const p = mul(mul(pA.value, pD.value, `${field}.pAD`), mul(pQ.value, pS.value, `${field}.pQS`), `${field}.p`);
  const pW = mul(p, W.value, `${field}.pW`);
  const pC1 = mul(pA.value, C1.value, `${field}.pC1`);
  const pC2 = mul(mul(pA.value, pD.value, `${field}.pAD2`), C2.value, `${field}.pC2`);
  const pC3 = mul(p, C3.value, `${field}.pC3`);
  let ev = sub(pW, C0.value, `${field}.minusC0`);
  ev = sub(ev, pC1, `${field}.minusC1`);
  ev = sub(ev, pC2, `${field}.minusC2`);
  ev = sub(ev, pC3, `${field}.minusC3`);

  let evIfLiquid = unknownQuantity(currency, { reason: "pL unknown; wallet EV is not liquid EV" });
  if (!isUnknown(pL)) {
    const pLW = mul(mul(p, pL.value, `${field}.pLchain`), W.value, `${field}.pLW`);
    let liq = sub(pLW, C0.value, `${field}.liqC0`);
    liq = sub(liq, pC1, `${field}.liqC1`);
    liq = sub(liq, pC2, `${field}.liqC2`);
    liq = sub(liq, pC3, `${field}.liqC3`);
    evIfLiquid = derivedQuantity(liq, [pA, pD, pQ, pS, pL, W, C0, C1, C2, C3], currency, {
      label: "expected_liquid_not_wallet",
      notes: "revenue term uses extra pL; incurred stage costs keep their incidence",
    });
  }

  return {
    ...net,
    point: derivedQuantity(ev, [pA, pD, pQ, pS, W, C0, C1, C2, C3], currency, {
      label: "expected_profit_not_net",
    }),
    suppressed: false,
    suppressedBecause: [],
    scenario,
    pL,
    evIfLiquid,
    p,
    currency,
    label: "expected_profit_not_net",
  };
}

/**
 * Break-even gross reward G* such that EV_wallet = 0.
 * G* = (C0 + pA*C1 + pA*pD*C2 + p*(C3+F)) / (p*(1-f))
 */
export function breakEvenGross(input = {}, field = "breakEven") {
  const currency = resolveSettlementCurrency(input);
  const pA = qProb(input.pA, `${field}.pA`);
  const pD = qProb(input.pD, `${field}.pD`);
  const pQ = qProb(input.pQ, `${field}.pQ`);
  const pS = qProb(input.pS, `${field}.pS`);
  const C0 = stageCost(input.C0, `${field}.C0`, currency);
  const C1 = stageCost(input.C1, `${field}.C1`, currency);
  const C2 = stageCost(input.C2, `${field}.C2`, currency);
  const C3 = stageCost(input.C3, `${field}.C3`, currency);
  const f = qProb(input.feeRate ?? input.f, `${field}.f`);
  const F = qMoney(input.flatFee ?? input.F, `${field}.F`, { unit: currency });
  const none = (code, reason) => notApplicableQuantity(currency, { code, reason, noFiniteBreakEven: true, unbounded: code === "unbounded" });
  if ([pA, pD, pQ, pS, C0, C1, C2, C3, f, F].some(isUnknown)) {
    return { breakEvenGross: unknownQuantity(currency, { reason: "G* needs pA,pD,pQ,pS,f,F,C0-C3; current G is not required" }), currency };
  }
  const keep = sub("1", f.value, `${field}.keep`);
  if (cmp(keep, "0") === 0) {
    return { breakEvenGross: none("no_finite_break_even", "fee rate leaves no keep"), currency };
  }
  const p = mul(mul(pA.value, pD.value, `${field}.pAD`), mul(pQ.value, pS.value, `${field}.pQS`), `${field}.p`);
  if (cmp(p, "0") === 0) {
    return { breakEvenGross: none("unbounded", "zero settlement-chain probability; no finite gross threshold"), currency };
  }
  const denom = mul(p, keep, `${field}.denom`);
  if (cmp(denom, "0") === 0) {
    return { breakEvenGross: none("no_finite_break_even", "zero denominator"), currency };
  }
  const pC1 = mul(pA.value, C1.value, `${field}.pC1`);
  const pC2 = mul(mul(pA.value, pD.value, `${field}.pAD2`), C2.value, `${field}.pC2`);
  const pC3F = mul(p, add(C3.value, F.value, `${field}.C3F`), `${field}.pC3F`);
  const num = add(add(add(C0.value, pC1, `${field}.n1`), pC2, `${field}.n2`), pC3F, `${field}.num`);
  const gStar = div(num, denom, `${field}.Gstar`);
  return {
    breakEvenGross: derivedQuantity(gStar, [pA, pD, pQ, pS, C0, C1, C2, C3, f, F], currency, {
      formula: "G* = (C0 + pA*C1 + pA*pD*C2 + p*(C3+F)) / (p*(1-f))",
    }),
    currency,
    p,
  };
}

/**
 * pA* = C0 / (pD·pQ·pS·W - C1 - pD·C2 - pD·pQ·pS·C3)
 * If the denominator is zero or negative, no award probability breaks even.
 */
export function breakEvenAwardProbability(input = {}, field = "pAstar") {
  const currency = resolveSettlementCurrency(input);
  const net = input.W && !input.gross
    ? { W: qMoney(input.W, `${field}.W`, { allowNegative: true, unit: currency }) }
    : walletNet({ ...input, settlementCurrency: currency }, field);
  const pD = qProb(input.pD, `${field}.pD`);
  const pQ = qProb(input.pQ, `${field}.pQ`);
  const pS = qProb(input.pS, `${field}.pS`);
  const C0 = stageCost(input.C0, `${field}.C0`, currency);
  const C1 = stageCost(input.C1, `${field}.C1`, currency);
  const C2 = stageCost(input.C2, `${field}.C2`, currency);
  const C3 = stageCost(input.C3, `${field}.C3`, currency);
  const W = net.W;
  if ([pD, pQ, pS, W, C0, C1, C2, C3].some(isUnknown)) {
    return unknownQuantity("probability", { reason: "pA* needs pD,pQ,pS,W,C0,C1,C2,C3" });
  }
  const pChain = mul(mul(pD.value, pQ.value, `${field}.pDQ`), pS.value, `${field}.pDQS`);
  const num = C0.value;
  let denom = mul(pChain, W.value, `${field}.pW`);
  denom = sub(denom, C1.value, `${field}.minusC1`);
  denom = sub(denom, mul(pD.value, C2.value, `${field}.pDC2`), `${field}.minusC2`);
  denom = sub(denom, mul(pChain, C3.value, `${field}.pC3`), `${field}.minusC3`);
  if (cmp(denom, "0") <= 0) {
    return notApplicableQuantity("probability", {
      reason: "denominator non-positive; no award probability breaks even under these assumptions",
    });
  }
  return derivedQuantity(div(num, denom, `${field}.pAstar`), [pD, pQ, pS, W, C0, C1, C2, C3], "probability", {
    formula: "pA* = C0 / (pD*pQ*pS*W - C1 - pD*C2 - pD*pQ*pS*C3)",
  });
}

export function realizedProfit({ W, C0, C1, C2, C3, stagesOccurred, settlementCurrency }) {
  const currency = resolveSettlementCurrency({ settlementCurrency, gross: W });
  const w = qMoney(W, "realized.W", { allowNegative: true, unit: currency });
  const costs = [C0, C1, C2, C3].map((c, i) => stageCost(c, `realized.C${i}`, currency));
  if (!stagesOccurred || stagesOccurred.awarded !== true || stagesOccurred.delivered !== true || stagesOccurred.settled !== true) {
    return unknownQuantity(currency, { reason: "realized profit requires observed award+delivery+settlement, not claimed status" });
  }
  if (isUnknown(w) || costs.some(isUnknown)) return unknownQuantity(currency, { reason: "missing W or stage costs" });
  let p = w.value;
  for (const c of costs) p = sub(p, c.value, "realized");
  return derivedQuantity(p, [w, ...costs], currency, { label: "realized_profit_not_net" });
}
