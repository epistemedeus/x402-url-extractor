/**
 * One-factor ±50% attempt sensitivity from Forge F01.
 * This is not staged wallet EV and does not replace h10.bounty-economics.card.v1.
 * Unknown stays unknown. Overflow is unknown plus a flag, never Infinity.
 */
import {
  CARD_SCHEMA,
  EXPLORER_EXPORT_URN,
  EXPLORER_EXPORT_VERSION,
  FORMULA_VERSION,
  SENSITIVITY_CONTRACT_SCHEMA,
  SENSITIVITY_INPUT_SCHEMA,
  SENSITIVITY_OUTPUT_SCHEMA,
  SENSITIVITY_VARIATION,
  SETTLEMENT_UNITS,
} from "./constants.mjs";
import { fail } from "./errors.mjs";
import { parseBoundedJson } from "./load.mjs";
import { admitDecimal } from "./money.mjs";

export const FORGE_F01_SOURCE = Object.freeze({
  repository: "epistemedeus/pilot-heavy-relay",
  visibility: "private",
  branch: "codex/forge-f01-20260922",
  commit: "4ceca4fd699a415e2f630a9c293a195dff15ad40",
  path: "experiments/forge-20260922/F01/project/",
});

export const EXPORT_SCHEMA_URN = EXPLORER_EXPORT_URN;
export const EXPORT_SCHEMA_VERSION = EXPLORER_EXPORT_VERSION;

const FIELD_KEYS = [
  "payoutUsd",
  "inputTokens",
  "outputTokens",
  "inputPricePerMillionUsd",
  "outputPricePerMillionUsd",
  "acceptanceProbability",
  "reviewerMinutes",
];

const NATIVE_FIELDS = [
  ["payout", "payoutUsd", "money"],
  ["inputTokens", "inputTokens", "count"],
  ["outputTokens", "outputTokens", "count"],
  ["inputPricePerMillion", "inputPricePerMillionUsd", "money"],
  ["outputPricePerMillion", "outputPricePerMillionUsd", "money"],
  ["acceptanceProbability", "acceptanceProbability", "probability"],
  ["reviewerMinutes", "reviewerMinutes", "minutes"],
];

const VALUE_KINDS = new Set(["hypothetical", "synthetic", "scenario"]);
const LABELS = new Set(["hypothetical", "synthetic", "scenario"]);

const EMPTY = {
  payoutUsd: null,
  inputTokens: null,
  outputTokens: null,
  inputPricePerMillionUsd: null,
  outputPricePerMillionUsd: null,
  acceptanceProbability: null,
  reviewerMinutes: null,
};

const SENSITIVITY_STEPS = [
  { field: "payoutUsd", label: "Expected net reward", varyLabel: "Payout" },
  { field: "acceptanceProbability", label: "Expected net reward", varyLabel: "Acceptance probability" },
  { field: "inputPricePerMillionUsd", label: "Token cost", varyLabel: "Input price" },
  { field: "outputPricePerMillionUsd", label: "Token cost", varyLabel: "Output price" },
  { field: "inputTokens", label: "Token cost", varyLabel: "Input tokens" },
  { field: "outputTokens", label: "Token cost", varyLabel: "Output tokens" },
];

const VARIATION = 0.5;

const NOTES = [
  "Modeled attempt sensitivity. Not actual earnings.",
  "Does not replace h10.bounty-economics.card.v1 staged wallet EV (pA pD pQ pS and stage costs).",
  "A single acceptance probability is not pA, pD, pQ, or pS. Missing stages stay unknown on the card.",
  "Unknown is not zero.",
  "Token prices are caller-supplied. This pack has no vendor price catalog.",
  "No currency conversion and no settlement instruction.",
  "Reviewer minutes are not converted into money.",
  "A zero token price with positive tokens is a promotional-credit warning; modeled net is then an overestimate.",
  "Overflow is unknown plus overflowWarning, never Infinity and never a substituted zero.",
  "Not paid demand, not a listing, and not a review.",
];

function rejectNonNumber(v) {
  if (typeof v === "boolean") return "Booleans are not valid numbers";
  if (typeof v === "object" && v !== null) return "Objects and arrays are not valid numbers";
  return null;
}

export function parseOptionalNumber(raw) {
  if (raw === null || raw === undefined) return { ok: true, value: null };
  const nonNumber = rejectNonNumber(raw);
  if (nonNumber) return { ok: false, error: nonNumber };
  if (typeof raw !== "number" && typeof raw !== "string") {
    return { ok: false, error: "Must be a number" };
  }
  if (typeof raw === "number") {
    if (!Number.isFinite(raw)) return { ok: false, error: "Must be a finite number" };
    if (raw < 0) return { ok: false, error: "Must not be negative" };
    return { ok: true, value: raw };
  }
  const trimmed = raw.trim();
  if (trimmed === "") return { ok: true, value: null };
  if (trimmed.toLowerCase() === "unknown") return { ok: true, value: null };
  const n = Number(trimmed);
  if (Number.isNaN(n)) return { ok: false, error: "Must be a number" };
  if (!Number.isFinite(n)) return { ok: false, error: "Must be a finite number" };
  if (n < 0) return { ok: false, error: "Must not be negative" };
  return { ok: true, value: n };
}

export function parseBoundedNumber(raw, min, max) {
  const base = parseOptionalNumber(raw);
  if (!base.ok) return base;
  if (base.value === null) return base;
  if (base.value < min || base.value > max) {
    return { ok: false, error: `Must be between ${min} and ${max}` };
  }
  return base;
}

export function sanitizeInputs(inputs) {
  const out = { ...EMPTY };
  const source = inputs && typeof inputs === "object" ? inputs : {};
  for (const key of FIELD_KEYS) {
    const v = source[key];
    if (typeof v !== "number" || !Number.isFinite(v) || v < 0) continue;
    if (key === "acceptanceProbability" && v > 1) continue;
    out[key] = v;
  }
  return out;
}

function rawTokenCostUsd(inputs) {
  const s = sanitizeInputs(inputs);
  const { inputTokens, outputTokens, inputPricePerMillionUsd, outputPricePerMillionUsd } = s;
  if (
    inputTokens === null ||
    outputTokens === null ||
    inputPricePerMillionUsd === null ||
    outputPricePerMillionUsd === null
  ) {
    return null;
  }
  return (
    (inputTokens / 1_000_000) * inputPricePerMillionUsd +
    (outputTokens / 1_000_000) * outputPricePerMillionUsd
  );
}

export function computeTokenCostUsd(inputs) {
  const cost = rawTokenCostUsd(inputs);
  return cost !== null && Number.isFinite(cost) ? cost : null;
}

function rawExpectedGrossUsd(inputs) {
  const s = sanitizeInputs(inputs);
  const { payoutUsd, acceptanceProbability } = s;
  if (payoutUsd === null || acceptanceProbability === null) return null;
  return payoutUsd * acceptanceProbability;
}

export function computeExpectedGrossUsd(inputs) {
  const gross = rawExpectedGrossUsd(inputs);
  return gross !== null && Number.isFinite(gross) ? gross : null;
}

function rawExpectedNetUsd(inputs) {
  const cost = rawTokenCostUsd(inputs);
  const gross = rawExpectedGrossUsd(inputs);
  return cost === null || gross === null ? null : gross - cost;
}

export function computeExpectedNetUsd(inputs) {
  const net = rawExpectedNetUsd(inputs);
  return net !== null && Number.isFinite(net) ? net : null;
}

export function computeBreakEven(inputs) {
  const s = sanitizeInputs(inputs);
  const cost = rawTokenCostUsd(s);
  const p = s.acceptanceProbability;
  if (cost === null || p === null) return { value: null, reachable: true };
  if (p <= 0) {
    return { value: cost === 0 ? 0 : null, reachable: Number.isFinite(cost) ? cost <= 0 : false };
  }
  const q = cost / p;
  if (!Number.isFinite(q)) return { value: null, reachable: false };
  return { value: q, reachable: true };
}

export function clamp(v, min, max) {
  return Math.min(max, Math.max(min, v));
}

function buildSensitivity(inputs, field, label, varyLabel) {
  const base = inputs[field];
  const isBounded = field === "acceptanceProbability";
  const vary = (v) => (isBounded ? clamp(v, 0, 1) : v);
  if (base === null || !Number.isFinite(base)) {
    return { field, label, varyLabel, base: null, range: null, varyRange: null };
  }
  const lowVary = vary(base * (1 - VARIATION));
  const highVary = vary(base * (1 + VARIATION));
  if (!Number.isFinite(lowVary) || !Number.isFinite(highVary)) {
    return { field, label, varyLabel, base: null, range: null, varyRange: null };
  }
  const lowInputs = { ...inputs, [field]: lowVary };
  const highInputs = { ...inputs, [field]: highVary };
  const isCostDriver = label === "Token cost";
  const lowValue = isCostDriver ? computeTokenCostUsd(lowInputs) : computeExpectedNetUsd(lowInputs);
  const highValue = isCostDriver ? computeTokenCostUsd(highInputs) : computeExpectedNetUsd(highInputs);
  if (lowValue === null || highValue === null) {
    return { field, label, varyLabel, base: null, range: null, varyRange: null };
  }
  return {
    field,
    label,
    varyLabel,
    base,
    range: { low: Math.min(lowValue, highValue), high: Math.max(lowValue, highValue) },
    varyRange: { low: lowVary, high: highVary },
  };
}

export function computeEconomics(inputs) {
  const s = sanitizeInputs(inputs);
  const rawCost = rawTokenCostUsd(s);
  const rawGross = rawExpectedGrossUsd(s);
  const rawNet = rawCost !== null && rawGross !== null ? rawGross - rawCost : null;
  const reviewerMinutes = s.reviewerMinutes;
  const p = s.acceptanceProbability;
  const rawMinutes = reviewerMinutes === null || p === null || p <= 0 ? null : reviewerMinutes / p;
  const minutesPerExpectedAcceptance = rawMinutes !== null && Number.isFinite(rawMinutes) ? rawMinutes : null;
  const minutesOverflow = rawMinutes !== null && !Number.isFinite(rawMinutes);
  const overflowWarning =
    (rawCost !== null && !Number.isFinite(rawCost)) ||
    (rawGross !== null && !Number.isFinite(rawGross)) ||
    (rawNet !== null && !Number.isFinite(rawNet)) ||
    minutesOverflow;
  const tokenCostUsd = rawCost !== null && Number.isFinite(rawCost) ? rawCost : null;
  const expectedGrossUsd = rawGross !== null && Number.isFinite(rawGross) ? rawGross : null;
  const expectedNetUsd = rawNet !== null && Number.isFinite(rawNet) ? rawNet : null;
  const sensitivities = SENSITIVITY_STEPS.map(({ field, label, varyLabel }) =>
    buildSensitivity(s, field, label, varyLabel),
  );
  const zeroPriceWarning =
    (s.inputPricePerMillionUsd === 0 && s.inputTokens !== null && s.inputTokens > 0) ||
    (s.outputPricePerMillionUsd === 0 && s.outputTokens !== null && s.outputTokens > 0);
  return {
    tokenCostUsd,
    expectedGrossUsd,
    expectedNetUsd,
    breakEven: computeBreakEven(s),
    sensitivities,
    minutesPerExpectedAcceptance,
    zeroPriceWarning,
    overflowWarning,
  };
}

export function roundMoney(v) {
  return Math.round(v * 10_000) / 10_000;
}

export function formatUsd(v, opts = {}) {
  if (v === null || !Number.isFinite(v)) return "Unknown";
  if (v !== 0 && Math.abs(v) < 1e-9) {
    const sign = v < 0 ? "-" : opts.signed ? "+" : "";
    return `${sign}$${Math.abs(v).toExponential(3)}`;
  }
  if (v !== 0 && Math.abs(v) < 0.01) {
    return v.toLocaleString("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 9,
    });
  }
  // A finite float past 1e15 has no honest cent expansion. Keep it visible and non-finite-free.
  if (Math.abs(v) >= 1e15) {
    const sign = v < 0 ? "-" : opts.signed ? "+" : "";
    return `${sign}$${Math.abs(v).toExponential(3)}`;
  }
  const formatted = v.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  if (opts.signed && v > 0) return `+${formatted}`;
  return formatted;
}

export function formatNumber(v) {
  if (v === null || !Number.isFinite(v)) return "Unknown";
  return v.toLocaleString("en-US", { maximumFractionDigits: 6 });
}

export function formatPercent(v) {
  if (v === null || !Number.isFinite(v)) return "Unknown";
  return `${(v * 100).toLocaleString("en-US", { maximumFractionDigits: 2 })}%`;
}

function scientific(n) {
  const sign = n < 0 ? "-" : "";
  const exp = Math.abs(n)
    .toExponential(12)
    .replace(/(\.\d*?)0+e/, "$1e")
    .replace(/\.e/, "e");
  return sign + exp;
}

export function formatDecimal(n) {
  if (n === null || n === undefined) return null;
  if (!Number.isFinite(n)) return null;
  if (Object.is(n, -0) || n === 0) return "0";
  const abs = Math.abs(n);
  if (abs >= 1e15 || abs < 1e-12) return { scientific: scientific(n) };
  let text = abs.toFixed(12).replace(/0+$/, "").replace(/\.$/, "");
  if (text === "0") return { scientific: scientific(n) };
  return n < 0 ? `-${text}` : text;
}

function formatMoney(v, currency, opts = {}) {
  if (v === null || !Number.isFinite(v)) return "Unknown";
  if (currency !== "USD") {
    if (v === 0) return `0 ${currency}`;
    const dec = formatDecimal(v);
    const text = typeof dec === "string" ? dec : dec.scientific;
    const sign = opts.signed && v > 0 ? "+" : "";
    return `${sign}${text} ${currency}`;
  }
  return formatUsd(v, opts);
}

export function sampleInputs() {
  return {
    payoutUsd: 500,
    inputTokens: 120_000,
    outputTokens: 8_000,
    inputPricePerMillionUsd: 3,
    outputPricePerMillionUsd: 15,
    acceptanceProbability: 0.6,
    reviewerMinutes: 45,
  };
}

export function exportExplorerInputs(inputs) {
  const record = {};
  for (const key of FIELD_KEYS) record[key] = inputs[key];
  return JSON.stringify(
    {
      $schema: EXPLORER_EXPORT_URN,
      bountyEconomicsExplorerExport: true,
      version: EXPLORER_EXPORT_VERSION,
      inputs: record,
    },
    null,
    2,
  );
}

export const exportInputs = exportExplorerInputs;

function parseExplorerValue(data) {
  if (typeof data !== "object" || data === null || Array.isArray(data)) {
    return { ok: false, error: "Expected a JSON object" };
  }
  if (data.bountyEconomicsExplorerExport !== true) {
    return { ok: false, error: 'Missing "bountyEconomicsExplorerExport": true marker' };
  }
  if (data.version !== EXPLORER_EXPORT_VERSION) {
    return { ok: false, error: `Unsupported schema version: ${JSON.stringify(data.version)}` };
  }
  if (data.$schema !== undefined && data.$schema !== EXPLORER_EXPORT_URN) {
    return { ok: false, error: `Unrecognized $schema: ${JSON.stringify(data.$schema)}` };
  }
  const inputsRaw = data.inputs;
  if (typeof inputsRaw !== "object" || inputsRaw === null || Array.isArray(inputsRaw)) {
    return { ok: false, error: '"inputs" must be an object' };
  }
  const allowed = new Set(FIELD_KEYS);
  const extra = Object.keys(inputsRaw).filter((key) => !allowed.has(key));
  if (extra.length > 0) return { ok: false, error: `Unknown field(s): ${extra.join(", ")}` };
  const missing = FIELD_KEYS.filter((key) => !(key in inputsRaw));
  if (missing.length > 0) return { ok: false, error: `Missing field(s): ${missing.join(", ")}` };
  const inputs = { ...EMPTY };
  for (const key of FIELD_KEYS) {
    const raw = inputsRaw[key];
    if (typeof raw === "boolean" || (typeof raw === "object" && raw !== null)) {
      return { ok: false, error: `${key}: not a valid number` };
    }
    const parsed = key === "acceptanceProbability" ? parseBoundedNumber(raw, 0, 1) : parseOptionalNumber(raw);
    if (!parsed.ok) return { ok: false, error: `${key}: ${parsed.error}` };
    inputs[key] = parsed.value;
  }
  return { ok: true, value: inputs };
}

export function parseExplorerExport(raw) {
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    return { ok: false, error: "Not valid JSON" };
  }
  return parseExplorerValue(data);
}

export const parseImport = parseExplorerExport;

function plainObject(value, field) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    fail("sensitivity.object", `${field} must be a plain object`);
  }
  return value;
}

function exactKeys(obj, allowed, field, optional = []) {
  const known = new Set([...allowed, ...optional]);
  const extra = Object.keys(obj).filter((key) => !known.has(key));
  if (extra.length > 0) fail("sensitivity.extra", `${field} has unknown field(s): ${extra.join(", ")}`);
  const missing = allowed.filter((key) => !(key in obj));
  if (missing.length > 0) fail("sensitivity.missing", `${field} is missing field(s): ${missing.join(", ")}`);
}

function nativeNumber(raw, field) {
  if (typeof raw === "number") {
    fail("sensitivity.float", `${field} must be a decimal string (unknown is not 0)`);
  }
  let text;
  try {
    text = admitDecimal(raw, field);
  } catch (error) {
    if (error && error.code) throw error;
    fail("sensitivity.decimal", `${field} is not a decimal string`);
  }
  if (text === null) fail("sensitivity.decimal", `${field} is empty`);
  const n = Number(text);
  if (!Number.isFinite(n) || (n === 0 && text !== "0")) {
    return { overflow: true, n: null };
  }
  return { overflow: false, n };
}

function parseNative(data) {
  plainObject(data, "sensitivity input");
  exactKeys(data, ["schema", "label", "currency", "inputs"], "sensitivity input", ["variation"]);
  if (data.schema !== SENSITIVITY_INPUT_SCHEMA) {
    fail("sensitivity.schema", `schema must be ${SENSITIVITY_INPUT_SCHEMA}`);
  }
  if (!LABELS.has(data.label)) {
    fail("sensitivity.label", "label must be hypothetical, synthetic, or scenario");
  }
  if (!SETTLEMENT_UNITS.includes(data.currency)) {
    fail("sensitivity.currency", `currency must be one of ${SETTLEMENT_UNITS.join(", ")} and is a unit label, not a conversion`);
  }
  if (data.variation !== undefined && data.variation !== SENSITIVITY_VARIATION) {
    fail("sensitivity.variation", `variation must be ${SENSITIVITY_VARIATION} (±50%)`);
  }
  plainObject(data.inputs, "inputs");
  exactKeys(data.inputs, NATIVE_FIELDS.map(([name]) => name), "inputs");
  const inputs = { ...EMPTY };
  let overflowInput = false;
  const echoed = {};
  for (const [name, key, kind] of NATIVE_FIELDS) {
    const slot = plainObject(data.inputs[name], name);
    if (slot.kind === "unknown") {
      exactKeys(slot, ["kind"], name);
      echoed[name] = { kind: "unknown", value: null };
      continue;
    }
    if (!VALUE_KINDS.has(slot.kind)) {
      fail(
        "sensitivity.kind",
        `${name}.kind must be unknown, hypothetical, synthetic, or scenario (not measured, and not a review)`,
      );
    }
    exactKeys(slot, ["kind", "value"], name);
    const parsed = nativeNumber(slot.value, `${name}.value`);
    if (parsed.overflow) {
      overflowInput = true;
      echoed[name] = { kind: slot.kind, value: null, overflow: true };
      continue;
    }
    if (key === "acceptanceProbability" && parsed.n > 1) {
      fail("sensitivity.probability", `${name} must be between 0 and 1`);
    }
    inputs[key] = parsed.n;
    echoed[name] = { kind: slot.kind, value: slot.value };
  }
  return {
    inputSchema: SENSITIVITY_INPUT_SCHEMA,
    label: data.label,
    currency: data.currency,
    inputs,
    echoed,
    overflowInput,
  };
}

function fieldUnit(field, currency) {
  if (field === "payoutUsd") return currency;
  if (field === "acceptanceProbability") return "probability";
  if (field === "inputPricePerMillionUsd" || field === "outputPricePerMillionUsd") return `${currency}/1e6 tokens`;
  if (field === "inputTokens" || field === "outputTokens") return "token";
  if (field === "reviewerMinutes") return "minute";
  return null;
}

function quantityFromNumber(n, unit, { signed = false, money = false } = {}) {
  if (n === null || !Number.isFinite(n)) {
    return {
      kind: "unknown",
      value: null,
      unit,
      status: "missing",
      verified: false,
      display: money ? formatMoney(null, unit) : "Unknown",
    };
  }
  const dec = formatDecimal(n);
  const scientificForm = typeof dec === "object";
  return {
    kind: "derived",
    value: scientificForm ? dec.scientific : dec,
    unit,
    status: "estimated",
    representation: scientificForm ? "finite-ieee754-scientific" : "decimal",
    // Decimal formatting does not make IEEE-754 calculations exact.
    exactDecimal: false,
    verified: false,
    display: money ? formatMoney(n, unit === "USD" || SETTLEMENT_UNITS.includes(unit) ? unit : "USD", { signed }) : formatNumber(n),
  };
}

function breakEvenQuantity(breakEven, currency) {
  if (breakEven.value === null && breakEven.reachable === false) {
    return {
      kind: "unknown",
      value: null,
      unit: currency,
      reachable: false,
      status: "missing",
      verified: false,
      display: "Not reachable",
      reason: "no finite payout breaks even at this acceptance probability",
    };
  }
  const q = quantityFromNumber(breakEven.value, currency, { money: true });
  return { ...q, reachable: breakEven.reachable === true };
}

function sensitivityQuantities(row, currency) {
  const metricUnit = currency;
  const varyUnit = fieldUnit(row.field, currency);
  return {
    field: row.field,
    varyLabel: row.varyLabel,
    metric: row.label,
    base: row.base === null ? { kind: "unknown", value: null, unit: varyUnit, status: "missing", verified: false } : quantityFromNumber(row.base, varyUnit),
    varyRange: row.varyRange
      ? {
          low: quantityFromNumber(row.varyRange.low, varyUnit).value,
          high: quantityFromNumber(row.varyRange.high, varyUnit).value,
          unit: varyUnit,
        }
      : null,
    range: row.range
      ? {
          low: quantityFromNumber(row.range.low, metricUnit, { money: true }).value,
          high: quantityFromNumber(row.range.high, metricUnit, { money: true }).value,
          unit: metricUnit,
          lowDisplay: formatMoney(row.range.low, currency),
          highDisplay: formatMoney(row.range.high, currency),
        }
      : null,
  };
}

function usageBlock() {
  return {
    cli: "node experiments/bounty-economics-20260912/bin/bounty-economics.mjs sensitivity --input FILE [--out DIR]",
    inputSchemas: [SENSITIVITY_INPUT_SCHEMA, EXPLORER_EXPORT_URN],
    outputSchema: SENSITIVITY_OUTPUT_SCHEMA,
    contract: "experiments/bounty-economics-20260912/SENSITIVITY-CONTRACT.json",
    doesNotReplace: CARD_SCHEMA,
  };
}

function buildOutput(parsed, economics) {
  const currency = parsed.currency;
  const overflowWarning = economics.overflowWarning === true || parsed.overflowInput === true;
  return {
    schema: SENSITIVITY_OUTPUT_SCHEMA,
    role: "one-factor-attempt-sensitivity",
    doesNotReplace: CARD_SCHEMA,
    formula: {
      id: "forge-f01-attempt-sensitivity-2026-09-22",
      expression: "expectedNet = payout * acceptanceProbability - (inputTokens + outputTokens priced per million)",
      variation: SENSITIVITY_VARIATION,
      stagedEv: "not this object",
      cardSchema: CARD_SCHEMA,
      cardFormula: FORMULA_VERSION,
    },
    source: FORGE_F01_SOURCE,
    usage: usageBlock(),
    inputSchema: parsed.inputSchema,
    label: parsed.label,
    currency,
    variation: SENSITIVITY_VARIATION,
    modeled: true,
    actualEarnings: null,
    observedDemand: false,
    payment: false,
    settlementImplied: false,
    currencyParity: false,
    rating: null,
    independentlyVerifiedByThisPack: false,
    explorerInputs: parsed.inputs,
    inputs: parsed.echoed,
    result: {
      tokenCost: quantityFromNumber(economics.tokenCostUsd, currency, { money: true }),
      expectedGross: quantityFromNumber(economics.expectedGrossUsd, currency, { money: true }),
      expectedNet: quantityFromNumber(economics.expectedNetUsd, currency, { money: true, signed: true }),
      breakEvenPayout: breakEvenQuantity(economics.breakEven, currency),
      minutesPerExpectedAcceptance: {
        ...quantityFromNumber(economics.minutesPerExpectedAcceptance, "minute"),
        display: economics.minutesPerExpectedAcceptance === null
          ? "Unknown"
          : `${formatNumber(economics.minutesPerExpectedAcceptance)} min`,
        monetized: false,
      },
      reviewerMinutes: {
        ...quantityFromNumber(parsed.inputs.reviewerMinutes, "minute"),
        display: parsed.inputs.reviewerMinutes === null ? "Unknown" : `${formatNumber(parsed.inputs.reviewerMinutes)} min`,
        monetized: false,
      },
      acceptanceProbability: {
        ...quantityFromNumber(parsed.inputs.acceptanceProbability, "probability"),
        display: formatPercent(parsed.inputs.acceptanceProbability),
      },
      zeroPriceWarning: economics.zeroPriceWarning === true,
      overflowWarning,
    },
    sensitivities: economics.sensitivities.map((row) => sensitivityQuantities(row, currency)),
    notes: NOTES,
  };
}

function echoedFromExplorer(inputs) {
  const echoed = {};
  for (const [name, key] of NATIVE_FIELDS) {
    const value = inputs[key];
    if (value === null) echoed[name] = { kind: "unknown", value: null };
    else {
      const dec = formatDecimal(value);
      echoed[name] = {
        kind: "hypothetical",
        value: dec === null ? null : typeof dec === "string" ? dec : dec.scientific,
      };
    }
  }
  return echoed;
}

export function evaluateSensitivity(input) {
  const data = typeof input === "string" ? parseBoundedJson(input, "sensitivity") : input;
  if (data && typeof data === "object" && !Array.isArray(data) && data.bountyEconomicsExplorerExport === true) {
    const parsed = parseExplorerValue(data);
    if (!parsed.ok) fail("sensitivity.import", parsed.error);
    const economics = computeEconomics(parsed.value);
    return buildOutput(
      {
        inputSchema: EXPLORER_EXPORT_URN,
        label: "hypothetical",
        currency: "USD",
        inputs: parsed.value,
        echoed: echoedFromExplorer(parsed.value),
        overflowInput: false,
      },
      economics,
    );
  }
  const native = parseNative(data);
  const economics = computeEconomics(native.inputs);
  if (native.overflowInput) economics.overflowWarning = true;
  return buildOutput(native, economics);
}

export function sensitivityContract() {
  return {
    schema: SENSITIVITY_CONTRACT_SCHEMA,
    outputSchema: SENSITIVITY_OUTPUT_SCHEMA,
    inputSchemas: [SENSITIVITY_INPUT_SCHEMA, EXPLORER_EXPORT_URN],
    doesNotReplace: CARD_SCHEMA,
    formula: "forge-f01-attempt-sensitivity-2026-09-22",
    stagedFormulaUnchanged: FORMULA_VERSION,
    source: FORGE_F01_SOURCE,
    receiving: {
      repository: "epistemedeus/neomorphic-io",
      path: "experiments/bounty-economics-20260912",
      cli: "node bin/bounty-economics.mjs sensitivity --input FILE [--out DIR]",
    },
    usage: {
      canonicalExample: "examples/sensitivity/synthetic-attempt.input.json",
      compatibilityExample: "examples/sensitivity/synthetic-attempt.explorer.json",
      publicSpecimen: "/labs/bounty-economics-preview/sensitivity/synthetic.html",
      publicContract: "/labs/bounty-economics-preview/sensitivity/CONTRACT.json",
      publicOutput: "/labs/bounty-economics-preview/sensitivity/synthetic.json",
      publicNativeInput: "/labs/bounty-economics-preview/sensitivity/input.native.json",
      publicExplorerInput: "/labs/bounty-economics-preview/sensitivity/input.explorer.json",
    },
    guarantees: [
      "Unknown is not zero.",
      "Modeled economics are not actual earnings.",
      "No token prices are invented.",
      "No currency parity and no settlement instruction.",
      "No default review.",
      "Reviewer minutes are not monetized.",
      "Not paid demand and not a listing.",
      "Overflow renders as unknown plus a visible warning, never Infinity.",
    ],
    observedDemand: false,
    payment: false,
    actualEarnings: null,
    rating: null,
  };
}

function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

export function renderOverflowNotice(active) {
  if (!active) return "";
  return `<p role="alert">These inputs exceed the calculator's numeric range. Affected results are unknown, not zero. Reduce the values before using this estimate.</p>`;
}

function row(label, value) {
  return `<tr><th>${esc(label)}</th><td>${value}</td></tr>`;
}

export function renderSensitivityHtml(doc, links = {}) {
  if (!doc || doc.schema !== SENSITIVITY_OUTPUT_SCHEMA) {
    fail("sensitivity.render", "renderSensitivityHtml requires a sensitivity output document");
  }
  const result = doc.result;
  const overflow = renderOverflowNotice(result.overflowWarning === true);
  const zero = result.zeroPriceWarning
    ? `<p role="note"><strong>Promotional tokens detected.</strong> A token price of zero is treated as zero cash cost, but promotional, trial, or included credits are not genuinely free. Treat the modeled net as an overestimate.</p>`
    : "";
  const sense = (doc.sensitivities ?? []).map((item) => {
    const range = item.range
      ? `${esc(item.range.lowDisplay)} – ${esc(item.range.highDisplay)}`
      : `<span class="unknown">Unknown — fill all related inputs to see a range.</span>`;
    const varied = item.varyRange
      ? `${esc(item.varyRange.low)} … ${esc(item.varyRange.high)}`
      : "Unknown";
    return `<section><h3>${esc(item.varyLabel)} <small>→ ${esc(item.metric)}</small></h3><p>varied range: ${varied}</p><p>${range}</p></section>`;
  }).join("");
  const downloads = [
    links.jsonHref ? `<a href="${esc(links.jsonHref)}">sensitivity JSON</a>` : "",
    links.contractHref ? `<a href="${esc(links.contractHref)}">contract</a>` : "",
    links.nativeHref ? `<a href="${esc(links.nativeHref)}">native input</a>` : "",
    links.explorerHref ? `<a href="${esc(links.explorerHref)}">explorer input</a>` : "",
  ].filter(Boolean).join(" · ");
  const pageUrl = typeof links.pageUrl === "string" ? links.pageUrl : "";
  const social = pageUrl
    ? `<meta property="og:type" content="website">
  <meta property="og:site_name" content="Neomorphic">
  <meta property="og:title" content="Synthetic attempt sensitivity — not a listing">
  <meta property="og:description" content="Synthetic modeled attempt sensitivity. Not open jobs, not actual earnings, and not staged wallet EV.">
  <meta property="og:url" content="${esc(pageUrl)}">
  <meta property="og:image" content="https://neomorphic.io/apple-touch-icon.png">
  <meta name="twitter:card" content="summary">
  <script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://neomorphic.io/#organization","name":"Neomorphic","legalName":"Neomorphic LLC"},{"@type":"WebSite","@id":"https://neomorphic.io/#website","url":"https://neomorphic.io/"},{"@type":"WebPage","@id":"${esc(pageUrl)}","url":"${esc(pageUrl)}","isPartOf":{"@id":"https://neomorphic.io/#website"},"name":"Synthetic attempt sensitivity — not a listing","description":"Synthetic modeled attempt sensitivity. Not open jobs, not actual earnings, and not staged wallet EV."}]}</script>
  `
    : "";
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title>Synthetic attempt sensitivity — not a listing</title>
  <meta name="description" content="Synthetic modeled attempt sensitivity. Not open jobs, not actual earnings, and not staged wallet EV.">
  ${social}<style>
    :root { color-scheme: light dark; --ink: #1b1b18; --muted: #5c5c56; --line: #d4d0c8; --bg: #f7f4ee; --card: #fffdf8; --unknown: #7a4d00; }
    @media (prefers-color-scheme: dark) {
      :root { --ink: #f3efe6; --muted: #b4aea2; --line: #3f3c36; --bg: #161513; --card: #1e1c19; --unknown: #f0c674; }
    }
    body { margin: 0; font: 15px/1.45 ui-sans-serif, system-ui, sans-serif; background: var(--bg); color: var(--ink); }
    main { max-width: 52rem; margin: 1.5rem auto; padding: 1.25rem 1.5rem 2rem; background: var(--card); border: 1px solid var(--line); }
    h1 { font-family: ui-serif, Georgia, serif; font-size: 1.45rem; margin: 0 0 .4rem; }
    h2 { font-size: .95rem; letter-spacing: .04em; text-transform: uppercase; margin: 1.4rem 0 .4rem; }
    .banner, .alert { border: 1px solid var(--line); padding: .6rem .75rem; margin: .75rem 0 1rem; }
    .unknown { color: var(--unknown); font-style: italic; }
    table { width: 100%; border-collapse: collapse; font-variant-numeric: tabular-nums; }
    th, td { text-align: left; padding: .35rem .4rem; border-bottom: 1px solid var(--line); vertical-align: top; }
    th { width: 46%; font-weight: 600; }
    small, .meta, footer { color: var(--muted); }
    a { color: inherit; }
    section { margin: .7rem 0; padding-bottom: .45rem; border-bottom: 1px solid var(--line); }
    h3 { font-size: 1rem; margin: 0; }
  </style>
</head>
<body>
<main>
  <h1>Attempt sensitivity <small>(${esc(doc.label)})</small></h1>
  <p class="banner"><strong>Synthetic model. Not an observed case and not open jobs.</strong> Not actual earnings. Not staged wallet EV. Not paid demand. No bids or payments. Unknown is not zero. No currency conversion.</p>
  <p class="meta">schema ${esc(doc.schema)} · input ${esc(doc.inputSchema)} · does not replace ${esc(doc.doesNotReplace)} · source ${esc(doc.source.repository)}@${esc(doc.source.commit)} · ${esc(doc.source.path)}</p>
  ${downloads ? `<p class="meta">${downloads}</p>` : ""}
  ${overflow || zero ? `<div class="alert">${overflow}${zero}</div>` : ""}
  <h2>Money (modeled)</h2>
  <table>
    ${row("Token cost", esc(result.tokenCost.display))}
    ${row("Expected gross reward", esc(result.expectedGross.display))}
    ${row("Expected net reward", esc(result.expectedNet.display))}
    ${row("Break-even payout", esc(result.breakEvenPayout.display))}
  </table>
  <h2>Learning, reuse and effort</h2>
  <p>Not converted to money. Reviewer minutes never silently inflate the net reward.</p>
  <table>
    ${row("Reviewer minutes per expected acceptance", esc(result.minutesPerExpectedAcceptance.display))}
    ${row("Minutes entered per attempt", esc(result.reviewerMinutes.display))}
    ${row("Acceptance probability", esc(result.acceptanceProbability.display ?? "Unknown"))}
  </table>
  <h2>Sensitivity ranges</h2>
  <p>Each row varies one input by ±50% (acceptance probability clamped to 0–1) and shows how the modeled result moves.</p>
  ${sense}
  <h2>What this is not</h2>
  <ul>
    ${(doc.notes ?? []).map((note) => `<li>${esc(note)}</li>`).join("")}
  </ul>
  <footer>forge-f01-attempt-sensitivity-2026-09-22 · modeled · actualEarnings null · rating null · payment false · ${esc(doc.source.commit)}</footer>
</main>
</body>
</html>
`;
}
