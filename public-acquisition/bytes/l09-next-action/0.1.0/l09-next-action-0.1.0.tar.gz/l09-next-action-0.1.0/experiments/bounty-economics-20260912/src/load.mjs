import { readFileSync, statSync } from "node:fs";
import { MAX_INPUT_BYTES, MAX_JSON_DEPTH, MAX_JSON_NODES } from "./constants.mjs";
import { fail } from "./errors.mjs";

const HOSTILE = new Set(["__proto__", "constructor", "prototype"]);

export function readBoundedJson(path, { maxBytes = MAX_INPUT_BYTES } = {}) {
  let st;
  try {
    st = statSync(path);
  } catch {
    fail("io.missing", `missing file ${path}`);
  }
  if (!st.isFile()) fail("io.not_file", `${path} is not a file`);
  if (st.size > maxBytes) fail("io.oversized", `${path} is ${st.size} bytes, above ${maxBytes}`);
  const buf = readFileSync(path);
  if (buf.length > maxBytes) fail("io.oversized", `${path} read ${buf.length} bytes, above ${maxBytes}`);
  return parseBoundedJson(buf.toString("utf8"), path);
}

export function parseBoundedJson(text, field = "json") {
  let value;
  try {
    value = JSON.parse(text, (key, v) => {
      if (HOSTILE.has(key)) fail("json.hostile", `${field} contains hostile key ${key}`);
      return v;
    });
  } catch (error) {
    if (error.code) throw error;
    fail("json.parse", `${field} is not JSON`);
  }
  countNodes(value, field);
  return value;
}

function countNodes(value, field, depth = 0, state = { n: 0 }) {
  if (depth > MAX_JSON_DEPTH) fail("json.depth", `${field} exceeds max depth ${MAX_JSON_DEPTH}`);
  state.n += 1;
  if (state.n > MAX_JSON_NODES) fail("json.nodes", `${field} exceeds max nodes ${MAX_JSON_NODES}`);
  if (value && typeof value === "object") {
    for (const [k, v] of Object.entries(value)) {
      if (HOSTILE.has(k)) fail("json.hostile", `${field} contains hostile key ${k}`);
      countNodes(v, field, depth + 1, state);
    }
  }
  return state.n;
}
