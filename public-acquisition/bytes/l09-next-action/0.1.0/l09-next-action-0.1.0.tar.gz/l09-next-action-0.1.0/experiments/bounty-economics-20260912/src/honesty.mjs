import { fail } from "./errors.mjs";
import { isUnknown } from "./quantity.mjs";

export function assertSampleIsNotPA(input) {
  const cohort = input.probabilities?.cohort ?? input.cohort;
  if (cohort && cohort.wins != null && cohort.bids != null && cohort.notCalibratedPA !== true) {
    fail("honesty.sample_pa", "a win/bid sample must set notCalibratedPA true; it is not pA");
  }
  const pA = input.probabilities?.pA ?? input.pA;
  const empirical = input.pAFromSample === true
    || pA?.fromCohort === true
    || pA?.source === "cohort"
    || pA?.basis === "cohort";
  if (empirical) {
    fail("honesty.cohort_pa", "cohort wins/bids cannot be promoted to calibrated pA");
  }
  if (pA && !isUnknown(pA) && pA.kind === "estimate") {
    if (!pA.basis || !(pA.date || pA.asOf) || !(pA.route || pA.sample)) {
      fail("honesty.estimate_basis", "estimate pA needs basis, date, and route or sample");
    }
  }
}

export function assertUnknownNotZero(q, field) {
  if (q && q.kind === "unknown" && q.value != null) {
    fail("honesty.unknown_value", `${field} unknown carried a value`);
  }
}

export function assertNetNotProfit(card) {
  if (card.wallet?.label === "expected_profit_not_net") return;
  if (card.wallet?.W && card.wallet?.W.label === "profit") {
    fail("honesty.net_vs_profit", "W is net wallet after fees, not profit");
  }
}

export function assertNoLossCause(input) {
  if (input.lossCause || input.whyLost || input.contentQualityVerdict) {
    fail("honesty.loss_cause", "do not assert why losses occurred; content quality is a hypothesis");
  }
}

export function assertNotAllGrokObserved(input) {
  if (input.allGrokRangeObserved === true) {
    fail("honesty.all_grok", "an all-Grok session range is hypothetical, not observed Pilot cost");
  }
  const blob = JSON.stringify(input.tokens ?? {});
  if (/all-?grok/i.test(blob) && /"kind":"measured"/.test(blob)) {
    fail("honesty.all_grok", "do not label an all-Grok range as measured");
  }
}

export function honestyNotes(input) {
  return [
    "Unknown is not zero.",
    "Operator-supplied and claimed-platform figures are not verified.",
    "Net wallet W is after fees and before stage costs; EV is expected profit under staged conditionals.",
    "A 2/5 same-buyer selected sample is a cohort description, not calibrated pA.",
    "Content quality as a cause of loss is a hypothesis, not a finding of this pack.",
  ];
}
