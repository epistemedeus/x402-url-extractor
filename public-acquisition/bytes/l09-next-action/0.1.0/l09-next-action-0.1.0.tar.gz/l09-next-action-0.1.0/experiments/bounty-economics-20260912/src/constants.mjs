export const INPUT_SCHEMA = "h10.bounty-economics.input.v1";
export const CARD_SCHEMA = "h10.bounty-economics.card.v1";
export const SENSITIVITY_INPUT_SCHEMA = "h10.bounty-economics.sensitivity.input.v1";
export const SENSITIVITY_OUTPUT_SCHEMA = "h10.bounty-economics.sensitivity.output.v1";
export const SENSITIVITY_CONTRACT_SCHEMA = "h10.bounty-economics.sensitivity.contract.v1";
export const EXPLORER_EXPORT_URN = "urn:bounty-economics-explorer:export:v1";
export const EXPLORER_EXPORT_VERSION = 1;
export const SENSITIVITY_VARIATION = "0.5";
export const PINS_SCHEMA = "h10.bounty-economics.pins.v1";
export const DECK_SCHEMA = "h10.bounty-economics.deck.v1";
export const DECISION_SCHEMA = "h10.bounty-economics.decision.v1";
export const FORMULA_VERSION = "sol-pro-staged-ev-2026-09-12";
export const SOL_PRO_PIN = Object.freeze({
  commit: "56122f4ceb1e637c113a181fdd0fffbc39c1e392",
  path: "overview/self-evaluations/2026-09-12-revenue-economics/SOL-PRO-REVIEW.md",
  blob: "e4d4c068864fca7b803d2ec160b2a715385e63d4",
});

export const MAX_INPUT_BYTES = 262_144;
export const MAX_JSON_DEPTH = 12;
export const MAX_JSON_NODES = 4_096;
export const MAX_INTERVAL_DIMS = 12;
export const MONEY_SCALE = 12n;

export const QUANTITY_KINDS = Object.freeze([
  "unknown",
  "not_applicable",
  "hypothetical",
  "operator_supplied",
  "claimed_platform",
  "scenario",
  "estimate",
  "derived",
  "measured",
]);

export const QUANTITY_STATUS = Object.freeze([
  "observed",
  "estimated",
  "missing",
  "not_applicable",
]);

export const CARD_LABELS = Object.freeze([
  "observed-operator-case",
  "synthetic",
  "hypothetical",
]);

export const EVIDENCE_STAGES = Object.freeze([
  "advertised",
  "bid",
  "awarded",
  "delivered",
  "approved",
  "settled",
  "liquid",
]);

export const CRITICAL_EV_FIELDS = Object.freeze([
  "pA",
  "pD",
  "pQ",
  "pS",
  "W",
  "C0",
  "C1",
  "C2",
  "C3",
]);

export const TOKEN_SLOTS = Object.freeze([
  "inputUncached",
  "inputCached",
  "output",
  "reasoning",
]);

export const COST_PLANES = Object.freeze([
  "cash",
  "apiPriceEquivalent",
  "subscriptionAllocation",
]);

export const DECISION_COST_PLANES = Object.freeze([
  "cash",
  "list",
  "subscription",
  "custom-economic",
]);

export const INTERVAL_DIMENSIONS = Object.freeze([
  "G",
  "f",
  "F",
  "pA",
  "pD",
  "pQ",
  "pS",
  "C0",
  "C1",
  "C2",
  "C3",
]);

export const SETTLEMENT_UNITS = Object.freeze(["USD", "USDC"]);
export const REASONING_METERS = Object.freeze(["included_in_output", "separate_meter"]);

export const RATING_DIMENSIONS = Object.freeze([
  "evidence_quality",
  "settlement_reliability",
  "estimated_economics",
  "discovery_friction",
]);

export const RATING_LEVELS = Object.freeze([
  "unknown",
  "weak",
  "moderate",
  "strong",
]);

export const CW04_PIN = Object.freeze({
  commit: "ec9695b2a851a879bfd1efc22d4c8372b314677e",
  path: "experiments/codex-window/cw04-bounty-experiences",
  note: "CW19 hardened provenance. Interface pin only; this pack does not rewrite CW04.",
  blobs: Object.freeze({
    "package.json": "c78a437ede2b1e916b6e4df265dcc3976dd5b9b0",
    "src/project.mjs": "a4807e2eb7aa3ec64e7734edfd82de70ee76dcfe",
    "src/source.mjs": "17561136cf094bdfbade85c0c934c2bc94bf2f68",
    "src/source-pins.mjs": "c1f76a452a835fad1bad3d2396354bde37436391",
    "bin/project.mjs": "4794fefe9672888e1bf2406714ce67fb58bb85fb",
    "README": "b561fcd25ed575e64c605fb1f200909cf31a1704",
    // MCP-verified path is README, not README.md.
  }),
});

export const H8_PIN = Object.freeze({
  commit: "4d96afc",
  path: "experiments/steady-agent-opportunities-20260912",
  note: "Optional pure classifier only. This pack does not amend H8. Corrected candidate 1a556aae (41/41) is not imported; no H8 HTTP/stream transport.",
  blobs: Object.freeze({
    "lib/classify.mjs": "2dce41c2f2c665155d871b9249f58da604700a18",
    "lib/labels.mjs": "b626bba974fe124f8e2d8e7a8436c4eecd91d9eb",
  }),
});

export const PILOT_MAIN_PIN = Object.freeze({
  commit: "87a6f4db",
  economics: "experiments/revenue-swarm-0907/c2/src/economics.mjs",
  effort: "overview/research/11-agent-effort-arbitrage-economics-2026-08-08.md",
  aggregation: "overview/research/10-bounty-aggregation-market-map-2026-08-08.md",
});
