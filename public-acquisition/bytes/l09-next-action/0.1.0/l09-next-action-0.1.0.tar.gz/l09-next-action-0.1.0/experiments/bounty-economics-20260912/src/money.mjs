import { MONEY_SCALE } from "./constants.mjs";
import { fail } from "./errors.mjs";

const ATOMIC = /^(0|[1-9]\d*)(\.\d+)?$/;
const SIGNED = /^-?(0|[1-9]\d*)(\.\d+)?$/;

function rejectHostileNumber(value, field) {
  if (typeof value === "number") {
    if (Number.isNaN(value)) fail("money.nan", `${field} is NaN`);
    if (!Number.isFinite(value)) fail("money.nonfinite", `${field} is not finite`);
  }
}

export function parseDecimalString(raw, field, { allowNegative = false } = {}) {
  if (typeof raw !== "string") fail("money.type", `${field} must be a decimal string`);
  const text = raw.trim();
  if (text === "") fail("money.empty", `${field} is empty`);
  if (text.startsWith("-") && !allowNegative) fail("money.negative", `${field} must be non-negative`);
  const pattern = allowNegative ? SIGNED : ATOMIC;
  if (!pattern.test(text)) fail("money.format", `${field} is not a decimal string`);
  return text;
}

/**
 * Admit money/rate values. IEEE floats are rejected so 2.85 cannot silently
 * become 2.84999… . Safe integers are accepted. Everything else must be a
 * decimal string.
 */
export function admitDecimal(value, field, { allowNegative = false } = {}) {
  rejectHostileNumber(value, field);
  if (value === null || value === undefined) return null;
  if (typeof value === "boolean" || typeof value === "object") {
    fail("money.type", `${field} must be a decimal string or safe integer`);
  }
  if (typeof value === "number") {
    if (!Number.isSafeInteger(value)) {
      fail(
        "money.float_rejected",
        `${field} is an IEEE float; use a decimal string (unknown is not 0)`,
      );
    }
    if (!allowNegative && value < 0) fail("money.negative", `${field} must be non-negative`);
    return String(value);
  }
  return parseDecimalString(value, field, { allowNegative });
}

export function toScaled(value, field, opts = {}) {
  const s = admitDecimal(value, field, opts);
  if (s === null) return null;
  const neg = s.startsWith("-");
  const mag = neg ? s.slice(1) : s;
  const [w, f = ""] = mag.split(".");
  if (BigInt(f.length) > MONEY_SCALE) {
    fail("money.scale", `${field} has more than ${MONEY_SCALE} decimal places`);
  }
  const frac = (f + "0".repeat(Number(MONEY_SCALE))).slice(0, Number(MONEY_SCALE));
  const n = BigInt(w) * 10n ** MONEY_SCALE + BigInt(frac);
  return neg ? -n : n;
}

export function fromScaled(n) {
  if (typeof n !== "bigint") fail("money.internal", "fromScaled requires bigint");
  const neg = n < 0n;
  const v = neg ? -n : n;
  const scale = 10n ** MONEY_SCALE;
  const w = v / scale;
  const f = (v % scale).toString().padStart(Number(MONEY_SCALE), "0").replace(/0+$/, "");
  const s = f ? `${w.toString()}.${f}` : w.toString();
  return neg ? `-${s}` : s;
}

export function add(a, b, field = "sum") {
  const x = toScaled(a, `${field}.a`, { allowNegative: true });
  const y = toScaled(b, `${field}.b`, { allowNegative: true });
  if (x === null || y === null) return null;
  return fromScaled(x + y);
}

export function sub(a, b, field = "difference") {
  const x = toScaled(a, `${field}.a`, { allowNegative: true });
  const y = toScaled(b, `${field}.b`, { allowNegative: true });
  if (x === null || y === null) return null;
  return fromScaled(x - y);
}

export function mul(a, b, field = "product") {
  const x = toScaled(a, `${field}.a`, { allowNegative: true });
  const y = toScaled(b, `${field}.b`, { allowNegative: true });
  if (x === null || y === null) return null;
  return fromScaled((x * y) / 10n ** MONEY_SCALE);
}

export function div(a, b, field = "quotient") {
  const x = toScaled(a, `${field}.a`, { allowNegative: true });
  const y = toScaled(b, `${field}.b`, { allowNegative: true });
  if (x === null || y === null) return null;
  if (y === 0n) fail("money.divzero", `${field} division by zero`);
  return fromScaled((x * 10n ** MONEY_SCALE) / y);
}

export function cmp(a, b) {
  const x = toScaled(a, "cmp.a", { allowNegative: true });
  const y = toScaled(b, "cmp.b", { allowNegative: true });
  if (x === null || y === null) return null;
  if (x < y) return -1;
  if (x > y) return 1;
  return 0;
}

export function isZero(value) {
  const n = toScaled(value, "zero", { allowNegative: true });
  return n === 0n;
}

export function inUnitInterval(value, field) {
  const n = toScaled(value, field);
  if (n === null) return false;
  const one = 10n ** MONEY_SCALE;
  return n >= 0n && n <= one;
}

export function assertUnitInterval(value, field) {
  if (!inUnitInterval(value, field)) {
    fail("money.unit_interval", `${field} must be a decimal in [0, 1]`);
  }
  return admitDecimal(value, field);
}
