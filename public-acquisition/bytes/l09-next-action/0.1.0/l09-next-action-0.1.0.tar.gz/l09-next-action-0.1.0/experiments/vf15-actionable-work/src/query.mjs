/**
 * Cold-client answer. Reads a published document and returns its action.
 * Does not import adapters, fetch, or the discovery functions.
 */
import { ANSWER_SCHEMA, QUESTION } from "./constants.mjs";
import { validateDocument } from "./validate.mjs";

export function answerNextAction(artifact, { question = QUESTION } = {}) {
  if (question !== QUESTION) {
    const error = new Error("unsupported question");
    error.code = "usage";
    throw error;
  }
  const errors = validateDocument(artifact);
  if (errors.length) {
    const error = new Error(errors.join("; "));
    error.code = "artifact_unreadable";
    throw error;
  }
  return {
    schema: ANSWER_SCHEMA,
    question,
    deterministic: true,
    readFrom: "published_artifact_only",
    qualified: artifact.qualified,
    action: artifact.action,
    refusal: artifact.refusal,
    provenance: artifact.provenance,
    confidence: artifact.confidence,
    catalogBridge: artifact.catalogBridge,
    limits: artifact.limits,
  };
}

export function answerJson(answer) {
  return `${JSON.stringify(answer, null, 2)}\n`;
}
