import { getAdapter } from "./adapters/index.mjs";
import { catalogBridge } from "./catalog-bridge.mjs";
import {
  AGENT_MAY,
  AGENT_MUST_NOT,
  COMMON_LIMITS,
  DOCUMENT_SCHEMA,
  EXIT,
  QUESTION,
  RANK_POLICY,
} from "./constants.mjs";
import { isIsoZ } from "./text.mjs";
import { validateDocument } from "./validate.mjs";

export function dropReason(item) {
  if (item.reason) return item.reason;
  if (item.isPullRequest) return "pull_request";
  if (item.state === "closed") return "closed";
  if (item.state !== "open") return "unknown_state";
  if (!item.itemUrl) return "missing_url";
  if (!item.title) return "missing_title";
  if (!item.nativeId) return "unrecognized_locator";
  return null;
}

export function compareItems(a, b) {
  if (a.preferred !== b.preferred) return a.preferred ? -1 : 1;
  if (a.updatedAt !== b.updatedAt) {
    if (a.updatedAt == null) return 1;
    if (b.updatedAt == null) return -1;
    if (a.updatedAt < b.updatedAt) return 1;
    if (a.updatedAt > b.updatedAt) return -1;
  }
  if (a.nativeId < b.nativeId) return -1;
  if (a.nativeId > b.nativeId) return 1;
  return 0;
}

export function selectItem(items) {
  const dropped = [];
  const eligible = [];
  for (const item of items) {
    const reason = dropReason(item);
    if (reason) dropped.push({ nativeId: item.nativeId, reason });
    else eligible.push(item);
  }
  eligible.sort(compareItems);
  const seen = new Set();
  const unique = [];
  for (const item of eligible) {
    if (seen.has(item.nativeId)) {
      dropped.push({ nativeId: item.nativeId, reason: "duplicate" });
      continue;
    }
    seen.add(item.nativeId);
    unique.push(item);
  }
  return { selected: unique[0] ?? null, dropped };
}

function limitsBlock() {
  return {
    claimAuthority: "none",
    paymentAuthority: "none",
    safeToStartWork: false,
    ledger: false,
    offer: false,
    publicListingIsNotClaimPermission: true,
  };
}

function confidenceBlock(level, extra) {
  return {
    level,
    limits: [...extra, ...COMMON_LIMITS],
  };
}

function actionFrom(item, provenance) {
  return {
    kind: "read_public_record",
    method: "GET",
    url: item.itemUrl,
    nativeId: item.nativeId,
    title: item.title,
    state: item.state,
    sourceId: provenance.sourceId,
    adapterId: provenance.adapterId,
    agentMay: [...AGENT_MAY],
    agentMustNot: [...AGENT_MUST_NOT],
  };
}

function assertPublicAction(action, adapter) {
  let url;
  try {
    url = new URL(action.url);
  } catch {
    const error = new Error("selected action URL is not usable");
    error.code = "internal";
    throw error;
  }
  if (url.protocol !== "https:" || !adapter.itemHosts.includes(url.hostname)) {
    const error = new Error("selected action URL is outside the adapter host");
    error.code = "internal";
    throw error;
  }
}

export function seal(discovered, adapter) {
  const provenance = discovered.provenance;
  const extraLimits = discovered.confidenceLimits;
  if (!discovered.ok) {
    return finish({
      schema: DOCUMENT_SCHEMA,
      qualified: false,
      question: QUESTION,
      action: null,
      refusal: discovered.refusal,
      selection: {
        policy: RANK_POLICY,
        considered: 0,
        selectedNativeId: null,
        dropped: [],
      },
      provenance,
      confidence: confidenceBlock("none", extraLimits),
      catalogBridge: catalogBridge({
        qualified: false,
        refusalCode: discovered.refusal.code,
        action: null,
        provenance,
      }),
      limits: limitsBlock(),
    });
  }

  const { selected, dropped } = selectItem(discovered.items);
  if (!selected) {
    const refusal = { code: "unqualified", message: "no discovered item qualified as a next action" };
    return finish({
      schema: DOCUMENT_SCHEMA,
      qualified: false,
      question: QUESTION,
      action: null,
      refusal,
      selection: {
        policy: RANK_POLICY,
        considered: discovered.items.length,
        selectedNativeId: null,
        dropped,
      },
      provenance,
      confidence: confidenceBlock("none", extraLimits),
      catalogBridge: catalogBridge({
        qualified: false,
        refusalCode: refusal.code,
        action: null,
        provenance,
      }),
      limits: limitsBlock(),
    });
  }

  const action = actionFrom(selected, provenance);
  assertPublicAction(action, adapter);
  return finish({
    schema: DOCUMENT_SCHEMA,
    qualified: true,
    question: QUESTION,
    action,
    refusal: null,
    selection: {
      policy: RANK_POLICY,
      considered: discovered.items.length,
      selectedNativeId: selected.nativeId,
      dropped,
    },
    provenance,
    confidence: confidenceBlock("source_statement", extraLimits),
    catalogBridge: catalogBridge({
      qualified: true,
      refusalCode: null,
      action,
      provenance,
    }),
    limits: limitsBlock(),
  });
}

function finish(doc) {
  const errors = validateDocument(doc);
  if (errors.length) {
    const error = new Error(errors.join("; "));
    error.code = "internal";
    throw error;
  }
  assertNoForbiddenKeys(doc);
  return doc;
}

const FORBIDDEN_SEGMENTS = new Set([
  "token",
  "secret",
  "password",
  "cookie",
  "authorization",
  "wallet",
  "mnemonic",
  "payoutkey",
  "seed",
]);

function forbiddenKey(key) {
  const lower = key.toLowerCase();
  if (FORBIDDEN_SEGMENTS.has(lower)) return true;
  const parts = key
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .split(/[^A-Za-z0-9]+|\s+/)
    .filter(Boolean);
  return parts.some((part) => FORBIDDEN_SEGMENTS.has(part.toLowerCase()));
}

function assertNoForbiddenKeys(value) {
  if (Array.isArray(value)) {
    for (const item of value) assertNoForbiddenKeys(item);
    return;
  }
  if (!value || typeof value !== "object") return;
  for (const [key, item] of Object.entries(value)) {
    if (forbiddenKey(key)) {
      const error = new Error(`forbidden key ${key}`);
      error.code = "internal";
      throw error;
    }
    assertNoForbiddenKeys(item);
  }
}

export function exitCodeFor(doc) {
  if (doc.qualified) return EXIT.OK;
  if (doc.refusal?.code === "source_unavailable") return EXIT.UNAVAILABLE;
  if (doc.refusal?.code === "malformed_source" || doc.refusal?.code === "unqualified") return EXIT.REFUSAL;
  return EXIT.USAGE;
}

export function documentJson(doc) {
  return `${JSON.stringify(doc, null, 2)}\n`;
}

export async function qualifyRun(options) {
  if (!isIsoZ(options.now)) {
    const error = new Error("now must be an ISO-8601 UTC timestamp");
    error.code = "usage";
    throw error;
  }
  const adapter = getAdapter(options.adapterId);
  if (!adapter) {
    const error = new Error(`unknown adapter ${options.adapterId}`);
    error.code = "usage";
    throw error;
  }
  const ctx = { now: options.now, fetchImpl: options.fetchImpl, timeoutMs: options.timeoutMs };
  if (options.mode === "fixture") {
    ctx.fixture = { text: options.fixtureText, id: options.fixtureId };
  } else if (options.mode !== "live") {
    const error = new Error("mode must be fixture or live");
    error.code = "usage";
    throw error;
  }
  const discovered = await adapter.discover(ctx);
  return seal(discovered, adapter);
}
