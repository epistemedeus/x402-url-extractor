/** Pins and honesty vocabulary for the VF15 qualification path. */

export const QUESTION = "what is the useful next action?";

export const DOCUMENT_SCHEMA = "neomorphic.vf15.qualified_next_action.v1";
export const ANSWER_SCHEMA = "neomorphic.vf15.cold_client_answer.v1";
export const ADAPTER_LIST_SCHEMA = "neomorphic.vf15.adapter_list.v1";
export const CATALOG_INDEX_SCHEMA = "neomorphic.vf15.action_catalog.v1";

/** Documented discovery seam on main. No module in this clone is named H6 discovery. */
export const DISCOVERY_SNAPSHOT_SCHEMA = "neomorphic.bounty-discovery.snapshot.v1";
export const DISCOVERY_QUERY_SCHEMA = "neomorphic.c10.five_source_query.v1";

/** Contributor desk public catalog. This path does not write that catalog. */
export const CONTRIBUTOR_CATALOG_SCHEMA = "neomorphic.contributor_desk.catalog.v1";

export const H15_SHA = "d1dc59cede5ad5306d219191ac51afbbaaed0623";
export const RECEIVER_SHA = "1652533b1823ac33b86591ec4e931a8c4ea4aa97";
export const RECEIVER_PRESENT_IN_CLONE = false;

export const RANK_POLICY = "vf15.rank.preferred_then_updated_desc_then_native_id_asc.v1";

export const AGENT_MAY = Object.freeze(["GET"]);
export const AGENT_MUST_NOT = Object.freeze([
  "POST",
  "PATCH",
  "PUT",
  "DELETE",
  "authenticate",
  "claim",
  "pay",
  "submit",
  "bid",
  "comment",
]);

export const COMMON_LIMITS = Object.freeze([
  "public listing is not claim permission",
  "this record is not an offer and not a payment",
  "metadata only; source text stays under the source terms",
]);

export const MAX_ITEMS = 20;
export const MAX_BODY_CHARS = 1_000_000;
export const MAX_TITLE_CHARS = 300;

export const EXIT = Object.freeze({
  OK: 0,
  REFUSAL: 2,
  USAGE: 3,
  UNAVAILABLE: 4,
});
