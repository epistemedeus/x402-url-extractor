/**
 * Public GET only. Redirects are not followed. The process environment is not
 * copied onto the request, so ambient tokens are not sent.
 */
import { MAX_BODY_CHARS } from "./constants.mjs";

export async function publicGet(url, { fetchImpl, headers, timeoutMs = 8000 } = {}) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return { ok: false, status: null, error: "non_https", text: "" };
  }
  if (parsed.protocol !== "https:" || parsed.username || parsed.password) {
    return { ok: false, status: null, error: "non_https", text: "" };
  }

  const fetchFn = fetchImpl ?? globalThis.fetch;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetchFn(url, {
      method: "GET",
      redirect: "manual",
      headers,
      signal: controller.signal,
    });
    if (response.status >= 300 && response.status < 400) {
      await drain(response);
      return { ok: false, status: response.status, error: "redirect", text: "" };
    }
    const raw = typeof response.text === "function" ? await response.text() : "";
    if (raw.length > MAX_BODY_CHARS) {
      return { ok: false, status: response.status, error: "body_too_large", text: "" };
    }
    if (!response.ok) {
      return { ok: false, status: response.status, error: "http_status", text: "" };
    }
    return { ok: true, status: response.status, error: null, text: raw };
  } catch (err) {
    const error = err?.name === "AbortError" ? "timeout" : "network";
    return { ok: false, status: null, error, text: "" };
  } finally {
    clearTimeout(timer);
  }
}

async function drain(response) {
  if (typeof response.text === "function") {
    try {
      await response.text();
    } catch {
      /* discarded */
    }
  }
}
