/**
 * Mozilla Bugzilla public REST. Unauthenticated GET. Comments are not requested.
 * Docs: https://bugzilla.readthedocs.io/en/latest/api/core/v1/bug.html
 * Terms: https://www.mozilla.org/en-US/about/legal/terms/mozilla/
 */
import { MAX_ITEMS } from "../constants.mjs";
import { canonicalIso, cleanTitle } from "../text.mjs";
import { parseJson, provenanceFromRead, readJsonSource } from "./read-json.mjs";

export const ADAPTER_ID = "bugzilla-mozilla";
export const SOURCE_ID = "bugzilla.mozilla.org";
export const REQUEST_URL =
  "https://bugzilla.mozilla.org/rest/bug?whiteboard=good-first-bug&bug_status=NEW&limit=5&include_fields=id,summary,status,is_open,product,component,last_change_time,resolution,whiteboard";
export const DOCUMENTATION_URL = "https://bugzilla.readthedocs.io/en/latest/api/core/v1/bug.html";
export const TERMS_URL = "https://www.mozilla.org/en-US/about/legal/terms/mozilla/";
export const PRIVACY_URL = "https://www.mozilla.org/en-US/privacy/";
export const CONTENT_POLICY =
  "Public bug metadata only (id, summary, status, product, component, whiteboard, timestamps). Comments, attachments, and response cookies are not stored.";
export const ITEM_HOSTS = Object.freeze(["bugzilla.mozilla.org"]);

const OPEN = new Set(["NEW", "ASSIGNED", "REOPENED", "UNCONFIRMED"]);
const CLOSED = new Set(["RESOLVED", "VERIFIED", "CLOSED"]);

const HEADERS = Object.freeze({
  Accept: "application/json",
  "User-Agent": "neomorphic-vf15-actionable-work",
});

function blankItem(reason = null) {
  return {
    nativeId: null,
    title: "",
    state: "unknown",
    itemUrl: null,
    updatedAt: null,
    preferred: false,
    isPullRequest: false,
    reason,
  };
}

function canonicalBugId(value) {
  if (typeof value === "number" && Number.isInteger(value) && value >= 1 && value <= 2_000_000_000) {
    return value;
  }
  if (typeof value === "string" && /^[1-9]\d*$/.test(value)) {
    const number = Number(value);
    if (Number.isSafeInteger(number) && String(number) === value && number <= 2_000_000_000) return number;
  }
  return null;
}

export function normalizeBugzillaBug(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return blankItem("malformed_item");
  const item = blankItem();
  const titled = cleanTitle(raw.summary);
  item.title = titled.title;
  if (titled.reason) item.reason = titled.reason;
  const id = canonicalBugId(raw.id);
  if (id == null) item.reason = item.reason || "malformed_item";
  else {
    item.nativeId = `bugzilla.mozilla.org#${id}`;
    item.itemUrl = `https://bugzilla.mozilla.org/show_bug.cgi?id=${id}`;
  }
  const status = typeof raw.status === "string" ? raw.status.toUpperCase() : "";
  if (raw.is_open === false || CLOSED.has(status)) item.state = "closed";
  else if (raw.is_open === true || OPEN.has(status)) item.state = "open";
  const board = typeof raw.whiteboard === "string" ? raw.whiteboard.toLowerCase() : "";
  item.preferred = board.includes("good-first-bug");
  item.updatedAt = canonicalIso(raw.last_change_time);
  return item;
}

export function parseBugzillaPayload(data) {
  if (!data || typeof data !== "object" || Array.isArray(data) || !Array.isArray(data.bugs)) {
    return { ok: false, code: "malformed_source", message: "bugzilla payload has no bugs array" };
  }
  if (data.bugs.length > MAX_ITEMS) {
    return { ok: false, code: "malformed_source", message: "bugzilla payload exceeds 20 bugs" };
  }
  return { ok: true, items: data.bugs.map(normalizeBugzillaBug) };
}

export async function discover(ctx) {
  const read = await readJsonSource({
    requestUrl: REQUEST_URL,
    headers: HEADERS,
    allowedHosts: ["bugzilla.mozilla.org"],
    ctx,
  });
  const provenance = provenanceFromRead(read, {
    sourceId: SOURCE_ID,
    adapterId: ADAPTER_ID,
    documentationUrl: DOCUMENTATION_URL,
    termsUrl: TERMS_URL,
    contentPolicy: CONTENT_POLICY,
    termsLinks: [TERMS_URL, PRIVACY_URL, DOCUMENTATION_URL],
  });
  if (read.unavailable) {
    return {
      ok: false,
      refusal: { code: "source_unavailable", message: `public get failed: ${read.error}` },
      items: [],
      provenance,
      confidenceLimits: confidenceLimits(read.evidenceClass),
    };
  }
  const parsed = parseJson(read.text);
  if (!parsed.ok) {
    return {
      ok: false,
      refusal: { code: "malformed_source", message: "response was not json" },
      items: [],
      provenance,
      confidenceLimits: confidenceLimits(read.evidenceClass),
    };
  }
  const shaped = parseBugzillaPayload(parsed.value);
  if (!shaped.ok) {
    return {
      ok: false,
      refusal: { code: shaped.code, message: shaped.message },
      items: [],
      provenance,
      confidenceLimits: confidenceLimits(read.evidenceClass),
    };
  }
  return {
    ok: true,
    refusal: null,
    items: shaped.items,
    provenance,
    confidenceLimits: confidenceLimits(read.evidenceClass),
  };
}

function confidenceLimits(evidenceClass) {
  const evidence =
    evidenceClass === "fixture"
      ? "fixture evidence is not a live fetch"
      : "live public GET is a point-in-time source statement";
  return [evidence, "public bug metadata only; comments and attachments were not fetched"];
}

export const adapter = Object.freeze({
  id: ADAPTER_ID,
  sourceId: SOURCE_ID,
  requestUrl: REQUEST_URL,
  documentationUrl: DOCUMENTATION_URL,
  termsUrl: TERMS_URL,
  itemHosts: ITEM_HOSTS,
  auth: "none",
  mutations: "none",
  discover,
});
