import { adapter as bugzillaMozilla } from "./bugzilla-mozilla.mjs";
import { adapter as githubPublicIssues } from "./github-public-issues.mjs";

export const ADAPTERS = Object.freeze([githubPublicIssues, bugzillaMozilla]);

const BY_ID = new Map(ADAPTERS.map((adapter) => [adapter.id, adapter]));

export function getAdapter(id) {
  return BY_ID.get(id) ?? null;
}

export function listAdapters() {
  return ADAPTERS.map((adapter) => ({
    id: adapter.id,
    sourceId: adapter.sourceId,
    requestUrl: adapter.requestUrl,
    documentationUrl: adapter.documentationUrl,
    termsUrl: adapter.termsUrl,
    auth: adapter.auth,
    mutations: adapter.mutations,
  }));
}
