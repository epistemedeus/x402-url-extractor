import { closeSync, constants, existsSync, lstatSync, openSync, readFileSync, realpathSync, statSync, writeFileSync } from "node:fs";
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { listAdapters } from "./adapters/index.mjs";
import { ADAPTER_LIST_SCHEMA, EXIT, QUESTION } from "./constants.mjs";
import { documentJson, exitCodeFor, qualifyRun } from "./qualify.mjs";
import { answerJson, answerNextAction } from "./query.mjs";

const PACK = fileURLToPath(new URL("..", import.meta.url));
const OUTSIDE = "path must be a file inside the experiment";

export function resolveInside(pack, cwd, userPath) {
  if (typeof userPath !== "string" || userPath.trim() === "" || userPath.includes("\0")) {
    const error = new Error("missing path");
    error.code = "usage";
    throw error;
  }
  const candidates = [resolve(cwd, userPath)];
  const fromPack = resolve(pack, userPath);
  if (fromPack !== candidates[0]) candidates.push(fromPack);
  for (const abs of candidates) {
    const rel = relative(pack, abs);
    const posix = rel.split(sep).join("/");
    if (!posix || posix.startsWith("..") || posix.includes("/../") || isAbsolute(rel)) continue;
    if (!existsSync(abs) || !statSync(abs).isFile()) continue;
    return { abs, rel: posix };
  }
  const error = new Error(OUTSIDE);
  error.code = "usage";
  throw error;
}

function usage(message) {
  const error = new Error(message);
  error.code = "usage";
  return error;
}

function isStrictlyInside(root, target) {
  const rel = relative(root, target);
  if (!rel || isAbsolute(rel)) return false;
  if (rel.split(sep).includes("..")) return false;
  return target === join(root, rel);
}

function isInsideOrEqual(root, target) {
  return target === root || isStrictlyInside(root, target);
}

// A new file is allowed only when its real parent already exists inside pack.
// Ancestor symlinks are resolved first. A final symlink is kept only when the
// file it names is inside pack, and the returned path is that real file.
export function resolveOutputInside(pack, cwd, userPath) {
  if (typeof userPath !== "string" || userPath.trim() === "" || userPath.includes("\0")) {
    throw usage("missing path");
  }
  let packReal;
  try {
    packReal = realpathSync(pack);
  } catch {
    throw usage(OUTSIDE);
  }
  const candidates = [resolve(cwd, userPath)];
  const fromPack = resolve(pack, userPath);
  if (fromPack !== candidates[0]) candidates.push(fromPack);
  for (const abs of candidates) {
    const resolved = confineOutput(packReal, abs);
    if (resolved) return resolved;
  }
  throw usage(OUTSIDE);
}

function confineOutput(packReal, abs) {
  const name = basename(abs);
  if (!name || name === "." || name === ".." || name.includes("/") || name.includes("\0")) return null;
  const parent = dirname(abs);
  if (!parent || !existsSync(parent)) return null;
  let parentReal;
  try {
    parentReal = realpathSync(parent);
  } catch {
    return null;
  }
  if (!isInsideOrEqual(packReal, parentReal)) return null;
  let parentStat;
  try {
    parentStat = lstatSync(parentReal);
  } catch {
    return null;
  }
  if (parentStat.isSymbolicLink() || !parentStat.isDirectory()) return null;
  const dest = join(parentReal, name);
  if (!isStrictlyInside(packReal, dest)) return null;
  return finishOutput(packReal, dest);
}

function finishOutput(packReal, dest) {
  let st;
  try {
    st = lstatSync(dest);
  } catch (err) {
    if (err.code === "ENOENT") return outputPath(packReal, dest);
    return null;
  }
  if (st.isSymbolicLink()) {
    let real;
    try {
      real = realpathSync(dest);
    } catch {
      return null;
    }
    if (!isStrictlyInside(packReal, real)) return null;
    let realStat;
    try {
      realStat = lstatSync(real);
    } catch {
      return null;
    }
    if (realStat.isSymbolicLink() || !realStat.isFile()) return null;
    return outputPath(packReal, real);
  }
  if (!st.isFile()) return null;
  return outputPath(packReal, dest);
}

function outputPath(packReal, abs) {
  return { abs, rel: relative(packReal, abs).split(sep).join("/") };
}

function writeConfined(pack, abs, data) {
  let packReal;
  try {
    packReal = realpathSync(pack);
  } catch {
    throw usage(OUTSIDE);
  }
  if (!isStrictlyInside(packReal, abs)) throw usage(OUTSIDE);
  const parent = dirname(abs);
  let parentReal;
  try {
    parentReal = realpathSync(parent);
  } catch {
    throw usage(OUTSIDE);
  }
  if (parentReal !== parent || !isInsideOrEqual(packReal, parentReal)) throw usage(OUTSIDE);
  let existing = null;
  try {
    existing = lstatSync(abs);
  } catch (err) {
    if (err.code !== "ENOENT") throw usage(OUTSIDE);
  }
  if (existing && (existing.isSymbolicLink() || !existing.isFile())) throw usage(OUTSIDE);
  let fd;
  try {
    fd = openSync(
      abs,
      constants.O_WRONLY | constants.O_CREAT | constants.O_TRUNC | constants.O_NOFOLLOW,
    );
  } catch (err) {
    const refused = new Set(["ELOOP", "EMLINK", "EISDIR", "ENOTDIR", "ENOENT"]);
    if (refused.has(err.code)) throw usage(OUTSIDE);
    throw err;
  }
  try {
    writeFileSync(fd, data);
  } finally {
    closeSync(fd);
  }
}

function resolveReadable(cwd, userPath) {
  if (typeof userPath !== "string" || userPath.trim() === "" || userPath.includes("\0")) {
    const error = new Error("missing artifact");
    error.code = "usage";
    throw error;
  }
  const abs = resolve(cwd, userPath);
  if (!existsSync(abs) || !statSync(abs).isFile()) {
    const error = new Error("artifact not found");
    error.code = "usage";
    throw error;
  }
  return abs;
}

function parseArgs(argv) {
  const [cmd, ...rest] = argv;
  const opts = {};
  for (let i = 0; i < rest.length; i += 1) {
    const token = rest[i];
    if (!token.startsWith("--")) {
      const error = new Error(`unexpected argument ${token}`);
      error.code = "usage";
      throw error;
    }
    const key = token.slice(2);
    const value = rest[i + 1];
    if (value == null || value.startsWith("--")) {
      const error = new Error(`missing value for --${key}`);
      error.code = "usage";
      throw error;
    }
    opts[key] = value;
    i += 1;
  }
  return { cmd, opts };
}

function helpText() {
  return [
    "vf15 qualify --adapter ID --mode fixture|live --now ISO [--fixture PATH] [--out PATH]",
    "vf15 query --artifact PATH [--question TEXT]",
    "vf15 adapters",
    `question: ${QUESTION}`,
    "--fixture and --out must stay inside this experiment",
    "",
  ].join("\n");
}

export async function main(argv, io = {}) {
  const stdout = io.stdout || process.stdout;
  const stderr = io.stderr || process.stderr;
  const cwd = io.cwd || process.cwd();
  try {
    if (argv.length === 0 || argv[0] === "--help" || argv[0] === "help") {
      const text = helpText();
      if (argv[0] === "--help" || argv[0] === "help") {
        stdout.write(text);
        return EXIT.OK;
      }
      stderr.write(text);
      return EXIT.USAGE;
    }
    const { cmd, opts } = parseArgs(argv);
    if (cmd === "adapters") {
      stdout.write(`${JSON.stringify({ schema: ADAPTER_LIST_SCHEMA, adapters: listAdapters() }, null, 2)}\n`);
      return EXIT.OK;
    }
    if (cmd === "qualify") return await qualifyCommand(opts, { stdout, cwd });
    if (cmd === "query") return queryCommand(opts, { stdout, cwd });
    const error = new Error(`unknown command ${cmd}`);
    error.code = "usage";
    throw error;
  } catch (err) {
    if (err.code === "artifact_unreadable") {
      stdout.write(
        `${JSON.stringify(
          {
            schema: "neomorphic.vf15.cold_client_answer.v1",
            question: QUESTION,
            deterministic: true,
            readFrom: "published_artifact_only",
            qualified: false,
            action: null,
            refusal: { code: "artifact_unreadable", message: err.message },
            provenance: null,
            confidence: null,
            catalogBridge: null,
            limits: null,
          },
          null,
          2,
        )}\n`,
      );
      return EXIT.USAGE;
    }
    stderr.write(`${err.code || "error"}: ${err.message}\n`);
    return err.code === "usage" ? EXIT.USAGE : 1;
  }
}

async function qualifyCommand(opts, { stdout, cwd }) {
  const allowed = new Set(["adapter", "mode", "now", "fixture", "out"]);
  for (const key of Object.keys(opts)) {
    if (!allowed.has(key)) {
      const error = new Error(`unknown flag --${key}`);
      error.code = "usage";
      throw error;
    }
  }
  if (!opts.adapter || !opts.mode || !opts.now) {
    const error = new Error("qualify requires --adapter, --mode, and --now");
    error.code = "usage";
    throw error;
  }
  let fixtureText;
  let fixtureId;
  if (opts.mode === "fixture") {
    if (!opts.fixture) {
      const error = new Error("fixture mode requires --fixture");
      error.code = "usage";
      throw error;
    }
    const resolved = resolveInside(PACK, cwd, opts.fixture);
    fixtureText = readFileSync(resolved.abs, "utf8");
    fixtureId = resolved.rel;
  } else if (opts.mode === "live") {
    if (opts.fixture) {
      const error = new Error("live mode does not take --fixture");
      error.code = "usage";
      throw error;
    }
  }
  let output = null;
  if (opts.out) output = resolveOutputInside(PACK, cwd, opts.out);
  const doc = await qualifyRun({
    adapterId: opts.adapter,
    mode: opts.mode,
    now: opts.now,
    fixtureText,
    fixtureId,
  });
  const json = documentJson(doc);
  if (output) {
    const again = resolveOutputInside(PACK, cwd, opts.out);
    if (again.abs !== output.abs) throw usage(OUTSIDE);
    writeConfined(PACK, again.abs, json);
  }
  stdout.write(json);
  return exitCodeFor(doc);
}

function queryCommand(opts, { stdout, cwd }) {
  const allowed = new Set(["artifact", "question"]);
  for (const key of Object.keys(opts)) {
    if (!allowed.has(key)) {
      const error = new Error(`unknown flag --${key}`);
      error.code = "usage";
      throw error;
    }
  }
  if (!opts.artifact) {
    const error = new Error("query requires --artifact");
    error.code = "usage";
    throw error;
  }
  const abs = resolveReadable(cwd, opts.artifact);
  const raw = readFileSync(abs, "utf8");
  let artifact;
  try {
    artifact = JSON.parse(raw);
  } catch {
    const error = new Error("artifact was not json");
    error.code = "artifact_unreadable";
    throw error;
  }
  const answer = answerNextAction(artifact, { question: opts.question ?? QUESTION });
  stdout.write(answerJson(answer));
  return EXIT.OK;
}
