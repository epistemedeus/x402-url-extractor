import { createHash } from "node:crypto";

export function sha256Prefixed(text) {
  const hex = createHash("sha256").update(text, "utf8").digest("hex");
  return `sha256:${hex}`;
}
