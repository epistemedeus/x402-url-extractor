/**
 * GitHub public issue search. Unauthenticated GET. Issue bodies are not stored.
 * Docs: https://docs.github.com/en/rest/search/search#search-issues-and-pull-requests
 * Terms: https://docs.github.com/en/site-policy/github-terms/github-terms-of-service
 */
import { MAX_ITEMS } from "../constants.mjs";
import { canonicalIso, cleanTitle } from "../text.mjs";
import { parseJson, provenanceFromRead, readJsonSource } from "./read-json.mjs";

export const ADAPTER_ID = "github-public-issues";
export const SOURCE_ID = "github.com";
export const REQUEST_URL =
  "https://api.github.com/search/issues?q=label%3A%22good+first+issue%22+state%3Aopen+is%3Aissue&sort=updated&order=desc&per_page=5";
export const DOCUMENTATION_URL =
  "https://docs.github.com/en/rest/search/search#search-issues-and-pull-requests";
export const TERMS_URL = "https://docs.github.com/en/site-policy/github-terms/github-terms-of-service";
export const ACCEPTABLE_USE_URL =
  "https://docs.github.com/en/site-policy/acceptable-use-policies/github-acceptable-use-policies";
export const CONTENT_POLICY =
  "Issue and repository text stays under each repository license. This adapter stores title, state, label names, updated_at, and the canonical issue URL.";
export const ITEM_HOSTS = Object.freeze(["github.com"]);

const HEADERS = Object.freeze({
  Accept: "application/vnd.github+json",
  "User-Agent": "neomorphic-vf15-actionable-work",
  "X-GitHub-Api-Version": "2022-11-28",
});

const ISSUE_URL = /^https:\/\/github\.com\/([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)\/issues\/(\d+)$/;

function blankItem(reason = null) {
  return {
    nativeId: null,
    title: "",
    state: "unknown",
    itemUrl: null,
    updatedAt: null,
    preferred: false,
    isPullRequest: false,
    reason,
  };
}

export function normalizeGithubItem(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return blankItem("malformed_item");
  const item = blankItem();
  if (raw.pull_request != null) item.isPullRequest = true;
  const titled = cleanTitle(raw.title);
  item.title = titled.title;
  if (titled.reason) item.reason = titled.reason;
  if (raw.state === "open" || raw.state === "closed") item.state = raw.state;
  item.updatedAt = canonicalIso(raw.updated_at);
  const labels = Array.isArray(raw.labels) ? raw.labels : [];
  const names = labels
    .map((label) => (typeof label === "string" ? label : label?.name))
    .filter((name) => typeof name === "string");
  item.preferred = names.some((name) => {
    const lower = name.toLowerCase();
    return lower === "good first issue" || lower === "help wanted";
  });

  if (typeof raw.html_url !== "string") return item;
  let url;
  try {
    url = new URL(raw.html_url);
  } catch {
    item.reason = item.reason || "unsafe_url";
    return item;
  }
  if (url.protocol !== "https:" || url.username || url.password || url.hostname !== "github.com") {
    item.reason = item.reason || "unsafe_url";
    return item;
  }
  const path = url.pathname.replace(/\/$/, "");
  if (path.includes("/pull/")) item.isPullRequest = true;
  const match = `${url.origin}${path}`.match(ISSUE_URL);
  if (!match) {
    if (!item.isPullRequest) item.reason = item.reason || "unrecognized_locator";
    return item;
  }
  const number = Number(match[3]);
  if (!Number.isSafeInteger(number) || String(number) !== match[3]) {
    item.reason = item.reason || "unrecognized_locator";
    return item;
  }
  if (raw.number != null && raw.number !== number) {
    item.reason = "id_mismatch";
    return item;
  }
  item.nativeId = `${match[1]}/${match[2]}#${number}`;
  item.itemUrl = `https://github.com/${match[1]}/${match[2]}/issues/${number}`;
  return item;
}

export function parseGithubPayload(data) {
  if (!data || typeof data !== "object" || Array.isArray(data) || !Array.isArray(data.items)) {
    return { ok: false, code: "malformed_source", message: "github search payload has no items array" };
  }
  if (data.items.length > MAX_ITEMS) {
    return { ok: false, code: "malformed_source", message: "github search payload exceeds 20 items" };
  }
  return { ok: true, items: data.items.map(normalizeGithubItem) };
}

export async function discover(ctx) {
  const read = await readJsonSource({
    requestUrl: REQUEST_URL,
    headers: HEADERS,
    allowedHosts: ["api.github.com"],
    ctx,
  });
  const provenance = provenanceFromRead(read, {
    sourceId: SOURCE_ID,
    adapterId: ADAPTER_ID,
    documentationUrl: DOCUMENTATION_URL,
    termsUrl: TERMS_URL,
    contentPolicy: CONTENT_POLICY,
    termsLinks: [TERMS_URL, ACCEPTABLE_USE_URL, DOCUMENTATION_URL],
  });
  if (read.unavailable) {
    return {
      ok: false,
      refusal: { code: "source_unavailable", message: `public get failed: ${read.error}` },
      items: [],
      provenance,
      confidenceLimits: confidenceLimits(read.evidenceClass),
    };
  }
  const parsed = parseJson(read.text);
  if (!parsed.ok) {
    return {
      ok: false,
      refusal: { code: "malformed_source", message: "response was not json" },
      items: [],
      provenance,
      confidenceLimits: confidenceLimits(read.evidenceClass),
    };
  }
  const shaped = parseGithubPayload(parsed.value);
  if (!shaped.ok) {
    return {
      ok: false,
      refusal: { code: shaped.code, message: shaped.message },
      items: [],
      provenance,
      confidenceLimits: confidenceLimits(read.evidenceClass),
    };
  }
  return {
    ok: true,
    refusal: null,
    items: shaped.items,
    provenance,
    confidenceLimits: confidenceLimits(read.evidenceClass),
  };
}

function confidenceLimits(evidenceClass) {
  const evidence =
    evidenceClass === "fixture"
      ? "fixture evidence is not a live fetch"
      : "live public GET is a point-in-time source statement";
  return [
    evidence,
    "unauthenticated GitHub search is rate-limited to 10 requests per minute and is not a license to copy issue bodies",
  ];
}

export const adapter = Object.freeze({
  id: ADAPTER_ID,
  sourceId: SOURCE_ID,
  requestUrl: REQUEST_URL,
  documentationUrl: DOCUMENTATION_URL,
  termsUrl: TERMS_URL,
  itemHosts: ITEM_HOSTS,
  auth: "none",
  mutations: "none",
  discover,
});
