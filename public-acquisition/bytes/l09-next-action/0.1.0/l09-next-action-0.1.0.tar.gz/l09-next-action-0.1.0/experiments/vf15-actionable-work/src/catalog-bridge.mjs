/**
 * Field bridge into the discovery next-step table and the contributor catalog.
 * nextStep("error") falls through to observe_only in the discovery function, so an
 * unavailable source is labeled taskClass "unknown", which that function refuses.
 * C05, C06, and C07 are cited by pin and are not executed. No catalog is written.
 */
import { PAYMENT_AUTHORITY, PUBLIC_TASK_SCHEMA } from "../../../packs/contributor-desk/src/constants.mjs";
import { nextStep, usefulChoice } from "../../../packs/bounty-discovery/src/five-source/compile.mjs";
import { ENGINE_PINS } from "../../../packs/bounty-discovery/src/five-source/engine-pins.mjs";
import { SNAPSHOT_SCHEMA } from "../../../packs/bounty-discovery/src/five-source/snapshot.mjs";
import {
  CONTRIBUTOR_CATALOG_SCHEMA,
  DISCOVERY_QUERY_SCHEMA,
  H15_SHA,
  RECEIVER_PRESENT_IN_CLONE,
  RECEIVER_SHA,
} from "./constants.mjs";

export function taskClassFor(qualified, refusalCode) {
  if (qualified) return "observe_open";
  if (refusalCode === "malformed_source") return "malformed";
  return "unknown";
}

export function bridgeId(adapterId, nativeId) {
  const slug = String(nativeId).replace(/[^A-Za-z0-9._-]+/g, "_");
  return `vf15_${adapterId}__${slug}`;
}

export function catalogBridge({ qualified, refusalCode, action, provenance }) {
  const taskClass = taskClassFor(qualified, refusalCode);
  return {
    discovery: {
      alignedTo: SNAPSHOT_SCHEMA,
      querySchema: DISCOVERY_QUERY_SCHEMA,
      module: "packs/bounty-discovery/src/five-source/compile.mjs",
      functionsReused: ["nextStep", "usefulChoice"],
      forkedCore: false,
      enginesExecuted: false,
      enginePins: {
        c05: ENGINE_PINS["discovery-search-index"].sha,
        c06: ENGINE_PINS["source-freshness-consumer"].sha,
        c07: ENGINE_PINS["workability-gate-composer"].sha,
      },
      taskClass,
      nextStep: nextStep(taskClass),
      usefulChoice: usefulChoice(taskClass),
      claimAuthority: "none",
      paymentAuthority: "none",
      publicListingIsNotClaimPermission: true,
      safeToStartWork: false,
      sourceId: provenance.sourceId,
      listingId: action?.nativeId ?? null,
      sourceUrl: action?.url ?? null,
      h15: H15_SHA,
    },
    contributorCatalog: {
      alignedTo: CONTRIBUTOR_CATALOG_SCHEMA,
      publicTaskSchema: PUBLIC_TASK_SCHEMA,
      module: "packs/contributor-desk/src/public-view.mjs",
      mutatedCatalog: false,
      walletless: true,
      deskPaymentAuthority: PAYMENT_AUTHORITY,
      task: action
        ? {
            id: bridgeId(provenance.adapterId, action.nativeId),
            title: action.title,
            summary: action.kind,
            provenance: provenance.evidenceClass,
            lifecycle: "discovered",
            fundingState: "unknown",
            claimable: false,
            appealable: false,
            reward: null,
            paid: false,
            settled: false,
            transfer: null,
            payoutState: "none",
            paymentAuthority: "none",
          }
        : null,
    },
    receiver: {
      sha: RECEIVER_SHA,
      presentInClone: RECEIVER_PRESENT_IN_CLONE,
      edited: false,
    },
  };
}
