import { readFileSync } from "node:fs";
import {
  AGENT_MAY,
  AGENT_MUST_NOT,
  DISCOVERY_QUERY_SCHEMA,
  DISCOVERY_SNAPSHOT_SCHEMA,
  H15_SHA,
  QUESTION,
  RECEIVER_SHA,
} from "./constants.mjs";

const schema = JSON.parse(
  readFileSync(new URL("../schema/qualified-next-action.v1.json", import.meta.url), "utf8"),
);

const SHA = /^sha256:[0-9a-f]{64}$/;
const ISO_Z = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/;

function sameStrings(a, b) {
  return Array.isArray(a) && a.length === b.length && a.every((value, index) => value === b[index]);
}

export function validateDocument(doc) {
  const errors = [];
  if (!doc || typeof doc !== "object" || Array.isArray(doc)) return ["document must be an object"];
  for (const key of schema.required) {
    if (!Object.hasOwn(doc, key)) errors.push(`missing ${key}`);
  }
  for (const key of Object.keys(doc)) {
    if (!schema.required.includes(key)) errors.push(`unexpected ${key}`);
  }
  if (doc.schema !== schema.$id) errors.push("schema");
  if (typeof doc.qualified !== "boolean") errors.push("qualified");
  if (doc.question !== QUESTION) errors.push("question");
  if (doc.qualified) {
    errors.push(...validateAction(doc.action));
    if (doc.refusal !== null) errors.push("refusal must be null when qualified");
  } else {
    if (doc.action !== null) errors.push("action must be null when refused");
    errors.push(...validateRefusal(doc.refusal));
  }
  errors.push(...validateSelection(doc.selection, doc.qualified));
  errors.push(...validateProvenance(doc.provenance));
  errors.push(...validateConfidence(doc.confidence, doc.qualified));
  errors.push(...validateBridge(doc.catalogBridge, doc.qualified));
  errors.push(...validateLimits(doc.limits));
  return errors.filter(Boolean);
}

function validateAction(action) {
  if (!action || typeof action !== "object" || Array.isArray(action)) return ["action"];
  const errors = [];
  if (action.kind !== "read_public_record") errors.push("action.kind");
  if (action.method !== "GET") errors.push("action.method");
  if (typeof action.url !== "string" || !action.url.startsWith("https://")) errors.push("action.url");
  if (typeof action.nativeId !== "string" || action.nativeId.length === 0) errors.push("action.nativeId");
  if (typeof action.title !== "string" || action.title.length === 0) errors.push("action.title");
  if (action.state !== "open") errors.push("action.state");
  if (typeof action.sourceId !== "string") errors.push("action.sourceId");
  if (typeof action.adapterId !== "string") errors.push("action.adapterId");
  if (!sameStrings(action.agentMay, AGENT_MAY)) errors.push("action.agentMay");
  if (!sameStrings(action.agentMustNot, AGENT_MUST_NOT)) errors.push("action.agentMustNot");
  return errors;
}

function validateRefusal(refusal) {
  if (!refusal || typeof refusal !== "object") return ["refusal"];
  const allowed = ["malformed_source", "unqualified", "source_unavailable"];
  if (!allowed.includes(refusal.code)) return ["refusal.code"];
  if (typeof refusal.message !== "string" || refusal.message.length === 0) return ["refusal.message"];
  if (Object.keys(refusal).length !== 2) return ["refusal keys"];
  return [];
}

function validateSelection(selection, qualified) {
  if (!selection || typeof selection !== "object") return ["selection"];
  const errors = [];
  if (selection.policy !== "vf15.rank.preferred_then_updated_desc_then_native_id_asc.v1") {
    errors.push("selection.policy");
  }
  if (!Number.isInteger(selection.considered) || selection.considered < 0) errors.push("selection.considered");
  if (qualified) {
    if (typeof selection.selectedNativeId !== "string") errors.push("selection.selectedNativeId");
  } else if (selection.selectedNativeId !== null) errors.push("selection.selectedNativeId");
  if (!Array.isArray(selection.dropped)) errors.push("selection.dropped");
  else {
    for (const row of selection.dropped) {
      if (!row || typeof row.reason !== "string") errors.push("selection.dropped");
      if (row && row.nativeId !== null && typeof row.nativeId !== "string") errors.push("selection.dropped");
    }
  }
  return errors;
}

function validateProvenance(provenance) {
  if (!provenance || typeof provenance !== "object") return ["provenance"];
  const errors = [];
  for (const key of [
    "sourceId",
    "adapterId",
    "documentationUrl",
    "termsUrl",
    "requestUrl",
    "fetchedAt",
    "fixtureId",
    "evidenceClass",
    "httpStatus",
    "bodySha256",
    "contentPolicy",
    "terms",
  ]) {
    if (!Object.hasOwn(provenance, key)) errors.push(`provenance.${key}`);
  }
  if (!ISO_Z.test(provenance.fetchedAt || "")) errors.push("provenance.fetchedAt");
  if (provenance.evidenceClass !== "fixture" && provenance.evidenceClass !== "live_public_get") {
    errors.push("provenance.evidenceClass");
  }
  if (provenance.evidenceClass === "fixture") {
    if (typeof provenance.fixtureId !== "string" || provenance.fixtureId.length === 0) {
      errors.push("provenance.fixtureId");
    }
  } else if (provenance.fixtureId !== null) errors.push("provenance.fixtureId");
  if (provenance.httpStatus !== null && !Number.isInteger(provenance.httpStatus)) errors.push("provenance.httpStatus");
  if (provenance.bodySha256 !== null && !SHA.test(provenance.bodySha256 || "")) errors.push("provenance.bodySha256");
  const terms = provenance.terms;
  if (!terms || terms.auth !== "none" || terms.mutations !== "none" || !Array.isArray(terms.links)) {
    errors.push("provenance.terms");
  }
  return errors;
}

function validateConfidence(confidence, qualified) {
  if (!confidence || typeof confidence !== "object") return ["confidence"];
  const errors = [];
  const level = qualified ? "source_statement" : "none";
  if (confidence.level !== level) errors.push("confidence.level");
  if (!Array.isArray(confidence.limits) || confidence.limits.length < 3) errors.push("confidence.limits");
  else if (confidence.limits.some((item) => typeof item !== "string" || item.length === 0)) {
    errors.push("confidence.limits");
  }
  return errors;
}

function validateBridge(bridge, qualified) {
  if (!bridge || typeof bridge !== "object") return ["catalogBridge"];
  const errors = [];
  const discovery = bridge.discovery;
  const catalog = bridge.contributorCatalog;
  const receiver = bridge.receiver;
  if (!discovery || discovery.forkedCore !== false || discovery.enginesExecuted !== false) errors.push("discovery");
  if (!discovery || discovery.alignedTo !== DISCOVERY_SNAPSHOT_SCHEMA || discovery.querySchema !== DISCOVERY_QUERY_SCHEMA) {
    errors.push("discovery schema");
  }
  if (!discovery || discovery.h15 !== H15_SHA) errors.push("h15");
  if (!discovery || discovery.claimAuthority !== "none" || discovery.paymentAuthority !== "none") errors.push("discovery authority");
  if (!discovery || discovery.safeToStartWork !== false || discovery.publicListingIsNotClaimPermission !== true) {
    errors.push("discovery boundary");
  }
  if (!discovery || typeof discovery.nextStep !== "string" || typeof discovery.taskClass !== "string") {
    errors.push("discovery class");
  }
  if (!discovery || typeof discovery.usefulChoice !== "boolean") errors.push("discovery usefulChoice");
  if (!catalog || catalog.mutatedCatalog !== false || catalog.walletless !== true) errors.push("contributorCatalog");
  if (!catalog || catalog.alignedTo !== "neomorphic.contributor_desk.catalog.v1") errors.push("contributorCatalog schema");
  if (qualified) {
    const task = catalog?.task;
    if (!task || task.claimable !== false || task.reward !== null || task.paid !== false || task.settled !== false) {
      errors.push("contributor task");
    }
    if (!task || task.transfer !== null || task.paymentAuthority !== "none" || task.lifecycle !== "discovered") {
      errors.push("contributor task state");
    }
  } else if (catalog && catalog.task !== null) errors.push("contributor task");
  if (
    !receiver ||
    receiver.edited !== false ||
    receiver.presentInClone !== false ||
    receiver.sha !== RECEIVER_SHA
  ) {
    errors.push("receiver");
  }
  return errors;
}

function validateLimits(limits) {
  if (!limits || typeof limits !== "object") return ["limits"];
  const errors = [];
  if (limits.claimAuthority !== "none") errors.push("limits.claimAuthority");
  if (limits.paymentAuthority !== "none") errors.push("limits.paymentAuthority");
  if (limits.safeToStartWork !== false) errors.push("limits.safeToStartWork");
  if (limits.ledger !== false) errors.push("limits.ledger");
  if (limits.offer !== false) errors.push("limits.offer");
  if (limits.publicListingIsNotClaimPermission !== true) errors.push("limits.publicListingIsNotClaimPermission");
  return errors;
}
