# VF15 actionable work

Qualify one discovered public record into a single next GET. A later client reads the published JSON and repeats that action without searching again.

The record is a JSON document (`neomorphic.vf15.qualified_next_action.v1`). Authority on every document is `claimAuthority: none` and `paymentAuthority: none`.

## Adapters

| Adapter | Source | Request | Terms |
| --- | --- | --- | --- |
| `github-public-issues` | `github.com` | [Issue search](https://docs.github.com/en/rest/search/search#search-issues-and-pull-requests) for open issues labeled `good first issue`, 5 rows, no token | [GitHub Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service) |
| `bugzilla-mozilla` | `bugzilla.mozilla.org` | [Bugzilla REST](https://bugzilla.readthedocs.io/en/latest/api/core/v1/bug.html) `whiteboard=good-first-bug`, `bug_status=NEW`, 5 rows, no API key | [Mozilla Terms](https://www.mozilla.org/en-US/about/legal/terms/mozilla/) |

Unauthenticated GitHub search is limited to 10 requests per minute. A non-200 response, a redirect, a timeout, or a network error becomes `source_unavailable` (exit 4). Fixtures are the CI path. `scripts/live-probe.mjs` is the labelled live read and exits 0 when a source is down.

## Commands

From this directory:

```sh
node --test --test-concurrency=1 tests/*.test.mjs

node bin/vf15.mjs qualify \
  --adapter github-public-issues \
  --mode fixture \
  --fixture fixtures/github/search-happy.json \
  --now 2026-09-26T21:00:00.000Z

node bin/vf15.mjs query \
  --artifact published/qualified-next-action.json \
  --question "what is the useful next action?"

node bin/vf15.mjs qualify \
  --adapter github-public-issues \
  --mode fixture \
  --fixture fixtures/github/malformed.json \
  --now 2026-09-26T21:00:00.000Z
```

The malformed command exits 2 and writes a refusal document. Query of a published refusal still answers; query does not search.

`published/catalog.json` lists both committed fixture qualifications and names the discovery and contributor-catalog schemas they bridge to.

## Seams

Discovery on this clone is `packs/bounty-discovery`. No module here is named H6 discovery. Qualification calls `nextStep` and `usefulChoice` from `packs/bounty-discovery/src/five-source/compile.mjs` and cites the snapshot schema `neomorphic.bounty-discovery.snapshot.v1`. An open qualified record is task class `observe_open`, so the discovery function returns `observe_only`. The concrete action is the GET in `action.url`. C05, C06, and C07 are cited by the pins already recorded in that pack and are not executed.

`nextStep("error")` in that function returns `observe_only`. An unavailable source is therefore labeled task class `unknown`, which the same function maps to `do_not_start_work`.

Contributor catalog fields (`id`, `title`, `summary`, `provenance`, `lifecycle`, `fundingState`, `claimable`, `walletless`) follow `neomorphic.contributor_desk.catalog.v1`. `claimable` is false, `reward` is null, and this path does not write the desk catalog.

H15 base `d1dc59cede5ad5306d219191ac51afbbaaed0623`. Receiver `1652533b1823ac33b86591ec4e931a8c4ea4aa97` is absent from this clone and is not edited.

## Limits

- One GET. `agentMustNot` includes comment, claim, pay, submit, bid, and authenticate.
- Fixture evidence is not a live fetch. The committed artifacts were qualified from `fixtures/` at `2026-09-26T21:00:00.000Z`.
- A public issue or bug is a source statement. It is not a reserved offer and not permission to start work.
- Ranking keeps a preferred label (`good first issue`, `help wanted`, or Bugzilla `good-first-bug`), then the newest `updatedAt`, then `nativeId` ascending.
- `--out` writes a file only when its resolved real path stays inside this directory. Relative escapes, absolute paths outside it, and symlink escapes are rejected before any write.
