import { sha256Prefixed } from "../hash.mjs";
import { publicGet } from "../http.mjs";
import { isIsoZ } from "../text.mjs";

/**
 * Shared read path for public JSON sources.
 * Fixture mode hashes the supplied text and does not call fetch.
 */
export async function readJsonSource({ requestUrl, headers, allowedHosts, ctx }) {
  if (!isIsoZ(ctx?.now)) {
    const error = new Error("now must be an ISO-8601 UTC timestamp");
    error.code = "usage";
    throw error;
  }

  const base = {
    requestUrl,
    fetchedAt: ctx.now,
  };

  if (ctx.fixture) {
    if (typeof ctx.fixture.text !== "string") {
      const error = new Error("fixture text must be a string");
      error.code = "usage";
      throw error;
    }
    return {
      ...base,
      text: ctx.fixture.text,
      httpStatus: 200,
      evidenceClass: "fixture",
      fixtureId: ctx.fixture.id ?? null,
      unavailable: false,
    };
  }

  let host;
  try {
    host = new URL(requestUrl).hostname;
  } catch {
    host = "";
  }
  if (!allowedHosts.includes(host)) {
    return {
      ...base,
      text: "",
      httpStatus: null,
      evidenceClass: "live_public_get",
      fixtureId: null,
      unavailable: true,
      error: "non_https",
    };
  }

  const response = await publicGet(requestUrl, {
    fetchImpl: ctx.fetchImpl,
    headers,
    timeoutMs: ctx.timeoutMs,
  });
  if (!response.ok) {
    return {
      ...base,
      text: "",
      httpStatus: response.status,
      evidenceClass: "live_public_get",
      fixtureId: null,
      unavailable: true,
      error: response.error,
    };
  }
  return {
    ...base,
    text: response.text,
    httpStatus: response.status,
    evidenceClass: "live_public_get",
    fixtureId: null,
    unavailable: false,
  };
}

export function provenanceFromRead(read, { sourceId, adapterId, documentationUrl, termsUrl, contentPolicy, termsLinks }) {
  return {
    sourceId,
    adapterId,
    documentationUrl,
    termsUrl,
    requestUrl: read.requestUrl,
    fetchedAt: read.fetchedAt,
    fixtureId: read.fixtureId,
    evidenceClass: read.evidenceClass,
    httpStatus: read.httpStatus,
    bodySha256: read.unavailable ? null : sha256Prefixed(read.text),
    contentPolicy,
    terms: {
      documentationUrl,
      termsUrl,
      auth: "none",
      mutations: "none",
      links: termsLinks,
    },
  };
}

export function parseJson(text) {
  try {
    return { ok: true, value: JSON.parse(text) };
  } catch {
    return { ok: false };
  }
}
