import { MAX_TITLE_CHARS } from "./constants.mjs";

const ISO_Z = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/;
const UNSAFE_TITLE = /bearer\s+[a-z0-9._~+/=-]{8,}|ghp_[a-z0-9]{20,}|github_pat_|-----begin/i;

export function isIsoZ(value) {
  return typeof value === "string" && ISO_Z.test(value) && Number.isFinite(Date.parse(value));
}

export function canonicalIso(value) {
  if (typeof value !== "string" || !Number.isFinite(Date.parse(value))) return null;
  const iso = new Date(value).toISOString();
  return iso.endsWith("Z") ? iso : null;
}

/**
 * Titles are identifiers stored in the action. Credential-shaped text is dropped
 * before it can be copied into the published artifact.
 */
export function cleanTitle(value) {
  if (typeof value !== "string") return { title: "", reason: null };
  const title = value.trim().replace(/\s+/g, " ").slice(0, MAX_TITLE_CHARS);
  if (UNSAFE_TITLE.test(title)) return { title: "", reason: "unsafe_title" };
  return { title, reason: null };
}
