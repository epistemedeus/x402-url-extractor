# seller-repair-external-consumer 0.4.1

Bounded caller execution plus a method-compatibility replay.
Node.js >=22.22.0. No npm packages. No default capture.

```bash
node package/bin/caller-deliver.mjs deliver --request request.json
node package/bin/caller-deliver.mjs later --artifact regression.json --caller caller.json
```

request.json is supplied by the caller. A 402 amount is not a price.
safeToPay cannot be set by the caller. productionHosted stays false.
