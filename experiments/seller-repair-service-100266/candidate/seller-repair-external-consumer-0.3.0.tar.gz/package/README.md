# seller-repair-external-consumer 0.3.0

Bounded caller execution for one supplied repair request.
Node.js >=22.22.0. No npm packages.

```bash
node package/bin/caller-deliver.mjs deliver --request request.json
node package/bin/caller-deliver.mjs later --artifact regression.json --caller caller.json
```

A missing request prints help and does not fabricate a completed task.
`independentRetest: true` does not establish a probe.
productionHosted and hostedAcquisitionVerified stay false.
